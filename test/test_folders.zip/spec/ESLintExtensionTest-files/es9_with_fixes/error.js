console.log("hello", x==2);

function x(){
        const x = 20;
    if(x==1 || y==1){
        console.log("d")
    };
}