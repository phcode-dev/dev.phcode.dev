/*
 * GNU AGPL-3.0 License
 *
 * Copyright (c) 2021 - present core.ai . All rights reserved.
 * Original work Copyright (c) 2014 - 2021 Adobe Systems Incorporated. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see https://opensource.org/licenses/AGPL-3.0.
 *
 */

/*global describe, beforeEach, beforeAll, afterAll, afterEach, it, expect, awaitsForDone, spyOn, jasmine, awaitsFor */

define(function (require, exports, module) {


    var CommandManager,          // loaded from brackets.test
        Commands,                // loaded from brackets.test
        DocumentManager,         // loaded from brackets.test
        EditorManager,           // loaded from brackets.test
        MainViewManager,         // loaded from brackets.test
        ProjectManager,          // loaded from brackets.test
        FileSystem,              // loaded from brackets.test
        Dialogs,                 // loaded from brackets.test
        DefaultDialogs,
        WorkspaceManager,
        PreferencesManager,
        Menus,
        SpecRunnerUtils          = require("spec/SpecRunnerUtils"),
        KeyEvent                 = require("utils/KeyEvent");

    describe("mainview:MainViewManager", function () {

        let testPath = SpecRunnerUtils.getTestPath("/spec/MainViewManager-test-files"),
            testWindow,
            _$,
            savedIsWithinProject,
            promise;

        var getFileObject = function (name) {
            return FileSystem.getFileForPath(testPath + "/" + name);
        };

        async function _init() {
            await SpecRunnerUtils.loadProjectInTestWindow(testPath);
            // Load module instances from brackets.test
            CommandManager          = testWindow.brackets.test.CommandManager;
            Commands                = testWindow.brackets.test.Commands;
            DocumentManager         = testWindow.brackets.test.DocumentManager;
            EditorManager           = testWindow.brackets.test.EditorManager;
            DefaultDialogs          = testWindow.brackets.test.DefaultDialogs;
            PreferencesManager      = testWindow.brackets.test.PreferencesManager;
            MainViewManager         = testWindow.brackets.test.MainViewManager;
            ProjectManager          = testWindow.brackets.test.ProjectManager;
            WorkspaceManager        = testWindow.brackets.test.WorkspaceManager;
            FileSystem              = testWindow.brackets.test.FileSystem;
            Dialogs                 = testWindow.brackets.test.Dialogs,
            Menus                   = testWindow.brackets.test.Menus;
            _$                      = testWindow.$;
            savedIsWithinProject    = ProjectManager.isWithinProject;
        }

        beforeAll(async function () {
            testWindow = await SpecRunnerUtils.createTestWindowAndRun({forceReload: true});
            await _init();
            // we have to disable html lint here as html lint panel interferes with the panel view tests,
            // which was created before we added html lint. Since we only test the panel functionality, not having html
            // lint won't impact test correctness.
            const prefs = PreferencesManager.getExtensionPrefs("HTMLLint");
            const PREFS_HTML_LINT_DISABLED = "disabled";
            prefs.set(PREFS_HTML_LINT_DISABLED, true);
        }, 30000);

        afterAll(async function () {
            ProjectManager.isWithinProject = savedIsWithinProject;
            MainViewManager._closeAll(MainViewManager.ALL_PANES);
            testWindow              = null;
            CommandManager          = null;
            Commands                = null;
            DocumentManager         = null;
            EditorManager           = null;
            ProjectManager          = null;
            FileSystem              = null;
            PreferencesManager      = null;
            await SpecRunnerUtils.closeTestWindow();
        }, 30000);

        beforeEach(async function () {
            MainViewManager._closeAll(MainViewManager.ALL_PANES);
            MainViewManager.setActivePaneId(MainViewManager.FIRST_PANE);
        });

        describe("basic attributes", function () {
            it("should have an active pane id", function () {
                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
            });
            it("should have only one pane", function () {
                expect(MainViewManager.getPaneCount()).toEqual(1);
                expect(MainViewManager.getPaneIdList().length).toEqual(1);
                expect(MainViewManager.getPaneIdList()[0]).toEqual("first-pane");
            });
            it("should not be viewing anything", function () {
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toEqual(null);
                expect(MainViewManager.getCurrentlyViewedPath(MainViewManager.ACTIVE_PANE)).toEqual(null);
                expect(MainViewManager.getCurrentlyViewedFile("first-pane")).toEqual(null);
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toEqual(null);
            });
            it("Pane should not have a title", function () {
                expect(MainViewManager.getPaneTitle("first-pane")).toBeFalsy();
            });
        });

        describe("Title bar", function () {
            it("should have a title bar in browser windows", async function () {
                if(Phoenix.isNativeApp) {
                    return;
                }

                const promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                const $element = testWindow.$('.title-wrapper .title');
                const isDisplayed = $element.is(":visible");
                expect(isDisplayed).toBeTrue(); // if no file opened, no html title bar bay

            });

            it("should not have a title bar in tauri windows", async function () {
                if(!Phoenix.isNativeApp) {
                    return;
                }
                const $element = testWindow.$('.title-wrapper .title');

                const promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                const isDisplayed = $element.is(":visible");
                expect(isDisplayed).toBeFalse();

            });

            it("should set a fixed title wrapper width in browser windows", async function () {
                if(Phoenix.isNativeApp) {
                    return;
                }
                const openPromise = MainViewManager._open(MainViewManager.FIRST_PANE,
                    FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(openPromise, "MainViewManager.doOpen");

                const wrapper = testWindow.$('.title-wrapper')[0];
                await awaitsFor(function () {
                    return parseFloat(wrapper.style.width) > 0;
                }, "title wrapper to get a fixed width", 2000);
            });

            it("should not set a title wrapper width in tauri windows", async function () {
                if(!Phoenix.isNativeApp) {
                    return;
                }
                const openPromise = MainViewManager._open(MainViewManager.FIRST_PANE,
                    FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(openPromise, "MainViewManager.doOpen");

                // In native apps, the file name is shown in the OS window title bar
                // the in-app wrapper for file name stays hidden and _updateTitle skips its layout work...
                const $wrapper = testWindow.$('.title-wrapper');
                expect($wrapper.css("display")).toBe("none");
                expect($wrapper[0].style.width).toBe("");
            });
        });

        describe("opening and closing files", function () {
            it("should open a file", async function () {
                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                expect(MainViewManager.getCurrentlyViewedPath(MainViewManager.ACTIVE_PANE)).toEqual(testPath + "/test.js");
                expect(MainViewManager.getCurrentlyViewedFile("first-pane").name).toEqual("test.js");
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toEqual(testPath + "/test.js");
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ALL_PANES)).toEqual(0);// panes are not activated on open

                MainViewManager._close(MainViewManager.ACTIVE_PANE, FileSystem.getFileForPath(testPath + "/test.js" ));
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toEqual(null);
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ALL_PANES)).toEqual(0);
            });
            it("should add file to working-set when opening files that are outside of the project", async function () {
                ProjectManager.isWithinProject = function () {
                    return false;
                };
                promise = MainViewManager._open(MainViewManager.ACTIVE_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                expect(MainViewManager.getCurrentlyViewedPath(MainViewManager.ACTIVE_PANE)).toEqual(testPath + "/test.js");
                expect(MainViewManager.getCurrentlyViewedFile("first-pane").name).toEqual("test.js");
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toEqual(testPath + "/test.js");
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ALL_PANES)).toEqual(1);

                MainViewManager._close(MainViewManager.ACTIVE_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toEqual(null);
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ALL_PANES)).toEqual(0);
            });
            it("should edit a document", async function () {
                promise = new $.Deferred();
                DocumentManager.getDocumentForPath(testPath + "/test.js")
                    .done(function (doc) {
                        MainViewManager._edit(MainViewManager.ACTIVE_PANE, doc);
                        promise.resolve();
                    });

                await awaitsForDone(promise, "MainViewManager.doEdit");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                expect(MainViewManager.getCurrentlyViewedPath(MainViewManager.ACTIVE_PANE)).toEqual(testPath + "/test.js");
                expect(MainViewManager.getCurrentlyViewedFile("first-pane").name).toEqual("test.js");
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toEqual(testPath + "/test.js");
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ALL_PANES)).toEqual(1);

                MainViewManager._close(MainViewManager.ACTIVE_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toEqual(null);
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ALL_PANES)).toEqual(0);
            });
            it("should not automatically be added to the working set when opening a file", async function () {
                promise = MainViewManager._open(MainViewManager.ACTIVE_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ALL_PANES)).toEqual(1);
            });
            it("should fail when operating on an invalid pane id", async function () {
                spyOn(Dialogs, 'showModalDialog').and.callFake(function (dlgClass, title, message, buttons) {
                    return {done: function (callback) { callback(Dialogs.DIALOG_BTN_OK); } };
                });
                var testme = function () {
                    CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                        paneId: "second-pane" });
                };
                expect(testme).toThrow();
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toBeFalsy();
                expect(function () { MainViewManager.setActivePaneId("second-pane"); }).toThrow();
                expect(MainViewManager.getActivePaneId()).not.toEqual("second-pane");
                expect(function () { MainViewManager.addToWorkingSet("second-pane", getFileObject("test.js")); }).toThrow();
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, testPath + "/test.js")).toEqual(-1);
                expect(function () { MainViewManager.findInWorkingSet("second-pane", testPath + "/test.js"); }).toThrow();
                expect(function () { MainViewManager.addListToWorkingSet("second-pane", [getFileObject("test.js")]); }).toThrow();
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, testPath + "/test.js")).toEqual(-1);
                expect(function () { MainViewManager.findInWorkingSet("second-pane", testPath + "/test.js"); }).toThrow();
            });
        });
        describe("editor manager integration", function () {
            it("should report the existing editor as the current full editor", async function () {
                var promise,
                    testDoc;
                promise = new $.Deferred();
                DocumentManager.getDocumentForPath(testPath + "/test.js")
                    .done(function (doc) {
                        testDoc = doc;
                        MainViewManager._edit(MainViewManager.ACTIVE_PANE, doc);
                        promise.resolve();
                    });

                await awaitsForDone(promise, "MainViewManager.doEdit");
                expect(EditorManager.getCurrentFullEditor()).toEqual(testDoc._masterEditor);
            });
            it("should notify when active editor changes", async function () {
                var promise,
                    docChangeListener = jasmine.createSpy(),
                    activeEditorChangeListener = jasmine.createSpy();

                DocumentManager.on("currentDocumentChange", docChangeListener);
                EditorManager.on("activeEditorChange", activeEditorChangeListener);
                promise = new $.Deferred();
                DocumentManager.getDocumentForPath(testPath + "/test.js")
                    .done(function (doc) {
                        MainViewManager._edit(MainViewManager.ACTIVE_PANE, doc);
                        promise.resolve();
                    });

                await awaitsForDone(promise, "MainViewManager.doEdit");
                expect(docChangeListener).toHaveBeenCalled();
                expect(activeEditorChangeListener).toHaveBeenCalled();
            });
        });
        describe("currentFileChange event handlers", function () {
            it("should fire currentFileChange event", async function () {
                var currentFileChangeListener = jasmine.createSpy();

                MainViewManager.on("currentFileChange", currentFileChangeListener);
                expect(currentFileChangeListener.calls.count()).toBe(0);
                promise = MainViewManager._open(MainViewManager.ACTIVE_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");
                expect(currentFileChangeListener.calls.count()).toBe(1);
                expect(currentFileChangeListener.calls.all()[0].args[1].name).toEqual("test.js");
                expect(currentFileChangeListener.calls.all()[0].args[2]).toEqual("first-pane");
                MainViewManager._closeAll(MainViewManager.ALL_PANES);
                expect(currentFileChangeListener.calls.count()).toBe(2);
                expect(currentFileChangeListener.calls.all()[1].args[1]).toEqual(null);
                MainViewManager.off("currentFileChange", currentFileChangeListener);
            });
            it("DocumentManager should listen to currentFileChange events", async function () {
                promise = MainViewManager._open(MainViewManager.ACTIVE_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");
                expect(DocumentManager.getCurrentDocument()).toBeTruthy();
                expect(DocumentManager.getCurrentDocument().file.name).toEqual("test.js");
                MainViewManager._closeAll(MainViewManager.ALL_PANES);
                expect(DocumentManager.getCurrentDocument()).toBe(null);
            });
            it("EditorManager should listen to currentFileChange events", async function () {
                promise = MainViewManager._open(MainViewManager.ACTIVE_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");
                expect(EditorManager.getCurrentFullEditor()).toBeTruthy();
                expect(EditorManager.getCurrentFullEditor().document.file.name).toEqual("test.js");
                MainViewManager._closeAll(MainViewManager.ALL_PANES);
                expect(EditorManager.getCurrentFullEditor()).toBe(null);
            });
        });
        describe("Splitting Views", function () {
            it("should create a new pane", async function () {
                var paneCreateListener = jasmine.createSpy(),
                    paneLayoutChangeListener = jasmine.createSpy();

                MainViewManager.on("paneCreate", paneCreateListener);
                MainViewManager.on("paneLayoutChange", paneLayoutChangeListener);
                MainViewManager.setLayoutScheme(1, 2);
                expect(MainViewManager.getPaneCount()).toEqual(2);
                expect(MainViewManager.getPaneIdList().length).toEqual(2);
                expect(MainViewManager.getPaneIdList()[1]).toEqual("second-pane");
                expect(MainViewManager.getAllOpenFiles().length).toEqual(0);

                expect(paneCreateListener.calls.count()).toBe(1);
                expect(paneLayoutChangeListener.calls.count()).toBe(1);

                expect(paneCreateListener.calls.all()[0].args[1]).toEqual("second-pane");
                expect(paneLayoutChangeListener.calls.all()[0].args[1]).toEqual("VERTICAL");
                MainViewManager.off("paneCreate", paneCreateListener);
                MainViewManager.off("paneLayoutChange", paneLayoutChangeListener);
            });
            it("should should show interstitial page", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                var interstitials = _$(".not-editor");
                expect(interstitials.length).toEqual(2);
                expect(_$(interstitials[0]).css("display")).not.toEqual("none");
                expect(_$(interstitials[1]).css("display")).not.toEqual("none");
            });
            it("should destroy a pane", async function () {
                // when we migrated to jasmine 2.0, this test was not activating the pane. assuming that all tests are
                // working correctly, the tests has been tweaked to match reality. We stopped reloading the test window
                // after each test to improve performance. This caused the issue to prop.
                var paneDestroyListener = jasmine.createSpy(),
                    paneLayoutChangeListener = jasmine.createSpy();

                MainViewManager.on("paneDestroy", paneDestroyListener);
                MainViewManager.on("paneLayoutChange", paneLayoutChangeListener);
                MainViewManager.setLayoutScheme(1, 2);
                expect(MainViewManager.getPaneCount()).toEqual(2);
                expect(MainViewManager.getPaneIdList().length).toEqual(2);
                expect(MainViewManager.getPaneIdList()[1]).toEqual("second-pane");
                MainViewManager.setLayoutScheme(1, 1);
                expect(MainViewManager.getPaneCount()).toEqual(1);
                expect(MainViewManager.getPaneIdList().length).toEqual(1);
                expect(MainViewManager.getPaneIdList()[0]).toEqual("first-pane");

                expect(paneDestroyListener.calls.count()).toBe(1);
                expect(paneLayoutChangeListener.calls.count()).toBe(1);

                expect(paneDestroyListener.calls.all()[0].args[1]).toEqual("second-pane");
                MainViewManager.off("paneDestroy", paneDestroyListener);
                MainViewManager.off("paneLayoutChange", paneLayoutChangeListener);
            });
            it("should show two files", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.js")).toEqual("first-pane");
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.css")).toEqual("second-pane");
                expect(MainViewManager.getWorkingSetSize("first-pane")).toEqual(1);
                expect(MainViewManager.getWorkingSetSize("second-pane")).toEqual(1);
                MainViewManager.setActivePaneId("first-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                expect(EditorManager.getCurrentFullEditor().document.file.name).toEqual("test.js");
                MainViewManager.setActivePaneId("second-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.css");
                expect(EditorManager.getCurrentFullEditor().document.file.name).toEqual("test.css");
            });
            it("should flip the view to the other pane", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.js")).toEqual("first-pane");
                MainViewManager.setActivePaneId("first-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                MainViewManager.setActivePaneId("second-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toEqual(null);
                MainViewManager._getPane("first-pane").$headerFlipViewBtn.trigger("click");
                MainViewManager.setActivePaneId("first-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toEqual(null);
                MainViewManager.setActivePaneId("second-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                MainViewManager._getPane("second-pane").$headerFlipViewBtn.trigger("click");
                MainViewManager.setActivePaneId("first-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                MainViewManager.setActivePaneId("second-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toEqual(null);
            });
            it("should show the file instead of flipping if file is already open", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                MainViewManager._getPane("first-pane").$headerFlipViewBtn.trigger("click");
                MainViewManager.setActivePaneId("first-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                expect(EditorManager.getCurrentFullEditor().document.file.name).toEqual("test.js");
                MainViewManager.setActivePaneId("second-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                expect(EditorManager.getCurrentFullEditor().document.file.name).toEqual("test.js");
            });
            it("should merge two panes to the right", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                expect(MainViewManager.getWorkingSetSize("first-pane")).toEqual(1);
                expect(MainViewManager.getWorkingSetSize("second-pane")).toEqual(1);
                MainViewManager.setLayoutScheme(1, 1);
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.js")).toEqual("first-pane");
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.css")).toEqual("first-pane");
            });
            it("should merge two panes to the left", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                expect(MainViewManager.getWorkingSetSize("first-pane")).toEqual(1);
                expect(MainViewManager.getWorkingSetSize("second-pane")).toEqual(1);
                MainViewManager.setActivePaneId("first-pane");
                MainViewManager.setLayoutScheme(1, 1);
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.js")).toEqual("first-pane");
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.css")).toEqual("first-pane");
            });
            it("should close the view when clicked", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.js")).toEqual("first-pane");
                MainViewManager.setActivePaneId("first-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE).name).toEqual("test.js");
                MainViewManager._getPane("first-pane").$headerCloseBtn.trigger("click");
                MainViewManager.setActivePaneId("first-pane");
                expect(MainViewManager.getCurrentlyViewedFile(MainViewManager.ACTIVE_PANE)).toEqual(null);
            });
            it("should collapse the panes when close button is clicked on a pane with no files", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                MainViewManager._getPane("first-pane").$headerCloseBtn.trigger("click");
                expect(MainViewManager.getLayoutScheme()).toEqual({rows: 1, columns: 1});
            });
            it("should switch pane when Commands.CMD_SWITCH_PANE_FOCUS is called", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                $('#first-pane').click();
                CommandManager.execute(Commands.CMD_SWITCH_PANE_FOCUS);
                expect(MainViewManager.getActivePaneId()).toEqual("second-pane");
                $('#second-pane').click();
                CommandManager.execute(Commands.CMD_SWITCH_PANE_FOCUS);
                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                MainViewManager.setLayoutScheme(2, 1);
                $('#first-pane').click();
                CommandManager.execute(Commands.CMD_SWITCH_PANE_FOCUS);
                expect(MainViewManager.getActivePaneId()).toEqual("second-pane");
                $('#second-pane').click();
                CommandManager.execute(Commands.CMD_SWITCH_PANE_FOCUS);
                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
            });
            it("should activate pane when editor gains focus", async function () {
                var editors = {},
                    handler = function (e, doc, editor, paneId) {
                        editors[doc.file.name] = editor;
                    };

                EditorManager.on("_fullEditorCreatedForDocument", handler);
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                editors["test.css"].focus();
                expect(MainViewManager.getActivePaneId()).toEqual("second-pane");
                editors["test.js"].focus();
                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                editors = null;
                EditorManager.off("_fullEditorCreatedForDocument", handler);
            });
            it("should activate pane when inline editor gains focus", async function () {
                var inlineEditor,
                    editors = {},
                    handler = function (e, doc, editor, paneId) {
                        editors[doc.file.name] = editor;
                    };

                EditorManager.on("_fullEditorCreatedForDocument", handler);
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.html",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                MainViewManager.setActivePaneId("first-pane");

                // open inline editor at specified offset index
                var inlineEditorResult = SpecRunnerUtils.toggleQuickEditAtOffset(editors["test.html"], {line: 8, ch: 14});
                await awaitsForDone(inlineEditorResult, "inline editor opened", 1000);

                MainViewManager.setActivePaneId("second-pane");
                inlineEditor = EditorManager.getInlineEditors(editors["test.html"])[0];
                inlineEditor.focus();
                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
            });
            it("should activate pane when pane is clicked", async function () {
                var activePaneChangeListener = jasmine.createSpy();

                MainViewManager.on("activePaneChange", activePaneChangeListener);
                MainViewManager.setLayoutScheme(1, 2);
                _$("#second-pane").click();
                expect(MainViewManager.getActivePaneId()).toEqual("second-pane");
                _$("#first-pane").click();
                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                expect(activePaneChangeListener.calls.count()).toBe(2);
                MainViewManager.off("activePaneChange", activePaneChangeListener);
            });
            it("should enforce bounds", function () {
                expect(MainViewManager.setLayoutScheme(1, 4)).toBeFalsy();
                expect(MainViewManager.setLayoutScheme(4, -2)).toBeFalsy();
                expect(MainViewManager.setLayoutScheme(0, 0)).toBeFalsy();
                expect(MainViewManager.setLayoutScheme(-1, -1)).toBeFalsy();
                expect(MainViewManager.setLayoutScheme(4, 1)).toBeFalsy();
                expect(MainViewManager.setLayoutScheme(1, 1)).toBeTruthy();
                expect(MainViewManager.setLayoutScheme(1, 2)).toBeTruthy();
                expect(MainViewManager.setLayoutScheme(2, 1)).toBeTruthy();
            });
            it("should toggle layout", async function () {
                var paneLayoutChangeListener = jasmine.createSpy();

                MainViewManager.on("paneLayoutChange", paneLayoutChangeListener);
                MainViewManager.setLayoutScheme(1, 2);
                expect(MainViewManager.getLayoutScheme()).toEqual({rows: 1, columns: 2});
                expect(paneLayoutChangeListener.calls.all()[0].args[1]).toEqual("VERTICAL");
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                MainViewManager.setLayoutScheme(2, 1);
                expect(MainViewManager.getLayoutScheme()).toEqual({rows: 2, columns: 1});
                expect(paneLayoutChangeListener.calls.all()[1].args[1]).toEqual("HORIZONTAL");
                expect(paneLayoutChangeListener.calls.count()).toBe(2);
                MainViewManager.off("paneLayoutChange", paneLayoutChangeListener);
            });
        });
        describe("Targeted Pane API tests", function () {
            it("should count open views", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ALL_PANES)).toEqual(2);
                expect(MainViewManager.getWorkingSetSize(MainViewManager.ACTIVE_PANE)).toEqual(1);
            });
            it("should find file in view", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                expect(MainViewManager.findInAllWorkingSets(testPath + "/test.js").shift().paneId).toEqual("second-pane");
            });
            it("should reopen file in view", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                // With same doc split doc should be opened in first pane as well
                expect(MainViewManager._getPaneIdForPath(testPath + "/test.js")).toEqual("first-pane");
            });
            it("should close all files in pane", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                MainViewManager._closeAll("second-pane");
                expect(MainViewManager.getAllOpenFiles().length).toEqual(1);
                MainViewManager._closeAll("first-pane");
                expect(MainViewManager.getAllOpenFiles().length).toEqual(0);
            });
            it("should allow closed files to reopen in new pane", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                MainViewManager._close("second-pane", FileSystem.getFileForPath(testPath + "/test.js"));
                expect(MainViewManager.getAllOpenFiles().length).toEqual(1);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.js").fullPath)).toEqual("first-pane");
            });
            it("should add to the appropriate workingset", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                MainViewManager.setActivePaneId("second-pane");
                MainViewManager.addToWorkingSet(MainViewManager.ACTIVE_PANE, getFileObject("test.js"));
                let ws = MainViewManager.findInAllWorkingSets(testPath + "/test.js");
                expect(ws[0].paneId).toEqual("first-pane");
                expect(ws[1].paneId).toEqual("second-pane");
            });
            it("should add list to the appropriate workingset", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.html",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                MainViewManager.setActivePaneId("second-pane");
                MainViewManager.addListToWorkingSet(MainViewManager.ACTIVE_PANE, [getFileObject("test.js"),
                    getFileObject("test.css"),
                    getFileObject("test.html")]);
                let ws = MainViewManager.findInAllWorkingSets(testPath + "/test.js");
                expect(ws[0].paneId).toEqual("first-pane");
                expect(ws[1].paneId).toEqual("second-pane");
                ws = MainViewManager.findInAllWorkingSets(testPath + "/test.css");
                expect(ws[0].paneId).toEqual("first-pane");
                expect(ws[1].paneId).toEqual("second-pane");
                ws = MainViewManager.findInAllWorkingSets(testPath + "/test.html");
                expect(ws.length).toEqual(1);
                expect(ws[0].paneId).toEqual("second-pane");
            });
        });
        describe("workingSetList Management tests", function () {
            beforeEach(async function () {
                MainViewManager.setLayoutScheme(1, 2);
            });
            it("should add file to FOCUSED pane", async function () {
                MainViewManager.setActivePaneId("first-pane");
                MainViewManager.addToWorkingSet(MainViewManager.ACTIVE_PANE, getFileObject("test.js"));
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.js").fullPath)).toEqual("first-pane");
                MainViewManager.setActivePaneId("second-pane");
                MainViewManager.addToWorkingSet(MainViewManager.ACTIVE_PANE, getFileObject("test.css"));
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.css").fullPath)).toEqual("second-pane");
            });
            it("should add files to FOCUSED pane", async function () {
                MainViewManager.setActivePaneId("first-pane");
                MainViewManager.addListToWorkingSet(MainViewManager.ACTIVE_PANE, [getFileObject("test.js"),
                    getFileObject("test.css")]);
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.js").fullPath)).toEqual("first-pane");
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.css").fullPath)).toEqual("first-pane");
                MainViewManager.setActivePaneId("second-pane");
                MainViewManager.addListToWorkingSet(MainViewManager.ACTIVE_PANE, [getFileObject("test.txt"),
                    getFileObject("test.html")]);
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.txt").fullPath)).toEqual("second-pane");
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.html").fullPath)).toEqual("second-pane");
            });
            it("should add file to appropriate pane", async function () {
                MainViewManager.setActivePaneId("second-pane");
                MainViewManager.addToWorkingSet("first-pane", getFileObject("test.js"));
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.js").fullPath)).toEqual("first-pane");
                MainViewManager.setActivePaneId("first-pane");
                MainViewManager.addToWorkingSet("second-pane", getFileObject("test.css"));
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.css").fullPath)).toEqual("second-pane");
            });
            it("should add files to appropriate pane", async function () {
                MainViewManager.setActivePaneId("second-pane");
                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.js").fullPath)).toEqual("first-pane");
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.css").fullPath)).toEqual("first-pane");
                MainViewManager.setActivePaneId("first-pane");
                MainViewManager.addListToWorkingSet("second-pane", [getFileObject("test.txt"),
                    getFileObject("test.html")]);
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.txt").fullPath)).toEqual("second-pane");
                expect(MainViewManager._getPaneIdForPath(getFileObject("test.html").fullPath)).toEqual("second-pane");
            });
            it("should not add list of files to ALL_PANES ", async function () {
                expect(function () {
                    MainViewManager.addListToWorkingSet(MainViewManager.ALL_PANES, [getFileObject("test.js"),
                        getFileObject("test.css")]);
                }).toThrow();
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, getFileObject("test.js").fullPath)).toEqual(-1);
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, getFileObject("test.css").fullPath)).toEqual(-1);
            });
            it("should not add a file to ALL_PANES ", async function () {
                expect(function () {
                    MainViewManager.addToWorkingSet(MainViewManager.ALL_PANES, getFileObject("test.css"));
                }).toThrow();
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, getFileObject("test.css").fullPath)).toEqual(-1);
            });
            it("should remove the view when removing a file from a workingset", async function () {
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);

                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager._close(MainViewManager.ALL_PANES, getFileObject("test.css"));
                expect(MainViewManager.getCurrentlyViewedFile("first-pane").name).toEqual("test.js");
            });
            it("should remove the file when removing from a targeted pane", async function () {
                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager._close("first-pane", getFileObject("test.css"));
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, getFileObject("test.css").fullPath)).toEqual(-1);
            });
            it("should remove the file when removing from the FOCUSED pane", async function () {
                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager.setActivePaneId("first-pane");
                MainViewManager._close(MainViewManager.ACTIVE_PANE, getFileObject("test.js"));
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, getFileObject("test.js").fullPath)).toEqual(-1);
            });
            it("should remove the file when removing from ALL_PANES", async function () {
                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager.setActivePaneId("first-pane");
                MainViewManager._close(MainViewManager.ALL_PANES, getFileObject("test.js"));
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, getFileObject("test.js").fullPath)).toEqual(-1);
            });
            //

            it("should remove the view when removing files from a workingset", async function () {
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);
                promise = CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN);

                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager._closeList(MainViewManager.ALL_PANES, [getFileObject("test.js"),
                    getFileObject("test.css")]);
                expect(Object.keys(MainViewManager._getPane("first-pane")._views).length).toEqual(0);
            });
            it("should remove files from the workingset", async function () {
                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager._closeList(MainViewManager.ALL_PANES, [getFileObject("test.js"),
                    getFileObject("test.css")]);
                expect(MainViewManager.getWorkingSetSize("first-pane")).toEqual(0);
            });
            it("should remove files from the workingset", async function () {
                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager._closeList(MainViewManager.ALL_PANES, [getFileObject("test.js"),
                    getFileObject("test.css")]);
                expect(MainViewManager.getWorkingSetSize("first-pane")).toEqual(0);
            });
            it("should remove files when removing from a targeted pane", async function () {
                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager._closeList("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                expect(MainViewManager.getWorkingSetSize("first-pane")).toEqual(0);
            });
            it("should remove the file when removing from the FOCUSED pane", async function () {
                MainViewManager.addListToWorkingSet("first-pane", [getFileObject("test.js"),
                    getFileObject("test.css")]);
                MainViewManager.setActivePaneId("first-pane");
                MainViewManager._closeList(MainViewManager.ACTIVE_PANE, [getFileObject("test.js"),
                    getFileObject("test.css")]);
                expect(MainViewManager.getWorkingSetSize("first-pane")).toEqual(0);
            });
            it("should remove the file when removing from ALL_PANES", async function () {
                MainViewManager.addToWorkingSet("first-pane", getFileObject("test.js"));
                MainViewManager.addToWorkingSet("second-pane", getFileObject("test.css"));
                MainViewManager._closeList(MainViewManager.ALL_PANES, [getFileObject("test.js"),
                    getFileObject("test.css")]);
                expect(MainViewManager.getWorkingSetSize("first-pane")).toEqual(0);
                expect(MainViewManager.getWorkingSetSize("second-pane")).toEqual(0);
            });
            it("should find file in view", async function () {
                MainViewManager.addToWorkingSet("second-pane", getFileObject("test.js"));
                MainViewManager.setActivePaneId("first-pane");
                expect(MainViewManager.findInAllWorkingSets(getFileObject("test.js").fullPath).shift().paneId).toEqual("second-pane");
                expect(MainViewManager.findInWorkingSet(MainViewManager.ACTIVE_PANE, getFileObject("test.js").fullPath)).toEqual(-1);
                expect(MainViewManager.findInWorkingSet("second-pane", getFileObject("test.js").fullPath)).not.toEqual(-1);
                expect(MainViewManager.findInWorkingSet("first-pane", getFileObject("test.js").fullPath)).toEqual(-1);
                expect(MainViewManager.findInWorkingSet(MainViewManager.ALL_PANES, getFileObject("test.css").fullPath)).toEqual(-1);
            });
        });

        describe("Traversing Files", function () {
            beforeEach(async function () {
                MainViewManager.setLayoutScheme(1, 2);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.css",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.html",
                    paneId: "second-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                MainViewManager.addToWorkingSet("first-pane", getFileObject("test.js"));
                MainViewManager.addToWorkingSet("first-pane", getFileObject("test.css"));
                MainViewManager.addToWorkingSet("second-pane", getFileObject("test.html"));
            });

            it("should traverse in list order", async function () {
                // Make test.js the active file
                promise = new $.Deferred();
                DocumentManager.getDocumentForPath(testPath + "/test.js")
                    .done(function (doc) {
                        MainViewManager._edit("first-pane", doc);
                        promise.resolve();
                    });
                await awaitsForDone(promise, "MainViewManager._edit");
                var traverseResult = MainViewManager.traverseToNextViewInListOrder(1);

                expect(traverseResult.file).toEqual(getFileObject("test.css"));
                expect(traverseResult.pane).toEqual("first-pane");
            });

            it("should traverse between panes in list order", async function () {
                var traverseResult = MainViewManager.traverseToNextViewInListOrder(1);

                expect(traverseResult.file).toEqual(getFileObject("test.js"));
                expect(traverseResult.pane).toEqual("first-pane");
            });

            it("should traverse to the first Working Set item if a file not in the Working Set is being viewed", async function () {
                // Close test.js to then reopen it without being in the Working Set
                CommandManager.execute(Commands.FILE_CLOSE, { file: getFileObject("test.js") });
                promise = CommandManager.execute(Commands.FILE_OPEN,  { fullPath: testPath + "/test.js",
                    paneId: "first-pane" });
                await awaitsForDone(promise, Commands.FILE_OPEN);
                MainViewManager.setActivePaneId("first-pane");

                var traverseResult = MainViewManager.traverseToNextViewInListOrder(1);

                expect(traverseResult.file).toEqual(getFileObject("test.css"));
                expect(traverseResult.pane).toEqual("first-pane");
            });

            it("should traverse between panes in reverse list order", async function () {
                // Make test.js the active file
                promise = new $.Deferred();
                DocumentManager.getDocumentForPath(testPath + "/test.js")
                    .done(function (doc) {
                        MainViewManager._edit("first-pane", doc);
                        promise.resolve();
                    });
                await awaitsForDone(promise, "MainViewManager._edit");
                var traverseResult = MainViewManager.traverseToNextViewInListOrder(-1);

                expect(traverseResult.file).toEqual(getFileObject("test.html"));
                expect(traverseResult.pane).toEqual("second-pane");
            });
        });

        describe("Bottom panel toggle with escape", function () {
            let panel1, panel2;
            beforeAll(function () {
                let samplePanelTemplate2 = `<div id="some-panel2" class="bottom-panel vert-resizable top-resizer"></div>`;
                panel2 = WorkspaceManager.createBottomPanel("panel2", _$(samplePanelTemplate2), 100);
                panel2.hide();
                expect(panel2.isVisible()).toBeFalse();
                let samplePanelTemplate = `<div id="some-panel1" class="bottom-panel vert-resizable top-resizer"></div>`;
                panel1 = WorkspaceManager.createBottomPanel("panel1", _$(samplePanelTemplate), 100);
                panel1.hide();
                expect(panel1.isVisible()).toBeFalse();
            });

            beforeEach(function () {
               panel1.hide();
               panel2.hide();
            });

            function _testPanelDoesntToggleBlocked() {
                panel1.show();
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeTrue();
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeTrue();
            }

            it("should bottom panel not toggle visibility on escape when there is no editor", async function () {
                _testPanelDoesntToggleBlocked();
            });

            async function _testPanelHideSuccess() {
                panel1.show();
                expect(panel1.isVisible()).toBeTrue();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeFalse();
            }

            it("should escape hide bottom panel when editor is focused", async function () {
                await _testPanelHideSuccess();
            });

            it("should bottom panel not toggle visibility on escape if modal dialog shown", async function () {
                panel1.show();
                expect(panel1.isVisible()).toBeTrue();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_ERROR, "title", "message");

                // first escape key will dismiss dialog instead of panel
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeTrue();

                // now panel will be dismissed
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeFalse();
            });

            it("should bottom panel not toggle visibility on escape if popup shown", async function () {
                panel1.show();
                expect(panel1.isVisible()).toBeTrue();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                // show editor context menu
                Menus.getContextMenu(Menus.ContextMenuIds.EDITOR_MENU).open({pageX: 0, pageY: 0});

                // first escape key will dismiss the editor context menu
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeTrue();

                // now panel will be dismissed
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeFalse();
            });

            it("should bottom panel not toggle visibility on escape if focused editor has selection", async function () {
                panel1.show();
                expect(panel1.isVisible()).toBeTrue();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");
                let editor = EditorManager.getActiveEditor();
                editor.setSelection({line: 0, ch: 0}, {line: 0, ch: 1});
                expect(editor.hasSelection()).toBeTrue();

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeTrue();
                editor.clearSelection();
            });

            it("should workspace add and remove EscapeKeyEventHandler", async function () {
                function escapeHandler() {}
                expect(WorkspaceManager.addEscapeKeyEventHandler("x", null)).toBeFalse();
                expect(WorkspaceManager.addEscapeKeyEventHandler("x", {})).toBeFalse();
                expect(WorkspaceManager.addEscapeKeyEventHandler("x", escapeHandler)).toBeTrue();
                // adding existing handler will fail
                expect(WorkspaceManager.addEscapeKeyEventHandler("x", escapeHandler)).toBeFalse();
                // remove now
                expect(WorkspaceManager.removeEscapeKeyEventHandler("x")).toBeTrue();
                // removing handler that doesnt exist will fail
                expect(WorkspaceManager.removeEscapeKeyEventHandler("x")).toBeFalse();
            });

            it("should dismiss panel if EscapeKeyEventHandler returns false", async function () {
                function escapeHandler() {return false;}
                expect(WorkspaceManager.addEscapeKeyEventHandler("x", escapeHandler)).toBeTrue();
                await _testPanelHideSuccess();

                // cleanup
                expect(WorkspaceManager.removeEscapeKeyEventHandler("x")).toBeTrue();
            });

            it("should not dismiss panel if EscapeKeyEventHandler returns true", async function () {
                function escapeHandler() {return true;}
                expect(WorkspaceManager.addEscapeKeyEventHandler("x", escapeHandler)).toBeTrue();
                _testPanelDoesntToggleBlocked();

                // cleanup
                expect(WorkspaceManager.removeEscapeKeyEventHandler("x")).toBeTrue();
            });

            it("should not dismiss any panel if codehints are visible", async function () {
                panel1.show();
                panel2.hide();
                expect(panel1.isVisible()).toBeTrue();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.html"));
                await awaitsForDone(promise, "MainViewManager.doOpen");
                let editor = EditorManager.getActiveEditor();
                // Position cursor inside the <p tag name to trigger HTML tag hints
                editor.setCursorPos(8, 1);
                await awaitsForDone(CommandManager.execute(Commands.SHOW_CODE_HINTS));
                await awaitsFor(function () {
                    return testWindow.$(".codehint-menu").is(":visible");
                }, "codehints to be shown");

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                await awaitsFor(function () {
                    return !testWindow.$(".codehint-menu").is(":visible");
                }, "codehints to be dismissed on escape press");
                expect(panel1.isVisible()).toBeTrue();
            });

            it("should escape collapse entire bottom panel container", async function () {
                panel1.show();
                expect(panel1.isVisible()).toBeTrue();
                panel2.show();
                expect(panel2.isVisible()).toBeTrue();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel2.isVisible()).toBeFalse();
                expect(panel1.isVisible()).toBeFalse();
            });

            it("should toggle bottom panel back on subsequent escape", async function () {
                panel1.show();
                expect(panel1.isVisible()).toBeTrue();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeFalse();
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeTrue();
            });

            it("should shift-escape focus active panel instead of collapsing", async function () {
                panel1.show();
                expect(panel1.isVisible()).toBeTrue();

                let focusCalled = false;
                panel1.focus = function () {
                    focusCalled = true;
                    return true;
                };

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0], {
                    shiftKey: true
                });
                // Shift+Escape should focus the panel, not collapse it
                expect(panel1.isVisible()).toBeTrue();
                expect(focusCalled).toBeTrue();
                delete panel1.focus;
            });

            it("should shift-escape from panel focus the editor", async function () {
                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                panel1.show();
                expect(panel1.isVisible()).toBeTrue();

                // Blur the editor so getFocusedEditor() returns null
                _$("#some-panel1")[0].setAttribute("tabindex", "-1");
                _$("#some-panel1")[0].focus();
                expect(EditorManager.getFocusedEditor()).toBeFalsy();

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown",
                    _$("#editor-holder")[0], { shiftKey: true });
                // Editor should regain focus
                expect(EditorManager.getFocusedEditor()).toBeTruthy();
            });

            it("should shift-escape open default panel when no panel is visible", async function () {
                panel1.hide();
                panel2.hide();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0], {
                    shiftKey: true
                });
                // A panel should now be visible (the default/quick access panel)
                let defaultPanel = WorkspaceManager.getPanelForID(WorkspaceManager.DEFAULT_PANEL_ID);
                expect(defaultPanel.isVisible()).toBeTrue();
                defaultPanel.hide();
            });

            it("should shift-escape focus panel with custom focus handler", async function () {
                // Create a panel with a text input that accepts focus
                let focusPanelTemplate = `<div id="focus-test-panel" class="bottom-panel vert-resizable top-resizer">
                    <input id="focus-test-input" type="text" />
                </div>`;
                let focusPanel = WorkspaceManager.createBottomPanel("focusTestPanel",
                    _$(focusPanelTemplate), 100);

                focusPanel.focus = function () {
                    _$("#focus-test-input")[0].focus();
                    return true;
                };

                focusPanel.show();
                expect(focusPanel.isVisible()).toBeTrue();

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                // Shift+Escape from editor should focus the panel's text input
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown",
                    _$("#editor-holder")[0], { shiftKey: true });
                expect(testWindow.document.activeElement).toBe(_$("#focus-test-input")[0]);

                // Shift+Escape from panel should focus the editor
                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown",
                    _$("#editor-holder")[0], { shiftKey: true });
                expect(EditorManager.getFocusedEditor()).toBeTruthy();
                expect(testWindow.document.activeElement).not.toBe(_$("#focus-test-input")[0]);

                focusPanel.hide();
                WorkspaceManager.destroyBottomPanel("focusTestPanel");
            });

            it("should app-drawer-button toggle the default panel", async function () {
                panel1.hide();
                panel2.hide();
                let defaultPanel = WorkspaceManager.getPanelForID(WorkspaceManager.DEFAULT_PANEL_ID);
                if (defaultPanel.isVisible()) {
                    defaultPanel.hide();
                }
                expect(defaultPanel.isVisible()).toBeFalse();

                // Click app-drawer-button to show the default panel
                _$("#app-drawer-button").click();
                expect(defaultPanel.isVisible()).toBeTrue();

                // Click again to hide it
                _$("#app-drawer-button").click();
                expect(defaultPanel.isVisible()).toBeFalse();
            });

            it("should escape collapse bottom panel regardless of canBeShown", async function () {
                panel1.show();
                panel2.registerCanBeShownHandler(function () {
                    return false;
                });

                expect(MainViewManager.getActivePaneId()).toEqual("first-pane");
                promise = MainViewManager._open(MainViewManager.FIRST_PANE, FileSystem.getFileForPath(testPath + "/test.js"));
                await awaitsForDone(promise, "MainViewManager.doOpen");

                SpecRunnerUtils.simulateKeyEvent(KeyEvent.DOM_VK_ESCAPE, "keydown", _$("#editor-holder")[0]);
                expect(panel1.isVisible()).toBeFalse();
                panel2.registerCanBeShownHandler(null);
            });
        });

        describe("setPluginPanelWidth", function () {
            let pluginPanel, $toolbarIcon;
            const MIN_WIDTH = 200;

            beforeAll(function () {
                // Create a toolbar icon in #plugin-icons-bar
                $toolbarIcon = _$('<a id="test-plugin-icon" href="#"></a>');
                _$("#plugin-icons-bar").append($toolbarIcon);

                let panelTemplate = '<div id="test-plugin-panel">Test Panel</div>';
                pluginPanel = WorkspaceManager.createPluginPanel(
                    "test-setwidth-panel", _$(panelTemplate), MIN_WIDTH, $toolbarIcon
                );
            });

            afterAll(function () {
                if (pluginPanel) {
                    pluginPanel.hide();
                }
                $toolbarIcon.remove();
            });

            afterEach(function () {
                pluginPanel.hide();
            });

            it("should be a no-op when no panel is visible", function () {
                expect(pluginPanel.isVisible()).toBeFalse();
                var toolbarWidthBefore = _$("#main-toolbar").width();
                WorkspaceManager.setPluginPanelWidth(500);
                var toolbarWidthAfter = _$("#main-toolbar").width();
                expect(toolbarWidthAfter).toEqual(toolbarWidthBefore);
            });

            it("should resize the panel to the specified width", function () {
                pluginPanel.show();
                expect(pluginPanel.isVisible()).toBeTrue();

                WorkspaceManager.setPluginPanelWidth(500);

                var $mainToolbar = _$("#main-toolbar");
                var $pluginIconsBar = _$("#plugin-icons-bar");
                var panelContentWidth = $mainToolbar.width() - $pluginIconsBar.outerWidth();
                expect(panelContentWidth).toEqual(500);
            });

            it("should clamp width to panel minWidth", function () {
                pluginPanel.show();

                // Request a width smaller than minWidth
                WorkspaceManager.setPluginPanelWidth(50);

                var $mainToolbar = _$("#main-toolbar");
                var $pluginIconsBar = _$("#plugin-icons-bar");
                var panelContentWidth = $mainToolbar.width() - $pluginIconsBar.outerWidth();
                expect(panelContentWidth).toBeGreaterThanOrEqual(MIN_WIDTH);
            });

            it("should clamp width to max size (75% of window)", function () {
                pluginPanel.show();

                var maxContentWidth = (testWindow.innerWidth * 0.75) -
                    _$("#plugin-icons-bar").outerWidth();

                // Request a width larger than max
                WorkspaceManager.setPluginPanelWidth(testWindow.innerWidth);

                var $mainToolbar = _$("#main-toolbar");
                var $pluginIconsBar = _$("#plugin-icons-bar");
                var panelContentWidth = $mainToolbar.width() - $pluginIconsBar.outerWidth();
                expect(panelContentWidth).toBeLessThanOrEqual(maxContentWidth + 1);
            });

            it("should update $windowContent right offset to match toolbar width", function () {
                pluginPanel.show();

                WorkspaceManager.setPluginPanelWidth(600);

                var $mainToolbar = _$("#main-toolbar");
                var $windowContent = _$(".content");
                var toolbarWidth = $mainToolbar.width();
                var rightOffset = parseInt($windowContent.css("right"), 10);
                expect(rightOffset).toEqual(toolbarWidth);
            });

            it("should handle multiple successive resizes", function () {
                pluginPanel.show();

                var widths = [300, 500, 400, 700];
                var $mainToolbar = _$("#main-toolbar");
                var $pluginIconsBar = _$("#plugin-icons-bar");

                widths.forEach(function (targetWidth) {
                    WorkspaceManager.setPluginPanelWidth(targetWidth);
                    var panelContentWidth = $mainToolbar.width() - $pluginIconsBar.outerWidth();
                    expect(panelContentWidth).toEqual(targetWidth);
                });
            });

            it("should preserve at least 100px for the editor area", function () {
                pluginPanel.show();

                // Request an absurdly large width that would squeeze the editor to near-zero
                WorkspaceManager.setPluginPanelWidth(testWindow.innerWidth);

                const $mainToolbar = _$("#main-toolbar");
                const sidebarWidth = _$("#sidebar").outerWidth() || 0;
                const toolbarWidth = $mainToolbar.width();
                const editorWidth = testWindow.innerWidth - sidebarWidth - toolbarWidth;

                // Editor area must retain at least 100px
                expect(editorWidth).toBeGreaterThanOrEqual(100);
            });

            it("should set drag-based maxsize to preserve at least 100px for the editor", function () {
                pluginPanel.show();

                // Trigger a layout recompute so updateResizeLimits runs
                WorkspaceManager.recomputeLayout(true);

                const $mainToolbar = _$("#main-toolbar");
                const sidebarWidth = _$("#sidebar").outerWidth() || 0;
                const maxSize = $mainToolbar.data("maxsize");

                // maxSize must leave at least 100px for the editor
                const editorWidthAtMax = testWindow.innerWidth - sidebarWidth - maxSize;
                expect(editorWidthAtMax).toBeGreaterThanOrEqual(100);

                // maxSize should also not exceed 75% of window width
                expect(maxSize).toBeLessThanOrEqual(testWindow.innerWidth * 0.75);
            });
        });

        describe("Plugin panel clamping on window resize", function () {
            let pluginPanel, $toolbarIcon;
            const MIN_WIDTH = 200;

            beforeAll(function () {
                $toolbarIcon = _$('<a id="test-clamp-icon" href="#"></a>');
                _$("#plugin-icons-bar").append($toolbarIcon);

                let panelTemplate = '<div id="test-clamp-panel">Test Panel</div>';
                pluginPanel = WorkspaceManager.createPluginPanel(
                    "test-clamp-panel", _$(panelTemplate), MIN_WIDTH, $toolbarIcon
                );
            });

            afterAll(function () {
                if (pluginPanel) {
                    pluginPanel.hide();
                }
                $toolbarIcon.remove();
            });

            afterEach(function () {
                pluginPanel.hide();
            });

            it("should clamp plugin panel when window resizes smaller", function () {
                pluginPanel.show();
                WorkspaceManager.setPluginPanelWidth(600);

                const $mainToolbar = _$("#main-toolbar");
                const widthBefore = $mainToolbar.width();

                // Simulate a narrow window resize
                const sidebarWidth = _$("#sidebar").outerWidth() || 0;
                const maxAllowed = Math.min(
                    testWindow.innerWidth * 0.75,
                    testWindow.innerWidth - sidebarWidth - 100
                );

                // Only expect clamping if the panel was wider than max
                if (widthBefore > maxAllowed) {
                    testWindow.dispatchEvent(new testWindow.Event("resize"));
                    expect($mainToolbar.width()).toBeLessThanOrEqual(maxAllowed);
                } else {
                    // Panel fits, dispatch resize and verify it stays unchanged
                    testWindow.dispatchEvent(new testWindow.Event("resize"));
                    expect($mainToolbar.width()).toEqual(widthBefore);
                }
            });

            it("should not let toolbar disappear on window resize", function () {
                pluginPanel.show();

                const $mainToolbar = _$("#main-toolbar");
                const $pluginIconsBar = _$("#plugin-icons-bar");

                testWindow.dispatchEvent(new testWindow.Event("resize"));

                // Toolbar must remain at least as wide as the icons bar + panel minWidth
                const minToolbarWidth = MIN_WIDTH + $pluginIconsBar.outerWidth();
                expect($mainToolbar.width()).toBeGreaterThanOrEqual(minToolbarWidth);
            });

            it("should clamp panel width when shown after window was resized", function () {
                // Panel is hidden; compute what the max toolbar width would be
                const sidebarWidth = _$("#sidebar").outerWidth() || 0;
                const maxToolbarWidth = Math.min(
                    testWindow.innerWidth * 0.75,
                    testWindow.innerWidth - sidebarWidth - 100
                );

                // Now show the panel — it should be clamped to maxToolbarWidth
                pluginPanel.show();

                const $mainToolbar = _$("#main-toolbar");
                expect($mainToolbar.width()).toBeLessThanOrEqual(maxToolbarWidth);

                // And content area should match
                const $windowContent = _$(".content");
                const rightOffset = parseInt($windowContent.css("right"), 10);
                expect(rightOffset).toEqual($mainToolbar.width());
            });

            it("should keep content right offset in sync after resize clamp", function () {
                pluginPanel.show();
                WorkspaceManager.setPluginPanelWidth(600);

                testWindow.dispatchEvent(new testWindow.Event("resize"));

                const $mainToolbar = _$("#main-toolbar");
                const $windowContent = _$(".content");
                const rightOffset = parseInt($windowContent.css("right"), 10);
                expect(rightOffset).toEqual($mainToolbar.width());
            });
        });

        describe("Quick Access panel (app drawer button)", function () {
            const DEFAULT_PANEL_ID = "workspace.defaultPanel";

            function getDrawerButton() {
                return _$("#app-drawer-button");
            }

            function isDefaultPanelVisible() {
                return _$("#default-panel").is(":visible");
            }

            function isDrawerSelected() {
                return getDrawerButton().hasClass("selected-button");
            }

            beforeEach(function () {
                // Ensure a clean state: hide any open panels
                const panel = WorkspaceManager.getPanelForID(DEFAULT_PANEL_ID);
                if (panel && panel.isVisible()) {
                    panel.hide();
                }
            });

            it("should have the app-drawer button in the toolbar", function () {
                expect(getDrawerButton().length).toBe(1);
            });

            it("should open Quick Access panel on drawer button click", function () {
                expect(isDefaultPanelVisible()).toBeFalse();

                getDrawerButton().click();

                expect(isDefaultPanelVisible()).toBeTrue();
            });

            it("should show selected state when panel is open", function () {
                expect(isDrawerSelected()).toBeFalse();

                getDrawerButton().click();

                expect(isDrawerSelected()).toBeTrue();
            });

            it("should close Quick Access panel on second click", function () {
                getDrawerButton().click();
                expect(isDefaultPanelVisible()).toBeTrue();
                expect(isDrawerSelected()).toBeTrue();

                getDrawerButton().click();

                expect(isDefaultPanelVisible()).toBeFalse();
                expect(isDrawerSelected()).toBeFalse();
            });

            it("should deselect drawer when another panel opens", async function () {
                getDrawerButton().click();
                expect(isDefaultPanelVisible()).toBeTrue();
                expect(isDrawerSelected()).toBeTrue();

                // Open a different panel (Problems)
                await CommandManager.execute(Commands.VIEW_TOGGLE_PROBLEMS);

                expect(isDefaultPanelVisible()).toBeFalse();
                expect(isDrawerSelected()).toBeFalse();

                // Clean up: close Problems panel
                await CommandManager.execute(Commands.VIEW_TOGGLE_PROBLEMS);
            });
        });
    });
});
