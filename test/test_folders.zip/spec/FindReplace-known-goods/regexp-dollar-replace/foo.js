/* Test comment */
define(function (require, exports, module) {
    [var] [Foo] = require("modules/[Foo]"),
        [Bar] = require("modules/[Bar]"),
        [Baz] = require("modules/[Baz]");
    
    function callFoo() {
        
        [foo]();
        
    }

}
