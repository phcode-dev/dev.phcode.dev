/*
 * GNU AGPL-3.0 License
 *
 * Copyright (c) 2021 - present core.ai . All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see https://opensource.org/licenses/AGPL-3.0.
 *
 */

/*global describe, it, expect, beforeAll, afterAll, beforeEach, afterEach, awaitsFor, awaitsForDone, jsPromise, spyOn */

define(function (require, exports, module) {
    const SpecRunnerUtils = require("spec/SpecRunnerUtils");

    describe("integration:TabBar", function () {
        let testWindow,
            PreferencesManager,
            $,
            FileSystem,
            MainViewManager,
            CommandManager,
            Commands,
            DocumentManager,
            Strings;
        let testFolder, testFilePath, testFilePath2, testFilePath3, testDuplicateDir1, testDuplicateDir2, testDuplicateName;

        /**
         * Helper function to create multiple test files
         * @param {number} count - Number of files to create
         * @param {string} prefix - Prefix for the file names
         * @param {string} content - Content template for the files (will be appended with file index)
         * @returns {Promise<string[]>} - Array of file paths
         */
        async function createTestFiles(count, prefix, content) {
            const testFiles = [];
            for (let i = 0; i < count; i++) {
                const filePath = testFolder + `/${prefix}-${i}.js`;
                testFiles.push(filePath);
                await jsPromise(
                    SpecRunnerUtils.createTextFile(
                        filePath,
                        content ? `${content} ${i}` : `// ${prefix} test file ${i}`,
                        FileSystem
                    )
                );
            }
            return testFiles;
        }

        /**
         * Helper function to open multiple files
         * @param {string[]} filePaths - Array of file paths to open
         * @param {string} [paneId] - Optional pane ID to open the files in
         * @returns {Promise<void>}
         */
        async function openTestFiles(filePaths, paneId) {
            for (const filePath of filePaths) {
                const options = { fullPath: filePath };
                if (paneId) {
                    options.paneId = paneId;
                }
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, options),
                    `Open file ${filePath}${paneId ? ` in ${paneId}` : ""}`
                );
            }
        }

        /**
         * Helper function to add files to a working set and open them, like the file tree double click does
         * @param {string[]} filePaths - Array of file paths to add
         * @param {string} [paneId] - Optional pane ID to add the files to
         * @returns {Promise<void>}
         */
        async function addToWorkingSet(filePaths, paneId) {
            for (const filePath of filePaths) {
                const options = { fullPath: filePath };
                if (paneId) {
                    options.paneId = paneId;
                }
                await awaitsForDone(
                    CommandManager.execute(Commands.CMD_ADD_TO_WORKINGSET_AND_OPEN, options),
                    `Add ${filePath} to the working set`
                );
            }
        }

        /**
         * Helper function to wait for tabs to appear
         * @param {string[]} filePaths - Array of file paths to wait for
         * @param {string} [paneId] - Optional pane ID to check for tabs
         * @returns {Promise<void>}
         */
        async function waitForTabs(filePaths, paneId) {
            if (paneId) {
                // Wait for tabs to appear in the specified pane
                await awaitsFor(
                    function () {
                        return getPaneTabCount(paneId) >= filePaths.length;
                    },
                    `All tabs to appear in ${paneId}`
                );
            } else if (filePaths.length === 1) {
                // Wait for a single tab to appear
                await awaitsFor(
                    function () {
                        return tabExists(filePaths[0]);
                    },
                    `Tab for ${filePaths[0]} to appear`
                );
            } else {
                // Wait for multiple tabs to appear
                await awaitsFor(
                    function () {
                        return getTabCount() >= filePaths.length && filePaths.every((path) => tabExists(path));
                    },
                    "All tabs to appear"
                );
            }
        }

        /**
         * Helper function to cancel the save dialog
         * @returns {void}
         */
        function cancelSaveDialog() {
            testWindow.brackets.test.Dialogs.cancelModalDialogIfOpen(
                testWindow.brackets.test.DefaultDialogs.DIALOG_ID_SAVE_CLOSE,
                testWindow.brackets.test.DefaultDialogs.DIALOG_BTN_DONTSAVE
            );
        }

        /**
         * Helper function to close files
         * @param {string[]} filePaths - Array of file paths to close
         * @param {string} [paneId] - Optional pane ID to close the files from
         * @returns {Promise<void>}
         */
        async function closeTestFiles(filePaths, paneId) {
            for (const filePath of filePaths) {
                const fileToClose = FileSystem.getFileForPath(filePath);
                const options = { file: fileToClose };
                if (paneId) {
                    options.paneId = paneId;
                }
                const promise = CommandManager.execute(Commands.FILE_CLOSE, options);
                cancelSaveDialog();
                await awaitsForDone(promise, `Close file ${filePath}`);
            }
        }

        /**
         * Helper function to simulate drag and drop between tabs
         * @param {string} sourceFilePath - Path of the source file to drag
         * @param {string} targetFilePath - Path of the target file to drop onto
         * @param {boolean} [dropBefore=true] - Whether to drop before the target (true) or after (false)
         * @returns {Promise<void>}
         */
        async function simulateTabDragAndDrop(sourceFilePath, targetFilePath, dropBefore = true) {
            // Get the source and target tabs
            const sourceTab = getTab(sourceFilePath);
            const targetTab = getTab(targetFilePath);

            // Simulate drag start on the source tab
            const dragStartEvent = $.Event("dragstart", {
                originalEvent: {
                    dataTransfer: {
                        setData: function () {},
                        effectAllowed: "move"
                    }
                }
            });
            sourceTab.trigger(dragStartEvent);

            // Simulate dragenter on the target tab
            const dragEnterEvent = $.Event("dragenter");
            targetTab.trigger(dragEnterEvent);

            // Simulate drag over on the target tab
            const targetRect = targetTab[0].getBoundingClientRect();
            const dropX = dropBefore
                ? targetRect.left + 5 // Position near the left edge to drop before
                : targetRect.right - 5; // Position near the right edge to drop after

            const dragOverEvent = $.Event("dragover", {
                originalEvent: {
                    dataTransfer: {
                        dropEffect: "move"
                    },
                    clientX: dropX
                },
                preventDefault: function () {}
            });
            targetTab.trigger(dragOverEvent);

            // Simulate drop on the target tab
            const dropEvent = $.Event("drop", {
                originalEvent: {
                    dataTransfer: {},
                    clientX: dropX
                },
                preventDefault: function () {},
                stopPropagation: function () {}
            });
            targetTab.trigger(dropEvent);

            // Simulate dragend to complete the operation
            const dragEndEvent = $.Event("dragend");
            sourceTab.trigger(dragEndEvent);
        }

        /**
         * Helper function to check if the tab bar for a specific pane is visible
         * @param {string} paneId - The pane ID ("first-pane" or "second-pane")
         * @returns {boolean} - True if the tab bar is visible, false otherwise
         */
        function isTabBarVisible(paneId) {
            const tabBarId = paneId === "first-pane" ? "#phoenix-tab-bar" : "#phoenix-tab-bar-2";
            return $(tabBarId).is(":visible");
        }

        /**
         * Helper function to get the tab count for a specific pane
         * @param {string} paneId - The pane ID ("first-pane" or "second-pane")
         * @returns {number} - The number of tabs in the pane
         */
        function getPaneTabCount(paneId) {
            const tabBarId = paneId === "first-pane" ? "#phoenix-tab-bar" : "#phoenix-tab-bar-2";
            return $(tabBarId).find(".tab").length;
        }

        /**
         * Helper function to check if a tab for a specific file exists in a specific pane
         * @param {string} filePath - The path of the file to check
         * @param {string} paneId - The pane ID ("first-pane" or "second-pane")
         * @returns {boolean} - True if the tab exists in the pane, false otherwise
         */
        function tabExistsInPane(filePath, paneId) {
            const tabBarId = paneId === "first-pane" ? "#phoenix-tab-bar" : "#phoenix-tab-bar-2";
            return $(tabBarId).find(`.tab[data-path="${filePath}"]`).length > 0;
        }

        /**
         * Helper function to get an item of a context menu by its label
         * @param {string} menuId - id of the menu element, like "tabbar-context-menu"
         * @param {string} text - the label of the item
         * @returns {jQuery} - The li element of the item
         */
        function getMenuItemByText(menuId, text) {
            return $(`#${menuId} .menu-name`).filter(function () {
                return $(this).text().trim() === text;
            }).closest("li");
        }

        /**
         * Helper function to open the context menu of a tab, in whichever pane it is
         * @param {jQuery} $tab - the tab element
         * @returns {Promise<void>}
         */
        async function openContextMenuOfTab($tab) {
            expect($tab.length).toBe(1);
            $tab.trigger($.Event("contextmenu", { pageX: 100, pageY: 100 }));
            await awaitsFor(
                function () {
                    return $("#tabbar-context-menu").hasClass("open");
                },
                "Tab context menu to appear"
            );
        }

        /**
         * Helper function to open the context menu of a working set item
         * @param {jQuery} $row - the li element of the item
         * @returns {Promise<void>}
         */
        async function openContextMenuOfWorkingSetItem($row) {
            expect($row.length).toBe(1);
            $row.trigger($.Event("contextmenu", { pageX: 100, pageY: 200, target: $row.find("a")[0] }));
            await awaitsFor(
                function () {
                    return $("#workingset-context-menu").hasClass("open");
                },
                "Working set context menu to appear"
            );
        }

        /**
         * Helper function to get the working set item of a file in a pane's list
         * @param {string} filePath - The path of the file
         * @param {string} paneId - The pane ID ("first-pane" or "second-pane")
         * @returns {jQuery} - The li element of the item
         */
        function getWorkingSetItemInPane(filePath, paneId) {
            return $(`#working-set-list-${paneId} li`).filter(function () {
                const file = $(this).data("file");
                return file && file.fullPath === filePath;
            });
        }

        /**
         * Helper function to get the tab of a file in a pane's tab bar
         * @param {string} filePath - The path of the file
         * @param {string} paneId - The pane ID ("first-pane" or "second-pane")
         * @returns {jQuery} - The tab element
         */
        function getTabInPane(filePath, paneId) {
            const tabBarId = paneId === "first-pane" ? "#phoenix-tab-bar" : "#phoenix-tab-bar-2";
            return $(tabBarId).find(`.tab[data-path="${filePath}"]`);
        }

        /**
         * Helper function to read a file from disk
         * @param {string} filePath - The path of the file
         * @returns {Promise<string>} - The text of the file
         */
        function readFileFromDisk(filePath) {
            return new Promise(function (resolve, reject) {
                FileSystem.getFileForPath(filePath).read(function (err, text) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(text);
                    }
                });
            });
        }

        beforeAll(async function () {
            // Create the test window
            testWindow = await SpecRunnerUtils.createTestWindowAndRun();
            // Get reference to all the required modules
            $ = testWindow.$;
            PreferencesManager = testWindow.brackets.test.PreferencesManager;
            FileSystem = testWindow.brackets.test.FileSystem;
            MainViewManager = testWindow.brackets.test.MainViewManager;
            CommandManager = testWindow.brackets.test.CommandManager;
            Commands = testWindow.brackets.test.Commands;
            DocumentManager = testWindow.brackets.test.DocumentManager;
            Strings = testWindow.Strings;

            // Keep this suite's files separate so cleanup never walks or deletes another suite's fixtures.
            testFolder = SpecRunnerUtils.getTempDirectory() + "/tabbar";

            // Create test files
            testFilePath = testFolder + "/tabbar-test.js";
            testFilePath2 = testFolder + "/tabbar-test2.js";
            testFilePath3 = testFolder + "/tabbar-test3.js";

            // Create files with the same name in different directories for testing duplicate name handling
            testDuplicateDir1 = testFolder + "/dir1";
            testDuplicateDir2 = testFolder + "/dir2";
            testDuplicateName = "duplicate.js";

            await SpecRunnerUtils.ensureExistsDirAsync(testFolder);
            await SpecRunnerUtils.ensureExistsDirAsync(testDuplicateDir1);
            await SpecRunnerUtils.ensureExistsDirAsync(testDuplicateDir2);

            await jsPromise(SpecRunnerUtils.createTextFile(testFilePath, "// Test file 1 for TabBar", FileSystem));
            await jsPromise(SpecRunnerUtils.createTextFile(testFilePath2, "// Test file 2 for TabBar", FileSystem));
            await jsPromise(SpecRunnerUtils.createTextFile(testFilePath3, "// Test file 3 for TabBar", FileSystem));
            await jsPromise(
                SpecRunnerUtils.createTextFile(
                    testDuplicateDir1 + "/" + testDuplicateName,
                    "// Duplicate file 1",
                    FileSystem
                )
            );
            await jsPromise(
                SpecRunnerUtils.createTextFile(
                    testDuplicateDir2 + "/" + testDuplicateName,
                    "// Duplicate file 2",
                    FileSystem
                )
            );

            // Open the first test file
            await awaitsForDone(
                CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                "Open test file"
            );
        }, 30000);

        afterAll(async function () {
            // closeTestWindow closes the files and parks the project before deleting fixtures.
            // Browser IndexedDB cleanup needs the same budget as other integration teardown.
            await SpecRunnerUtils.closeTestWindow();
            await SpecRunnerUtils.deletePathAsync(testFolder, true);
            testWindow = null;
        }, 30000);

        /**
         * Helper function to check if a tab for a specific file exists in the tab bar
         * @param {string} filePath - The path of the file to check
         * @returns {boolean} - True if the tab exists, false otherwise
         */
        function tabExists(filePath) {
            return $(`.tab[data-path="${filePath}"]`).length > 0;
        }

        /**
         * Helper function to count the number of tabs in the tab bar
         * @returns {number} - The number of tabs
         */
        function getTabCount() {
            return $(".tab").length;
        }

        /**
         * Helper function to check if a tab for a specific file is active
         * @param {string} filePath - The path of the file to check
         * @returns {boolean} - True if the tab is active, false otherwise
         */
        function isTabActive(filePath) {
            return $(`.tab[data-path="${filePath}"].active`).length > 0;
        }

        /**
         * Helper function to get the tab element for a specific file
         * @param {string} filePath - The path of the file
         * @returns {jQuery} - The tab element
         */
        function getTab(filePath) {
            return $(`.tab[data-path="${filePath}"]`);
        }

        /**
         * Helper function to check if a tab has a dirty indicator
         * @param {string} filePath - The path of the file to check
         * @returns {boolean} - True if the tab has a dirty indicator, false otherwise
         */
        function isTabDirty(filePath) {
            return getTab(filePath).hasClass("dirty");
        }

        /**
         * Helper function to get the tab name element for a specific file
         * @param {string} filePath - The path of the file
         * @returns {jQuery} - The tab name element
         */
        function getTabName(filePath) {
            return getTab(filePath).find(".tab-name");
        }

        /**
         * Helper function to check if a tab has a directory name displayed
         * @param {string} filePath - The path of the file to check
         * @returns {boolean} - True if the tab has a directory name, false otherwise
         */
        function hasDirectoryName(filePath) {
            return getTab(filePath).find(".tab-dirname").length > 0;
        }

        /**
         * Helper function to get the directory name displayed in a tab
         * @param {string} filePath - The path of the file
         * @returns {string} - The directory name or empty string if not found
         */
        function getDirectoryName(filePath) {
            const $dirName = getTab(filePath).find(".tab-dirname");
            return $dirName.length ? $dirName.text() : "";
        }

        /**
         * Helper function to check if a tab has a file icon
         * @param {string} filePath - The path of the file to check
         * @returns {boolean} - True if the tab has a file icon, false otherwise
         */
        function hasFileIcon(filePath) {
            return getTab(filePath).find(".tab-icon i").length > 0;
        }

        /**
         * Helper function to check if a tab has a git status indicator
         * @param {string} filePath - The path of the file to check
         * @returns {boolean} - True if the tab has a git status indicator, false otherwise
         */
        function hasGitStatus(filePath) {
            return getTab(filePath).hasClass("git-new") || getTab(filePath).hasClass("git-modified");
        }

        /**
         * Helper function to get the tooltip (title attribute) of a tab
         * @param {string} filePath - The path of the file
         * @returns {string} - The tooltip text
         */
        function getTabTooltip(filePath) {
            return getTab(filePath).attr("title") || "";
        }

        /**
         * Helper function to check if a tab has a close button
         * @param {string} filePath - The path of the file to check
         * @returns {boolean} - True if the tab has a close button, false otherwise
         */
        function hasCloseButton(filePath) {
            return getTab(filePath).find(".tab-close").length > 0;
        }

        /**
         * Helper function to check if the overflow button is visible
         * @returns {boolean} - True if the overflow button is visible, false otherwise
         */
        function isOverflowButtonVisible() {
            return $("#overflow-button").is(":visible");
        }

        /**
         * Helper function to get the overflow button element
         * @returns {jQuery} - The overflow button element
         */
        function getOverflowButton() {
            return $("#overflow-button");
        }

        /**
         * Helper function to check if a tab is visible in the tab bar (not hidden by overflow)
         * @param {string} filePath - The path of the file to check
         * @returns {boolean} - True if the tab is visible, false otherwise
         */
        function isTabVisible(filePath) {
            const $tab = getTab(filePath);
            if (!$tab.length) {
                return false;
            }

            const $tabBar = $("#phoenix-tab-bar");
            const tabBarRect = $tabBar[0].getBoundingClientRect();
            const tabRect = $tab[0].getBoundingClientRect();

            // A tab is considered visible if it is completely within the tab bar's visible area
            // with a small margin of error (2px)
            return tabRect.left >= tabBarRect.left && tabRect.right <= tabBarRect.right + 2;
        }

        /**
         * Helper function to get the overflow dropdown menu
         * @returns {jQuery} - The overflow dropdown menu element
         */
        function getOverflowDropdown() {
            return $(".dropdown-overflow-menu");
        }

        /**
         * Helper function to get the items in the overflow dropdown
         * @returns {jQuery} - The overflow dropdown items
         */
        function getOverflowDropdownItems() {
            return $(".dropdown-overflow-menu .dropdown-tab-item");
        }

        /**
         * Helper function to get a specific item in the overflow dropdown by file path
         * @param {string} filePath - The path of the file to find
         * @returns {jQuery} - The dropdown item element
         */
        function getOverflowDropdownItem(filePath) {
            return $(`.dropdown-overflow-menu .dropdown-tab-item[data-tab-path="${filePath}"]`);
        }

        describe("Visibility", function () {
            it("should show tab bar when the feature is enabled", async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Wait for the tab bar to become visible
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar").is(":visible");
                    },
                    "Tab bar to become visible"
                );
            });

            it("should hide tab bar when the feature is disabled", async function () {
                // Disable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: false, numberOfTabs: -1 });

                // Wait for the tab bar to become hidden
                await awaitsFor(
                    function () {
                        return !$("#phoenix-tab-bar").is(":visible");
                    },
                    "Tab bar to become hidden"
                );
            });

            it("should show working set when the option is enabled", async function () {
                // Enable the working set feature
                PreferencesManager.set("showWorkingSet", true);

                // Wait for the working set to become visible
                await awaitsFor(
                    function () {
                        return !$("#working-set-list-container").hasClass("working-set-hidden");
                    },
                    "Working set to become visible"
                );
            });

            it("should hide working set when the option is disabled", async function () {
                // Disable the working set feature
                PreferencesManager.set("showWorkingSet", false);

                // Wait for the working set to become hidden
                await awaitsFor(
                    function () {
                        return $("#working-set-list-container").hasClass("working-set-hidden");
                    },
                    "Working set to become hidden"
                );
            });
        });

        describe("Configure Working Set Button", function () {
            it("should have a working set configuration button in the sidebar", function () {
                // Verify the button exists
                const $configButton = $(".working-set-splitview-btn");
                expect($configButton.length).toBe(1);
            });

            it("should open a menu with 'Show working set' and 'Show file tab bar' options when clicked", async function () {
                // Click the configure working set button
                const $configButton = $(".working-set-splitview-btn");
                $configButton.click();

                // Wait for the menu to appear
                await awaitsFor(
                    function () {
                        return $(".dropdown-menu:visible").length > 0;
                    },
                    "Context menu to appear"
                );

                // Verify the menu contains the expected options
                const $menu = $(".dropdown-menu:visible");
                const showWorkingSetItem = $menu.find("li a[id$='cmd.toggleShowWorkingSet']");
                const showFileTabsItem = $menu.find("li a[id$='cmd.toggleShowFileTabs']");

                expect(showWorkingSetItem.length).toBe(1);
                expect(showFileTabsItem.length).toBe(1);

                // Clean up - close the menu
                $("body").click();
            });

            it("should toggle working set visibility when 'Show working set' option is clicked", async function () {
                // First, ensure working set is visible
                PreferencesManager.set("showWorkingSet", true);
                await awaitsFor(
                    function () {
                        return !$("#working-set-list-container").hasClass("working-set-hidden");
                    },
                    "Working set to become visible"
                );

                // Click the configure working set button
                const $configButton = $(".working-set-splitview-btn");
                $configButton.click();

                // Wait for the menu to appear
                await awaitsFor(
                    function () {
                        return $(".dropdown-menu:visible").length > 0;
                    },
                    "Context menu to appear"
                );

                // Click the "Show working set" option
                const $menu = $(".dropdown-menu:visible");
                const showWorkingSetItem = $menu.find("li a[id$='cmd.toggleShowWorkingSet']");
                showWorkingSetItem.click();

                // Wait for the working set to become hidden
                await awaitsFor(
                    function () {
                        return $("#working-set-list-container").hasClass("working-set-hidden");
                    },
                    "Working set to become hidden"
                );

                // Click the configure working set button again
                $configButton.click();

                // Wait for the menu to appear
                await awaitsFor(
                    function () {
                        return $(".dropdown-menu:visible").length > 0;
                    },
                    "Context menu to appear"
                );

                // Click the "Show working set" option again
                const $menu2 = $(".dropdown-menu:visible");
                const showWorkingSetItem2 = $menu2.find("li a[id$='cmd.toggleShowWorkingSet']");
                showWorkingSetItem2.click();

                // Wait for the working set to become visible
                await awaitsFor(
                    function () {
                        return !$("#working-set-list-container").hasClass("working-set-hidden");
                    },
                    "Working set to become visible"
                );
            });

            it("should toggle tab bar visibility when 'Show file tab bar' option is clicked", async function () {
                // First, ensure tab bar is visible
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar").is(":visible");
                    },
                    "Tab bar to become visible"
                );

                // Click the configure working set button
                const $configButton = $(".working-set-splitview-btn");
                $configButton.click();

                // Wait for the menu to appear
                await awaitsFor(
                    function () {
                        return $(".dropdown-menu:visible").length > 0;
                    },
                    "Context menu to appear"
                );

                // Click the "Show file tab bar" option
                const $menu = $(".dropdown-menu:visible");
                const showFileTabsItem = $menu.find("li a[id$='cmd.toggleShowFileTabs']");
                showFileTabsItem.click();

                // Wait for the tab bar to become hidden
                await awaitsFor(
                    function () {
                        return !$("#phoenix-tab-bar").is(":visible");
                    },
                    "Tab bar to become hidden"
                );

                // Click the configure working set button again
                $configButton.click();

                // Wait for the menu to appear
                await awaitsFor(
                    function () {
                        return $(".dropdown-menu:visible").length > 0;
                    },
                    "Context menu to appear"
                );

                // Click the "Show file tab bar" option again
                const $menu2 = $(".dropdown-menu:visible");
                const showFileTabsItem2 = $menu2.find("li a[id$='cmd.toggleShowFileTabs']");
                showFileTabsItem2.click();

                // Wait for the tab bar to become visible
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar").is(":visible");
                    },
                    "Tab bar to become visible"
                );
            });
        });

        describe("Drag and Drop", function () {
            beforeEach(async function () {
                // Close all files and reset to single pane
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);

                // Wait for cleanup to complete
                await awaitsFor(
                    function () {
                        return MainViewManager.getPaneCount() === 1 && getTabCount() === 0;
                    },
                    "Cleanup to complete with single pane and no tabs"
                );
            });

            it("should allow dragging and dropping a tab to the beginning of the tab bar", async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();

                // Create and open multiple test files to work with
                const testFiles = await createTestFiles(3, "drag-drop-test", "// Drag drop test file");
                await openTestFiles(testFiles);
                await waitForTabs(testFiles);

                // Verify initial tab order
                const initialWorkingSet = MainViewManager.getWorkingSet("first-pane");
                expect(initialWorkingSet.length).toBe(testFiles.length);
                expect(initialWorkingSet[0].fullPath).toBe(testFiles[0]);
                expect(initialWorkingSet[1].fullPath).toBe(testFiles[1]);
                expect(initialWorkingSet[2].fullPath).toBe(testFiles[2]);

                // Simulate drag and drop from first tab to last tab
                await simulateTabDragAndDrop(testFiles[0], testFiles[2], true);

                // Wait for the working set to update
                await awaitsFor(
                    function () {
                        const currentWorkingSet = MainViewManager.getWorkingSet("first-pane");
                        // Check if the first file has moved to before the last file
                        return (
                            currentWorkingSet.length === testFiles.length &&
                            currentWorkingSet[1].fullPath === testFiles[0]
                        );
                    },
                    "Working set to update after drag and drop"
                );

                // Verify the new tab order
                const finalWorkingSet = MainViewManager.getWorkingSet("first-pane");
                expect(finalWorkingSet.length).toBe(testFiles.length);
                expect(finalWorkingSet[0].fullPath).toBe(testFiles[1]);
                expect(finalWorkingSet[1].fullPath).toBe(testFiles[0]);
                expect(finalWorkingSet[2].fullPath).toBe(testFiles[2]);

                // Clean up - close all the test files
                await closeTestFiles(testFiles);
            });

            it("should allow dragging and dropping a tab in between other tabs", async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();

                // Create and open multiple test files to work with
                const testFiles = await createTestFiles(3, "drag-between-test", "// Drag between test file");
                await openTestFiles(testFiles);
                await waitForTabs(testFiles);

                // Verify initial tab order
                const initialWorkingSet = MainViewManager.getWorkingSet("first-pane");
                expect(initialWorkingSet.length).toBe(testFiles.length);
                expect(initialWorkingSet[0].fullPath).toBe(testFiles[0]);
                expect(initialWorkingSet[1].fullPath).toBe(testFiles[1]);
                expect(initialWorkingSet[2].fullPath).toBe(testFiles[2]);

                // Simulate drag and drop from last tab to before the middle tab
                await simulateTabDragAndDrop(testFiles[2], testFiles[1], true);

                // Wait for the working set to update
                await awaitsFor(
                    function () {
                        const currentWorkingSet = MainViewManager.getWorkingSet("first-pane");
                        // Check if the last file has moved to between the first and second files
                        return (
                            currentWorkingSet.length === testFiles.length &&
                            currentWorkingSet[1].fullPath === testFiles[2]
                        );
                    },
                    "Working set to update after drag and drop"
                );

                // Verify the new tab order
                const finalWorkingSet = MainViewManager.getWorkingSet("first-pane");
                expect(finalWorkingSet.length).toBe(testFiles.length);
                expect(finalWorkingSet[0].fullPath).toBe(testFiles[0]);
                expect(finalWorkingSet[1].fullPath).toBe(testFiles[2]); // Last tab should now be in the middle
                expect(finalWorkingSet[2].fullPath).toBe(testFiles[1]); // Middle tab should now be last

                // Clean up - close all the test files
                await closeTestFiles(testFiles);
            });

            it("should allow dragging a tab from one pane to another non-empty pane", async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();

                // Set up a horizontal split view (two columns)
                MainViewManager.setLayoutScheme(1, 2);

                // Create test files for both panes
                const firstPaneFiles = await createTestFiles(2, "first-pane-test", "// First pane test file");
                const secondPaneFiles = await createTestFiles(2, "second-pane-test", "// Second pane test file");

                // Open files in both panes
                await openTestFiles(firstPaneFiles, "first-pane");
                await openTestFiles(secondPaneFiles, "second-pane");

                // Wait for all tabs to appear in both panes
                await waitForTabs(firstPaneFiles, "first-pane");
                await waitForTabs(secondPaneFiles, "second-pane");

                // Verify initial tab counts
                expect(getPaneTabCount("first-pane")).toBe(firstPaneFiles.length);
                expect(getPaneTabCount("second-pane")).toBe(secondPaneFiles.length);

                // Get the source tab from the first pane and target tab from the second pane
                const sourceTab = $(`.tab[data-path="${firstPaneFiles[0]}"]`);
                const targetTab = $(`.tab[data-path="${secondPaneFiles[0]}"]`);

                // Simulate drag start on the source tab
                const dragStartEvent = $.Event("dragstart", {
                    originalEvent: {
                        dataTransfer: {
                            setData: function () {},
                            effectAllowed: "move"
                        }
                    }
                });
                sourceTab.trigger(dragStartEvent);

                // Simulate dragenter on the target tab
                const dragEnterEvent = $.Event("dragenter");
                targetTab.trigger(dragEnterEvent);

                // Simulate drag over on the target tab
                const dragOverEvent = $.Event("dragover", {
                    originalEvent: {
                        dataTransfer: {
                            dropEffect: "move"
                        },
                        clientX: targetTab[0].getBoundingClientRect().left + 5 // Position near the left edge
                    },
                    preventDefault: function () {}
                });
                targetTab.trigger(dragOverEvent);

                // Simulate drop on the target tab
                const dropEvent = $.Event("drop", {
                    originalEvent: {
                        dataTransfer: {},
                        clientX: targetTab[0].getBoundingClientRect().left + 5 // Position near the left edge
                    },
                    preventDefault: function () {},
                    stopPropagation: function () {}
                });
                targetTab.trigger(dropEvent);

                // Simulate dragend to complete the operation
                const dragEndEvent = $.Event("dragend");
                sourceTab.trigger(dragEndEvent);

                // Wait for the tab to move to the second pane
                await awaitsFor(
                    function () {
                        return (
                            !tabExistsInPane(firstPaneFiles[0], "first-pane") &&
                            tabExistsInPane(firstPaneFiles[0], "second-pane")
                        );
                    },
                    "Tab to move from first pane to second pane"
                );

                // Verify the tab counts after the drag and drop
                expect(getPaneTabCount("first-pane")).toBe(firstPaneFiles.length - 1);
                expect(getPaneTabCount("second-pane")).toBe(secondPaneFiles.length + 1);

                // Clean up - close all files and reset to single pane
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
            });

            it("should allow dragging a tab to an empty pane", async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();

                // Set up a horizontal split view (two columns)
                MainViewManager.setLayoutScheme(1, 2);

                // Wait for layout to settle
                await awaitsFor(
                    function () {
                        return MainViewManager.getPaneCount() === 2;
                    },
                    "Layout to settle with two panes"
                );

                // Verify both panes are empty
                expect(MainViewManager.getWorkingSet("first-pane").length).toBe(0);
                expect(MainViewManager.getWorkingSet("second-pane").length).toBe(0);

                // Create test files for the first pane
                const firstPaneFiles = await createTestFiles(
                    2,
                    "first-pane-empty-test",
                    "// First pane empty test file"
                );

                // Open files in the first pane only
                await openTestFiles(firstPaneFiles, "first-pane");

                // Wait for all tabs to appear in the first pane
                await waitForTabs(firstPaneFiles, "first-pane");

                // Verify initial state: first pane has tabs, second pane is empty
                expect(getPaneTabCount("first-pane")).toBe(firstPaneFiles.length);

                // If the second pane has tabs, log what they are and close them
                if (getPaneTabCount("second-pane") > 0) {
                    const secondPaneWorkingSet = MainViewManager.getWorkingSet("second-pane");
                    for (const file of secondPaneWorkingSet) {
                        await awaitsForDone(
                            CommandManager.execute(Commands.FILE_CLOSE, { file: file, paneId: "second-pane" }),
                            `Force close file ${file.fullPath} in second pane`
                        );
                    }

                    // Wait for the second pane to be empty
                    await awaitsFor(
                        function () {
                            return getPaneTabCount("second-pane") === 0;
                        },
                        "Second pane to be empty after cleanup"
                    );
                }

                expect(getPaneTabCount("second-pane")).toBe(0);
                expect(isTabBarVisible("second-pane")).toBe(false);

                // Get the source tab from the first pane
                const sourceTab = $(`.tab[data-path="${firstPaneFiles[0]}"]`);
                expect(sourceTab.length).toBe(1, "Source tab should exist in the first pane");

                // Get the empty pane content area as the drop target
                const emptyPaneTarget = $("#second-pane .pane-content");
                expect(emptyPaneTarget.length).toBe(1, "Empty pane target should exist");

                // Simulate drag and drop
                try {
                    // Simulate drag start
                    const dragStartEvent = $.Event("dragstart", {
                        originalEvent: {
                            dataTransfer: {
                                setData: function () {},
                                effectAllowed: "move"
                            }
                        }
                    });
                    sourceTab.trigger(dragStartEvent);

                    // Simulate dragenter
                    const dragEnterEvent = $.Event("dragenter");
                    emptyPaneTarget.trigger(dragEnterEvent);

                    // Simulate dragover
                    const dragOverEvent = $.Event("dragover", {
                        originalEvent: {
                            dataTransfer: {
                                dropEffect: "move"
                            }
                        },
                        preventDefault: function () {}
                    });
                    emptyPaneTarget.trigger(dragOverEvent);

                    // Simulate drop
                    const dropEvent = $.Event("drop", {
                        originalEvent: {
                            dataTransfer: {}
                        },
                        preventDefault: function () {},
                        stopPropagation: function () {}
                    });
                    emptyPaneTarget.trigger(dropEvent);

                    // Simulate dragend
                    const dragEndEvent = $.Event("dragend");
                    sourceTab.trigger(dragEndEvent);
                } catch (e) {
                    console.error("Error during drag and drop simulation:", e);
                    throw e;
                }

                // Wait for the tab to move to the second pane
                await awaitsFor(
                    function () {
                        return (
                            !tabExistsInPane(firstPaneFiles[0], "first-pane") &&
                            tabExistsInPane(firstPaneFiles[0], "second-pane") &&
                            isTabBarVisible("second-pane")
                        );
                    },
                    "Tab to move from first pane to second pane and tab bar to appear"
                );

                // Verify the tab counts after the drag and drop
                expect(getPaneTabCount("first-pane")).toBe(firstPaneFiles.length - 1);
                expect(getPaneTabCount("second-pane")).toBe(1);

                // Clean up - close all files and reset to single pane
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
            });
        });

        describe("Working Set", function () {
            beforeEach(async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();

                // Wait for the tab bar to update
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar").length > 0 && getTabCount() === 0;
                    },
                    "Tab bar to update with no tabs"
                );
            });

            it("should add tabs when files are added to the working set", async function () {
                // Open the first test file and wait for its tab to appear
                await openTestFiles([testFilePath]);
                await waitForTabs([testFilePath]);

                // Verify the tab exists
                expect(tabExists(testFilePath)).toBe(true);
                expect(getTabCount()).toBe(1);

                // Open the second test file and wait for its tab to appear
                await openTestFiles([testFilePath2]);
                await waitForTabs([testFilePath2]);

                // Verify both tabs exist
                expect(tabExists(testFilePath)).toBe(true);
                expect(tabExists(testFilePath2)).toBe(true);
                expect(getTabCount()).toBe(2);

                // Open the third test file and wait for its tab to appear
                await openTestFiles([testFilePath3]);
                await waitForTabs([testFilePath3]);

                // Verify all three tabs exist
                expect(tabExists(testFilePath)).toBe(true);
                expect(tabExists(testFilePath2)).toBe(true);
                expect(tabExists(testFilePath3)).toBe(true);
                expect(getTabCount()).toBe(3);
            });

            it("should remove tabs when files are removed from the working set", async function () {
                // Open all three test files
                const testFiles = [testFilePath, testFilePath2, testFilePath3];
                await openTestFiles(testFiles);
                await waitForTabs(testFiles);

                // Verify all three tabs exist
                expect(getTabCount()).toBe(3);

                // Close the second test file
                await closeTestFiles([testFilePath2]);

                // Wait for the tab to disappear
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath2);
                    },
                    "Tab for second file to disappear"
                );

                // Verify the second tab is removed
                expect(tabExists(testFilePath)).toBe(true);
                expect(tabExists(testFilePath2)).toBe(false);
                expect(tabExists(testFilePath3)).toBe(true);
                expect(getTabCount()).toBe(2);

                // Close the first test file
                await closeTestFiles([testFilePath]);

                // Wait for the tab to disappear
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath);
                    },
                    "Tab for first file to disappear"
                );

                // Verify the first tab is removed
                expect(tabExists(testFilePath)).toBe(false);
                expect(tabExists(testFilePath2)).toBe(false);
                expect(tabExists(testFilePath3)).toBe(true);
                expect(getTabCount()).toBe(1);

                // Close the third test file
                await closeTestFiles([testFilePath3]);

                // Wait for the tab to disappear
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath3);
                    },
                    "Tab for third file to disappear"
                );

                // Verify all tabs are removed
                expect(tabExists(testFilePath)).toBe(false);
                expect(tabExists(testFilePath2)).toBe(false);
                expect(tabExists(testFilePath3)).toBe(false);
                expect(getTabCount()).toBe(0);
            });
        });

        describe("Tab Reuse", function () {
            beforeEach(async function () {
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });
                await testWindow.closeAllFiles();
                await awaitsFor(
                    function () {
                        return getTabCount() === 0;
                    },
                    "Tab bar to update with no tabs"
                );
            });

            it("should keep the existing tab elements when files are opened, switched and closed", async function () {
                await openTestFiles([testFilePath]);
                await waitForTabs([testFilePath]);
                const firstTab = getTab(testFilePath)[0];

                // opening another file only adds a tab, the existing one is left alone
                await openTestFiles([testFilePath2]);
                await waitForTabs([testFilePath, testFilePath2]);
                await awaitsFor(
                    function () {
                        return isTabActive(testFilePath2);
                    },
                    "Second tab to become active"
                );
                const secondTab = getTab(testFilePath2)[0];
                expect(getTab(testFilePath)[0]).toBe(firstTab);

                // switching files moves the active marker, the tabs stay the same elements
                await openTestFiles([testFilePath]);
                await awaitsFor(
                    function () {
                        return isTabActive(testFilePath);
                    },
                    "First tab to become active"
                );
                expect(getTab(testFilePath)[0]).toBe(firstTab);
                expect(getTab(testFilePath2)[0]).toBe(secondTab);

                // a dirty flag change only toggles a class on the tab
                const doc = DocumentManager.getOpenDocumentForPath(testFilePath);
                doc.setText("// Modified content");
                await awaitsFor(
                    function () {
                        return isTabDirty(testFilePath);
                    },
                    "Dirty indicator to appear"
                );
                expect(getTab(testFilePath)[0]).toBe(firstTab);
                doc.setText("// Test file 1 for TabBar");
                await awaitsForDone(CommandManager.execute(Commands.FILE_SAVE, { doc: doc }), "Save file");

                // closing a file removes just its tab
                await closeTestFiles([testFilePath2]);
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath2);
                    },
                    "Second tab to disappear"
                );
                expect(getTab(testFilePath)[0]).toBe(firstTab);
            });
        });

        describe("Active Tab", function () {
            beforeEach(async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();

                // Open all three test files
                const testFiles = [testFilePath, testFilePath2, testFilePath3];
                await openTestFiles(testFiles);
                await waitForTabs(testFiles);
            });

            it("should change active tab when switching files in the working set", async function () {
                // Helper function to switch to a file and verify it's active
                async function switchToFileAndVerify(filePath, description) {
                    // Switch to the file
                    await openTestFiles([filePath]);

                    // Wait for the tab to become active
                    await awaitsFor(
                        function () {
                            return isTabActive(filePath);
                        },
                        `${description} to become active`
                    );

                    // Verify this tab is active and others are not
                    expect(isTabActive(testFilePath)).toBe(filePath === testFilePath);
                    expect(isTabActive(testFilePath2)).toBe(filePath === testFilePath2);
                    expect(isTabActive(testFilePath3)).toBe(filePath === testFilePath3);
                }

                // Test switching to each file
                await switchToFileAndVerify(testFilePath, "First tab");
                await switchToFileAndVerify(testFilePath2, "Second tab");
                await switchToFileAndVerify(testFilePath3, "Third tab");
            });

            it("should display active tab correctly based on the active file in the working set", async function () {
                // Get the currently active file
                const activeFile = MainViewManager.getCurrentlyViewedFile();

                // Wait for tab bar to be recreated and reflect the active file
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar").length > 0 && activeFile && isTabActive(activeFile.fullPath);
                    },
                    "Tab bar to be recreated and show active file"
                );

                // Verify the tab for the active file is active
                expect(isTabActive(activeFile.fullPath)).toBe(true);

                // Switch to a different file
                await openTestFiles([testFilePath2]);

                // Get the new active file
                const newActiveFile = MainViewManager.getCurrentlyViewedFile();

                // Wait for tab bar to update with the new active file
                await awaitsFor(
                    function () {
                        return newActiveFile && isTabActive(newActiveFile.fullPath);
                    },
                    "Tab bar to update with new active file"
                );

                // Verify the tab for the new active file is active
                expect(isTabActive(newActiveFile.fullPath)).toBe(true);

                // Verify the tab for the previous active file is no longer active
                expect(isTabActive(activeFile.fullPath)).toBe(false);
            });

            it("should switch files properly when different tabs are clicked", async function () {
                // Helper function to click a tab and verify it becomes active
                async function clickTabAndVerify(filePath, description) {
                    const $tab = getTab(filePath);
                    expect($tab.length).toBe(1);
                    $tab.trigger("mousedown");

                    // Wait for the file to become active
                    await awaitsFor(
                        function () {
                            return (
                                isTabActive(filePath) && MainViewManager.getCurrentlyViewedFile().fullPath === filePath
                            );
                        },
                        `${description} to become active after tab click`
                    );

                    // Verify this tab is active and others are not
                    const allPaths = [testFilePath, testFilePath2, testFilePath3];
                    allPaths.forEach((path) => {
                        expect(isTabActive(path)).toBe(path === filePath);
                    });

                    // Verify the correct file is loaded in the editor
                    expect(MainViewManager.getCurrentlyViewedFile().fullPath).toBe(filePath);
                }
                // Wait for the tab bar to be properly loaded
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar").length > 0 && getTabCount() === 3;
                    },
                    "Tab bar to be properly loaded with all tabs"
                );

                // Wait for the third file to become active
                await awaitsFor(
                    function () {
                        return (
                            isTabActive(testFilePath3) &&
                            MainViewManager.getCurrentlyViewedFile() &&
                            MainViewManager.getCurrentlyViewedFile().fullPath === testFilePath3
                        );
                    },
                    "Third file to become active"
                );

                // Initially, verify the third file is active (last opened)
                expect(isTabActive(testFilePath3)).toBe(true);
                expect(MainViewManager.getCurrentlyViewedFile().fullPath).toBe(testFilePath3);

                // Test clicking on each tab
                await clickTabAndVerify(testFilePath, "First file");
                await clickTabAndVerify(testFilePath2, "Second file");
                await clickTabAndVerify(testFilePath3, "Third file");

                // Click back on the first tab to ensure it still works
                await clickTabAndVerify(testFilePath, "First file");
            });
        });

        describe("Overflow", function () {
            beforeEach(async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();
            });

            it("should show overflow button when there are too many tabs to fit", async function () {
                // Create several test files to ensure overflow
                const testFiles = await createTestFiles(15, "overflow-test", "// Overflow test file");

                // Open all the test files
                await openTestFiles(testFiles);

                // Wait for all tabs to appear
                await waitForTabs(testFiles);

                // Wait for the overflow button to appear
                await awaitsFor(
                    function () {
                        return isOverflowButtonVisible();
                    },
                    "Overflow button to appear"
                );

                // Verify the overflow button is visible
                expect(isOverflowButtonVisible()).toBe(true);

                // Verify that some tabs are not visible
                let visibleTabs = 0;
                let hiddenTabs = 0;
                for (const filePath of testFiles) {
                    if (isTabVisible(filePath)) {
                        visibleTabs++;
                    } else {
                        hiddenTabs++;
                    }
                }

                // There should be at least one hidden tab
                expect(hiddenTabs).toBeGreaterThan(0);
                expect(visibleTabs + hiddenTabs).toBe(testFiles.length);

                // Clean up - close all the test files
                await closeTestFiles(testFiles);
            });

            it("should display dropdown with hidden tabs when overflow button is clicked", async function () {
                // Create several test files to ensure overflow
                const testFiles = await createTestFiles(15, "overflow-test", "// Overflow test file");

                // Open all the test files
                await openTestFiles(testFiles);

                // Wait for all tabs to appear
                await waitForTabs(testFiles);

                // Wait for the overflow button to appear
                await awaitsFor(
                    function () {
                        return isOverflowButtonVisible();
                    },
                    "Overflow button to appear"
                );

                // Get the list of hidden tabs
                const hiddenFiles = testFiles.filter((filePath) => !isTabVisible(filePath));
                expect(hiddenFiles.length).toBeGreaterThan(0);

                // Click the overflow button
                getOverflowButton().click();

                // Wait for the dropdown to appear
                await awaitsFor(
                    function () {
                        return getOverflowDropdown().length > 0;
                    },
                    "Overflow dropdown to appear"
                );

                // Verify the dropdown is visible
                expect(getOverflowDropdown().length).toBeGreaterThan(0);

                // Verify the dropdown contains items for all hidden tabs
                const dropdownItems = getOverflowDropdownItems();
                expect(dropdownItems.length).toBe(hiddenFiles.length);

                // Verify each hidden file has an item in the dropdown
                for (const filePath of hiddenFiles) {
                    const item = getOverflowDropdownItem(filePath);
                    expect(item.length).toBe(1);
                }

                // Clean up - close the dropdown by clicking elsewhere
                $("body").click();

                // Wait for the dropdown to disappear
                await awaitsFor(
                    function () {
                        return getOverflowDropdown().length === 0;
                    },
                    "Overflow dropdown to disappear"
                );

                // Clean up - close all the test files
                await closeTestFiles(testFiles);
            });

            it("should make tab visible and file active when clicking on item in overflow dropdown", async function () {
                // Create several test files to ensure overflow
                const testFiles = await createTestFiles(15, "overflow-test", "// Overflow test file");

                // Open all the test files
                await openTestFiles(testFiles);

                // Wait for all tabs to appear
                await waitForTabs(testFiles);

                // Wait for the overflow button to appear
                await awaitsFor(
                    function () {
                        return isOverflowButtonVisible();
                    },
                    "Overflow button to appear"
                );

                // Get the list of hidden tabs
                const hiddenFiles = testFiles.filter((filePath) => !isTabVisible(filePath));
                expect(hiddenFiles.length).toBeGreaterThan(0);

                // Select a hidden file to test
                const testHiddenFile = hiddenFiles[0];

                // Click the overflow button
                getOverflowButton().click();

                // Wait for the dropdown to appear
                await awaitsFor(
                    function () {
                        return getOverflowDropdown().length > 0;
                    },
                    "Overflow dropdown to appear"
                );

                // Get the dropdown item for the test file
                const dropdownItem = getOverflowDropdownItem(testHiddenFile);
                expect(dropdownItem.length).toBe(1);

                // Click the dropdown item
                dropdownItem.click();

                // Wait for the file to become active
                await awaitsFor(
                    function () {
                        return (
                            isTabActive(testHiddenFile) &&
                            MainViewManager.getCurrentlyViewedFile().fullPath === testHiddenFile
                        );
                    },
                    "Hidden file to become active after dropdown item click"
                );

                // Verify the file is active
                expect(isTabActive(testHiddenFile)).toBe(true);
                expect(MainViewManager.getCurrentlyViewedFile().fullPath).toBe(testHiddenFile);

                // Verify the tab is now visible (scrolled into view)
                await awaitsFor(
                    function () {
                        return isTabVisible(testHiddenFile);
                    },
                    "Tab to become visible after dropdown item click"
                );

                expect(isTabVisible(testHiddenFile)).toBe(true);

                // Clean up - close all the test files
                await closeTestFiles(testFiles);
            });

            it("should hide the overflow button once the tabs fit and never open an empty menu", async function () {
                const testFiles = await createTestFiles(15, "overflow-test", "// Overflow test file");
                await openTestFiles(testFiles);
                await waitForTabs(testFiles);
                await awaitsFor(
                    function () {
                        return isOverflowButtonVisible();
                    },
                    "Overflow button to appear"
                );

                await closeTestFiles(testFiles.slice(3));
                await awaitsFor(
                    function () {
                        return getTabCount() === 3 && !isOverflowButtonVisible();
                    },
                    "Overflow button to hide once the tabs fit"
                );

                // the click handler of the button is still there, but with no hidden tab there is no menu to show
                expect(getOverflowDropdown().length).toBe(0);
                getOverflowButton().click();
                expect(getOverflowDropdown().length).toBe(0);

                await closeTestFiles(testFiles.slice(0, 3));
            });

            it("should scroll tab bar to make selected file visible when selecting from working set", async function () {
                // Create several test files to ensure overflow
                const testFiles = await createTestFiles(15, "overflow-test", "// Overflow test file");

                // Open all the test files
                await openTestFiles(testFiles);

                // Wait for all tabs to appear
                await waitForTabs(testFiles);

                // Wait for the overflow button to appear
                await awaitsFor(
                    function () {
                        return isOverflowButtonVisible();
                    },
                    "Overflow button to appear"
                );

                // Get the list of hidden tabs
                const hiddenFiles = testFiles.filter((filePath) => !isTabVisible(filePath));
                expect(hiddenFiles.length).toBeGreaterThan(0);

                // Select a hidden file to test
                const testHiddenFile = hiddenFiles[0];

                // Verify the tab is not visible initially
                expect(isTabVisible(testHiddenFile)).toBe(false);

                // Select the file directly from the working set (not using the overflow dropdown)
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testHiddenFile }),
                    "Open hidden file from working set"
                );

                // Wait for the file to become active
                await awaitsFor(
                    function () {
                        return (
                            isTabActive(testHiddenFile) &&
                            MainViewManager.getCurrentlyViewedFile().fullPath === testHiddenFile
                        );
                    },
                    "Hidden file to become active after selection from working set"
                );

                // Verify the file is active
                expect(isTabActive(testHiddenFile)).toBe(true);
                expect(MainViewManager.getCurrentlyViewedFile().fullPath).toBe(testHiddenFile);

                // Verify the tab is now visible (scrolled into view)
                await awaitsFor(
                    function () {
                        return isTabVisible(testHiddenFile);
                    },
                    "Tab to become visible after selection from working set"
                );

                expect(isTabVisible(testHiddenFile)).toBe(true);

                // Clean up - close all the test files
                await closeTestFiles(testFiles);
            });
        });

        describe("Tab Items", function () {
            beforeEach(async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();
            });

            it("should display the correct tab name", async function () {
                // Open the first test file
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open test file"
                );

                // Wait for the tab to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath);
                    },
                    "Tab to appear"
                );

                // Get the filename from the path
                const fileName = testFilePath.split("/").pop();

                // Verify the tab name is correct
                expect(getTabName(testFilePath).text()).toBe(fileName);
            });

            it("should display a file icon", async function () {
                // Open the first test file
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open test file"
                );

                // Wait for the tab to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath);
                    },
                    "Tab to appear"
                );

                // Verify the tab has a file icon
                expect(hasFileIcon(testFilePath)).toBe(true);
            });

            it("should draw the icons of a provider registered after the tabs were made", async function () {
                await openTestFiles([testFilePath]);
                await waitForTabs([testFilePath]);
                expect(getTab(testFilePath).find(".late-test-icon").length).toBe(0);

                // a provider can't be unregistered, so it is switched off again once the spec is done
                let lateIconActive = true;
                testWindow.brackets.test.WorkingSetView.addIconProvider(function (data) {
                    if (lateIconActive && data.fullPath === testFilePath) {
                        return "<i class='late-test-icon'></i>";
                    }
                }, 100);
                await awaitsFor(
                    function () {
                        return getTab(testFilePath).find(".late-test-icon").length === 1;
                    },
                    "Late icon provider to draw on the existing tab"
                );
                lateIconActive = false;
            });

            it("should display a dirty indicator when the file is modified and remove it when saved", async function () {
                // Open the first test file
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open test file"
                );

                // Wait for the tab to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath);
                    },
                    "Tab to appear"
                );

                // Initially, the file should not be dirty
                expect(isTabDirty(testFilePath)).toBe(false);

                // Get the document and modify it
                const doc = DocumentManager.getOpenDocumentForPath(testFilePath);
                doc.setText("// Modified content");

                // Wait for the dirty indicator to appear
                await awaitsFor(
                    function () {
                        return isTabDirty(testFilePath);
                    },
                    "Dirty indicator to appear"
                );

                // Verify the tab has a dirty indicator
                expect(isTabDirty(testFilePath)).toBe(true);

                // Save the file
                await awaitsForDone(CommandManager.execute(Commands.FILE_SAVE, { doc: doc }), "Save file");

                // Wait for the dirty indicator to disappear
                await awaitsFor(
                    function () {
                        return !isTabDirty(testFilePath);
                    },
                    "Dirty indicator to disappear"
                );

                // Verify the tab no longer has a dirty indicator
                expect(isTabDirty(testFilePath)).toBe(false);

                // Revert the changes for cleanup
                doc.setText("// Test file 1 for TabBar");
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_SAVE, { doc: doc }),
                    "Save file with original content"
                );
            });

            it("should display directory name for files with the same name", async function () {
                // Open both duplicate files
                const duplicateFile1 = testDuplicateDir1 + "/" + testDuplicateName;
                const duplicateFile2 = testDuplicateDir2 + "/" + testDuplicateName;

                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: duplicateFile1 }),
                    "Open first duplicate file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: duplicateFile2 }),
                    "Open second duplicate file"
                );

                // Wait for both tabs to appear
                await awaitsFor(
                    function () {
                        return tabExists(duplicateFile1) && tabExists(duplicateFile2);
                    },
                    "Both duplicate tabs to appear"
                );

                // Verify both tabs have directory names
                expect(hasDirectoryName(duplicateFile1)).toBe(true);
                expect(hasDirectoryName(duplicateFile2)).toBe(true);

                // Verify the directory names are correct
                expect(getDirectoryName(duplicateFile1)).toContain("dir1");
                expect(getDirectoryName(duplicateFile2)).toContain("dir2");
            });

            it("should display the full file path in the tooltip", async function () {
                // Open the first test file
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open test file"
                );

                // Wait for the tab to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath);
                    },
                    "Tab to appear"
                );

                // Verify the tooltip contains the full path
                const tooltip = getTabTooltip(testFilePath);
                expect(tooltip).toContain(Phoenix.app.getDisplayPath(testFilePath));
            });

            it("should display git change markers when git is enabled", async function () {
                // Skip this test if Git integration is not available
                if (!testWindow.brackets.test.Phoenix || !testWindow.brackets.test.Phoenix.app) {
                    expect("Test skipped - Phoenix.app not available").toBe("Test skipped - Phoenix.app not available");
                    return;
                }

                // Create a mock for the Git integration
                if (!testWindow.phoenixGitEvents) {
                    testWindow.phoenixGitEvents = {};
                }

                // Save the original Git integration if it exists
                const originalGitEvents = testWindow.phoenixGitEvents.TabBarIntegration;

                // Create a mock TabBarIntegration
                testWindow.phoenixGitEvents.TabBarIntegration = {
                    isUntracked: function (path) {
                        return path === testFilePath; // Mark the first file as untracked
                    },
                    isModified: function (path) {
                        return path === testFilePath2; // Mark the second file as modified
                    }
                };

                // Make sure the EventEmitter exists
                if (!testWindow.phoenixGitEvents.EventEmitter) {
                    testWindow.phoenixGitEvents.EventEmitter = {
                        on: function () {},
                        emit: function () {}
                    };
                }

                // Open the test files
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open first test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath2 }),
                    "Open second test file"
                );

                // Trigger a Git status update
                testWindow.phoenixGitEvents.EventEmitter.emit("GIT_FILE_STATUS_CHANGED");

                // Wait for the tabs to update with Git status
                await awaitsFor(
                    function () {
                        return hasGitStatus(testFilePath) && hasGitStatus(testFilePath2);
                    },
                    "Tabs to update with Git status"
                );

                // Verify the first file has the git-new class
                const $tab1 = getTab(testFilePath);
                expect($tab1.hasClass("git-new")).toBe(true);
                expect(hasGitStatus(testFilePath)).toBe(true);

                // Verify the second file has the git-modified class
                const $tab2 = getTab(testFilePath2);
                expect($tab2.hasClass("git-modified")).toBe(true);
                expect(hasGitStatus(testFilePath2)).toBe(true);

                // Verify the tooltips contain the Git status
                expect(getTabTooltip(testFilePath)).toContain("Untracked");
                expect(getTabTooltip(testFilePath2)).toContain("Modified");

                // Restore the original Git integration
                testWindow.phoenixGitEvents.TabBarIntegration = originalGitEvents;
            });

            it("should display a close button", async function () {
                // Open the first test file
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open test file"
                );

                // Wait for the tab to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath);
                    },
                    "Tab to appear"
                );

                // Verify the tab has a close button
                expect(hasCloseButton(testFilePath)).toBe(true);

                // Verify the close button has the correct icon
                const $closeButton = getTab(testFilePath).find(".tab-close");
                expect($closeButton.find("i.fa-times").length).toBe(1);
            });

            it("should close the file when the close button is clicked", async function () {
                // Open the first test file
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open test file"
                );

                // Wait for the tab to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath);
                    },
                    "Tab to appear"
                );

                // Get the close button
                const $closeButton = getTab(testFilePath).find(".tab-close");

                // Create a spy for the FILE_CLOSE command
                const executeOriginal = CommandManager.execute;
                let fileCloseCalled = false;
                let fileClosePathArg = null;

                CommandManager.execute = function (command, args) {
                    if (command === Commands.FILE_CLOSE) {
                        fileCloseCalled = true;
                        if (args && args.file) {
                            fileClosePathArg = args.file.fullPath;
                        }
                    }
                    return executeOriginal.apply(CommandManager, arguments);
                };

                // Click the close button
                $closeButton.click();

                // Cancel the save dialog if it appears
                cancelSaveDialog();

                // Wait for the tab to disappear
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath);
                    },
                    "Tab to disappear"
                );

                // Restore the original execute function
                CommandManager.execute = executeOriginal;

                // Verify the FILE_CLOSE command was called with the correct file
                expect(fileCloseCalled).toBe(true);
                expect(fileClosePathArg).toBe(testFilePath);
            });
        });

        describe("Context Menu", function () {
            beforeEach(async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();

                // Open all three test files
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open first test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath2 }),
                    "Open second test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath3 }),
                    "Open third test file"
                );

                // Wait for all tabs to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath) && tabExists(testFilePath2) && tabExists(testFilePath3);
                    },
                    "All tabs to appear"
                );
            });

            /**
             * Helper function to get the context menu element
             * @returns {jQuery} - The context menu element
             */
            function getContextMenu() {
                return $("#tabbar-context-menu");
            }

            it("should open context menu when right-clicking on a tab", async function () {
                // Get the tab element
                const $tab = getTab(testFilePath);
                expect($tab.length).toBe(1);
                const currentBefore = MainViewManager.getCurrentlyViewedPath("first-pane");
                expect(currentBefore).toBe(testFilePath3);

                // Simulate a right-click (contextmenu) event on the tab
                const event = $.Event("contextmenu", {
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(event);

                // Wait for the context menu to appear
                await awaitsFor(
                    function () {
                        return getContextMenu().hasClass("open");
                    },
                    "Context menu to appear"
                );

                // Verify the context menu is open, for the right-clicked tab, while the current file stays put
                expect(getContextMenu().hasClass("open")).toBe(true);
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(currentBefore);
                expect(isTabActive(testFilePath3)).toBe(true);
                expect($tab.hasClass("context")).toBe(true);

                // Clean up - close the context menu by clicking elsewhere
                $("body").click();

                // Wait for the context menu to disappear
                await awaitsFor(
                    function () {
                        return !getContextMenu().hasClass("open");
                    },
                    "Context menu to disappear"
                );
            });

            it("should close the tab when selecting 'Close' from context menu", async function () {
                // Get the tab element
                const $tab = getTab(testFilePath);

                // Right-click on the tab to open context menu
                // First trigger mousedown to make the tab active
                const mousedownEvent = $.Event("mousedown", {
                    button: 2,
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(mousedownEvent);

                // Then trigger contextmenu to open the menu
                const contextmenuEvent = $.Event("contextmenu", {
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(contextmenuEvent);

                // Wait for context menu to appear
                await awaitsFor(
                    function () {
                        return getContextMenu().hasClass("open");
                    },
                    "Context menu to appear"
                );

                // Find and click the "Close" option
                const $closeTabOption = getContextMenu()
                    .find(".menu-name")
                    .filter(function () {
                        return $(this).text().trim() === Strings.CMD_FILE_CLOSE;
                    })
                    .closest("li");
                expect($closeTabOption.length).toBe(1);
                $closeTabOption.click();

                // Cancel the save dialog if it appears
                cancelSaveDialog();

                // Verify the tab is closed
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath);
                    },
                    "Tab to be closed"
                );
            });

            it("should close tabs to the right when selecting 'Close tabs to the right' from context menu", async function () {
                // Open all three test files
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open first test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath2 }),
                    "Open second test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath3 }),
                    "Open third test file"
                );

                // Wait for all tabs to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath) && tabExists(testFilePath2) && tabExists(testFilePath3);
                    },
                    "All tabs to appear"
                );

                // Verify all three tabs exist
                expect(tabExists(testFilePath)).toBe(true);
                expect(tabExists(testFilePath2)).toBe(true);
                expect(tabExists(testFilePath3)).toBe(true);

                // Get the first tab element
                const $tab = getTab(testFilePath);

                // Right-click on the first tab to open context menu
                const mousedownEvent = $.Event("mousedown", {
                    button: 2,
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(mousedownEvent);

                const contextmenuEvent = $.Event("contextmenu", {
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(contextmenuEvent);

                // Wait for context menu to appear
                await awaitsFor(
                    function () {
                        return getContextMenu().hasClass("open");
                    },
                    "Context menu to appear"
                );

                // Find and click the "Close Tabs to the Right" option
                const $closeTabsToRightOption = getContextMenu()
                    .find(".menu-name")
                    .filter(function () {
                        return $(this).text().trim() === Strings.CLOSE_TABS_TO_THE_RIGHT;
                    })
                    .closest("li");
                expect($closeTabsToRightOption.length).toBe(1);
                $closeTabsToRightOption.click();

                // Cancel any save dialogs that might appear
                cancelSaveDialog();

                // Verify tabs to the right are closed
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath) && !tabExists(testFilePath2) && !tabExists(testFilePath3);
                    },
                    "Tabs to the right to be closed"
                );

                // Verify only the first tab remains
                expect(tabExists(testFilePath)).toBe(true);
                expect(tabExists(testFilePath2)).toBe(false);
                expect(tabExists(testFilePath3)).toBe(false);
                expect(getTabCount()).toBe(1);
            });

            it("should close tabs to the left when selecting 'Close tabs to the left' from context menu", async function () {
                // Open all three test files
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open first test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath2 }),
                    "Open second test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath3 }),
                    "Open third test file"
                );

                // Wait for all tabs to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath) && tabExists(testFilePath2) && tabExists(testFilePath3);
                    },
                    "All tabs to appear"
                );

                // Verify all three tabs exist
                expect(tabExists(testFilePath)).toBe(true);
                expect(tabExists(testFilePath2)).toBe(true);
                expect(tabExists(testFilePath3)).toBe(true);

                // Get the third tab element
                const $tab = getTab(testFilePath3);

                // Right-click on the third tab to open context menu
                const mousedownEvent = $.Event("mousedown", {
                    button: 2,
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(mousedownEvent);

                const contextmenuEvent = $.Event("contextmenu", {
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(contextmenuEvent);

                // Wait for context menu to appear
                await awaitsFor(
                    function () {
                        return getContextMenu().hasClass("open");
                    },
                    "Context menu to appear"
                );

                // Find and click the "Close Tabs to the Left" option
                const $closeTabsToLeftOption = getContextMenu()
                    .find(".menu-name")
                    .filter(function () {
                        return $(this).text().trim() === Strings.CLOSE_TABS_TO_THE_LEFT;
                    })
                    .closest("li");
                expect($closeTabsToLeftOption.length).toBe(1);
                $closeTabsToLeftOption.click();

                // Cancel any save dialogs that might appear
                cancelSaveDialog();

                // Verify tabs to the left are closed
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath) && !tabExists(testFilePath2) && tabExists(testFilePath3);
                    },
                    "Tabs to the left to be closed"
                );

                // Verify only the third tab remains
                expect(tabExists(testFilePath)).toBe(false);
                expect(tabExists(testFilePath2)).toBe(false);
                expect(tabExists(testFilePath3)).toBe(true);
                expect(getTabCount()).toBe(1);
            });

            it("should close all tabs when selecting 'Close all tabs' from context menu", async function () {
                // Open all three test files
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath }),
                    "Open first test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath2 }),
                    "Open second test file"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath3 }),
                    "Open third test file"
                );

                // Wait for all tabs to appear
                await awaitsFor(
                    function () {
                        return tabExists(testFilePath) && tabExists(testFilePath2) && tabExists(testFilePath3);
                    },
                    "All tabs to appear"
                );

                // Verify all three tabs exist
                expect(tabExists(testFilePath)).toBe(true);
                expect(tabExists(testFilePath2)).toBe(true);
                expect(tabExists(testFilePath3)).toBe(true);

                // Get any tab element (we'll use the first)
                const $tab = getTab(testFilePath);

                // Right-click on the tab to open context menu
                const mousedownEvent = $.Event("mousedown", {
                    button: 2,
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(mousedownEvent);

                const contextmenuEvent = $.Event("contextmenu", {
                    pageX: 100,
                    pageY: 100
                });
                $tab.trigger(contextmenuEvent);

                // Wait for context menu to appear
                await awaitsFor(
                    function () {
                        return getContextMenu().hasClass("open");
                    },
                    "Context menu to appear"
                );

                // Find and click the "Close All Tabs" option
                const $closeAllTabsOption = getContextMenu()
                    .find(".menu-name")
                    .filter(function () {
                        return $(this).text().trim() === Strings.CLOSE_ALL_TABS;
                    })
                    .closest("li");
                expect($closeAllTabsOption.length).toBe(1);
                $closeAllTabsOption.click();

                // Cancel any save dialogs that might appear
                cancelSaveDialog();

                // Verify all tabs are closed
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath) && !tabExists(testFilePath2) && !tabExists(testFilePath3);
                    },
                    "All tabs to be closed"
                );

                expect(tabExists(testFilePath)).toBe(false);
                expect(tabExists(testFilePath2)).toBe(false);
                expect(tabExists(testFilePath3)).toBe(false);
                expect(getTabCount()).toBe(0);
            });
        });

        describe("Pinned Tabs", function () {
            let pinFiles;

            function getContextMenuItem(text) {
                return $("#tabbar-context-menu")
                    .find(".menu-name")
                    .filter(function () {
                        return $(this).text().trim() === text;
                    })
                    .closest("li");
            }

            function getWorkingSetItem(filePath) {
                return $("#working-set-list-container li").filter(function () {
                    const file = $(this).data("file");
                    return file && file.fullPath === filePath;
                });
            }

            function getWorkingSetOrder() {
                return MainViewManager.getWorkingSet("first-pane").map((file) => file.fullPath);
            }

            async function openTabContextMenu(filePath) {
                getTab(filePath).trigger($.Event("contextmenu", { pageX: 100, pageY: 100 }));
                await awaitsFor(
                    function () {
                        return $("#tabbar-context-menu").hasClass("open");
                    },
                    "Context menu to appear"
                );
            }

            async function closeContextMenu() {
                $("body").click();
                await awaitsFor(
                    function () {
                        return !$("#tabbar-context-menu").hasClass("open");
                    },
                    "Context menu to disappear"
                );
            }

            async function pinFromContextMenu(filePath, paneId = "first-pane") {
                await openTabContextMenu(filePath);
                const $pinItem = getContextMenuItem(Strings.PIN_TAB);
                expect($pinItem.length).toBe(1);
                $pinItem.click();
                await awaitsFor(
                    function () {
                        return MainViewManager.isPathPinned(paneId, filePath) && getTab(filePath).hasClass("pinned");
                    },
                    "Tab to be pinned"
                );
            }

            beforeEach(async function () {
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
                pinFiles = await createTestFiles(3, "pin-test", "// Pin test file");
                await openTestFiles(pinFiles);
                await waitForTabs(pinFiles);
            });

            afterEach(async function () {
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
            });

            it("should pin a tab from the context menu and show a pin instead of the close button", async function () {
                await pinFromContextMenu(pinFiles[1]);

                const $tab = getTab(pinFiles[1]);
                expect($tab.find(".tab-pin").length).toBe(1);
                expect($tab.find(".tab-close").length).toBe(0);
                expect(getTab(pinFiles[0]).find(".tab-close").length).toBe(1);

                // pinned tabs move to the front, in the working set and in the tab bar
                expect(getWorkingSetOrder()).toEqual([pinFiles[1], pinFiles[0], pinFiles[2]]);
                expect($("#phoenix-tab-bar .tab").first().attr("data-path")).toBe(pinFiles[1]);

                // the menu offers to unpin a pinned tab
                await openTabContextMenu(pinFiles[1]);
                expect(getContextMenuItem(Strings.UNPIN_TAB).length).toBe(1);
                expect(getContextMenuItem(Strings.PIN_TAB).length).toBe(0);
                await closeContextMenu();
            });

            it("should unpin a tab when its pin icon is clicked", async function () {
                await pinFromContextMenu(pinFiles[0]);

                getTab(pinFiles[0]).find(".tab-pin").click();
                await awaitsFor(
                    function () {
                        return !MainViewManager.isPathPinned("first-pane", pinFiles[0]) &&
                            getTab(pinFiles[0]).find(".tab-close").length === 1;
                    },
                    "Tab to be unpinned"
                );
                expect(getTab(pinFiles[0]).hasClass("pinned")).toBe(false);
            });

            it("should show the pin in the working set and unpin from there", async function () {
                await pinFromContextMenu(pinFiles[2]);

                await awaitsFor(
                    function () {
                        return getWorkingSetItem(pinFiles[2]).find(".file-status-icon.pinned").length === 1;
                    },
                    "Pin icon to appear in the working set"
                );
                // the working set lists the pinned file first as well
                expect($("#working-set-list-container li").first().data("file").fullPath).toBe(pinFiles[2]);

                getWorkingSetItem(pinFiles[2]).find(".file-status-icon.pinned").trigger("mousedown");
                await awaitsFor(
                    function () {
                        return !MainViewManager.isPathPinned("first-pane", pinFiles[2]) &&
                            !getTab(pinFiles[2]).hasClass("pinned");
                    },
                    "File to be unpinned from the working set"
                );
                expect(getWorkingSetItem(pinFiles[2]).find(".file-status-icon.pinned").length).toBe(0);
            });

            it("should keep pinned tabs open when closing all tabs from the context menu", async function () {
                await pinFromContextMenu(pinFiles[0]);

                await openTabContextMenu(pinFiles[1]);
                const $closeAll = getContextMenuItem(Strings.CLOSE_ALL_TABS);
                expect($closeAll.length).toBe(1);
                $closeAll.click();
                cancelSaveDialog();

                await awaitsFor(
                    function () {
                        return getTabCount() === 1;
                    },
                    "Unpinned tabs to close"
                );
                expect(tabExists(pinFiles[0])).toBe(true);
                expect(getWorkingSetOrder()).toEqual([pinFiles[0]]);
            });

            it("should skip pinned tabs for close tabs to the left and disable it when nothing is left to close", async function () {
                await pinFromContextMenu(pinFiles[0]);
                await pinFromContextMenu(pinFiles[1]);
                expect(getWorkingSetOrder()).toEqual([pinFiles[0], pinFiles[1], pinFiles[2]]);

                // everything to the left of the last tab is pinned, so there is nothing to close
                await openTabContextMenu(pinFiles[2]);
                expect(getContextMenuItem(Strings.CLOSE_TABS_TO_THE_LEFT).find("a").hasClass("disabled")).toBe(true);
                expect(getContextMenuItem(Strings.CLOSE_OTHER_TABS).find("a").hasClass("disabled")).toBe(true);
                expect(getContextMenuItem(Strings.CLOSE_TABS_TO_THE_RIGHT).find("a").hasClass("disabled")).toBe(true);
                expect(getContextMenuItem(Strings.CLOSE_ALL_TABS).find("a").hasClass("disabled")).toBe(false);
                await closeContextMenu();

                // from the first tab, close tabs to the right only closes the unpinned one
                await openTabContextMenu(pinFiles[0]);
                expect(getContextMenuItem(Strings.CLOSE_TABS_TO_THE_RIGHT).find("a").hasClass("disabled")).toBe(false);
                getContextMenuItem(Strings.CLOSE_TABS_TO_THE_RIGHT).click();
                cancelSaveDialog();

                await awaitsFor(
                    function () {
                        return !tabExists(pinFiles[2]);
                    },
                    "Unpinned tab to the right to close"
                );
                expect(getWorkingSetOrder()).toEqual([pinFiles[0], pinFiles[1]]);
            });

            it("should pin a tab dropped in front of a pinned tab and unpin one dropped behind an unpinned tab", async function () {
                await pinFromContextMenu(pinFiles[0]);

                await simulateTabDragAndDrop(pinFiles[2], pinFiles[0], true);
                await awaitsFor(
                    function () {
                        return MainViewManager.isPathPinned("first-pane", pinFiles[2]) &&
                            getTab(pinFiles[2]).hasClass("pinned");
                    },
                    "Tab dropped in front of a pinned tab to be pinned"
                );
                expect(getWorkingSetOrder()).toEqual([pinFiles[2], pinFiles[0], pinFiles[1]]);

                await simulateTabDragAndDrop(pinFiles[0], pinFiles[1], false);
                await awaitsFor(
                    function () {
                        return !MainViewManager.isPathPinned("first-pane", pinFiles[0]) &&
                            !getTab(pinFiles[0]).hasClass("pinned");
                    },
                    "Tab dropped behind an unpinned tab to be unpinned"
                );
                expect(getWorkingSetOrder()).toEqual([pinFiles[2], pinFiles[1], pinFiles[0]]);
                expect(MainViewManager.isPathPinned("first-pane", pinFiles[2])).toBe(true);
            });

            it("should show the dirty indicator on a pinned tab and on its working set item", async function () {
                await pinFromContextMenu(pinFiles[1]);
                const doc = DocumentManager.getOpenDocumentForPath(pinFiles[1]);
                doc.setText("// Pin test file changed");
                await awaitsFor(
                    function () {
                        return isTabDirty(pinFiles[1]);
                    },
                    "Pinned tab to show the dirty indicator"
                );
                expect(getTab(pinFiles[1]).hasClass("pinned")).toBe(true);
                expect(getTab(pinFiles[1]).find(".tab-pin").length).toBe(1);
                expect(getTab(pinFiles[1]).find(".tab-close").length).toBe(0);

                // the working set item shows the dirty dot while the mouse is away and the pin while it hovers
                const $row = getWorkingSetItem(pinFiles[1]);
                await awaitsFor(
                    function () {
                        return $row.find(".file-status-icon.dirty").length === 1;
                    },
                    "Pinned working set item to show the dirty dot"
                );
                expect($row.find(".file-status-icon.pinned").length).toBe(0);
                $row.trigger("mouseenter");
                expect($row.find(".file-status-icon.pinned").length).toBe(1);
                expect($row.find(".file-status-icon.dirty").length).toBe(0);
                $row.trigger("mouseleave");
                expect($row.find(".file-status-icon.dirty").length).toBe(1);

                // once the file is clean again the pin is back
                await awaitsForDone(CommandManager.execute(Commands.FILE_SAVE, { doc: doc }), "Save the pinned file");
                await awaitsFor(
                    function () {
                        return !isTabDirty(pinFiles[1]) && $row.find(".file-status-icon.pinned").length === 1;
                    },
                    "Pin to show again once the file is clean"
                );
                expect($row.find(".file-status-icon.dirty").length).toBe(0);
            });

            it("should close an unpinned tab on middle click but not a pinned one", async function () {
                await pinFromContextMenu(pinFiles[0]);

                getTab(pinFiles[0]).trigger($.Event("mousedown", { which: 2, button: 1 }));
                getTab(pinFiles[1]).trigger($.Event("mousedown", { which: 2, button: 1 }));
                cancelSaveDialog();
                await awaitsFor(
                    function () {
                        return !tabExists(pinFiles[1]);
                    },
                    "Unpinned tab to close on middle click"
                );
                expect(tabExists(pinFiles[0])).toBe(true);
                expect(MainViewManager.isPathPinned("first-pane", pinFiles[0])).toBe(true);
                expect(getWorkingSetOrder()).toEqual([pinFiles[0], pinFiles[2]]);
            });

            it("should only focus the editor when the active tab is clicked again", async function () {
                expect(isTabActive(pinFiles[2])).toBe(true);
                const executeSpy = spyOn(CommandManager, "execute").and.callThrough();
                const openCalls = () => executeSpy.calls.allArgs().filter((args) => args[0] === Commands.FILE_OPEN);

                // the active tab doesn't open the file again, that would rebuild the editor
                getTab(pinFiles[2]).trigger($.Event("mousedown", { which: 1, button: 0 }));
                expect(openCalls().length).toBe(0);
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(pinFiles[2]);

                // another tab is opened through the command
                getTab(pinFiles[1]).trigger($.Event("mousedown", { which: 1, button: 0 }));
                expect(openCalls().length).toBe(1);
                expect(openCalls()[0][1].fullPath).toBe(pinFiles[1]);
                await awaitsFor(
                    function () {
                        return isTabActive(pinFiles[1]);
                    },
                    "Other tab to become active"
                );
            });

            it("should take a ctrl click on mac as a right click and not open the tab", async function () {
                expect(isTabActive(pinFiles[2])).toBe(true);
                const executeSpy = spyOn(CommandManager, "execute").and.callThrough();
                const openCalls = () => executeSpy.calls.allArgs().filter((args) => args[0] === Commands.FILE_OPEN);

                getTab(pinFiles[0]).trigger($.Event("mousedown", { which: 1, button: 0, ctrlKey: true }));
                if (testWindow.brackets.platform === "mac") {
                    expect(openCalls().length).toBe(0);
                    expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(pinFiles[2]);
                } else {
                    expect(openCalls().length).toBe(1);
                    expect(openCalls()[0][1].fullPath).toBe(pinFiles[0]);
                    await awaitsFor(
                        function () {
                            return isTabActive(pinFiles[0]);
                        },
                        "Ctrl clicked tab to become active"
                    );
                }
            });

            it("should keep a tab pinned when it is dragged to the other pane", async function () {
                await pinFromContextMenu(pinFiles[0]);

                MainViewManager.setLayoutScheme(1, 2);
                await awaitsFor(
                    function () {
                        return MainViewManager.getPaneCount() === 2;
                    },
                    "Second pane to be created"
                );

                const sourceTab = getTab(pinFiles[0]);
                const emptyPaneTarget = $("#second-pane .pane-content");
                sourceTab.trigger($.Event("dragstart", {
                    originalEvent: { dataTransfer: { setData: function () {}, effectAllowed: "move" } }
                }));
                emptyPaneTarget.trigger($.Event("dragover", {
                    originalEvent: { dataTransfer: { dropEffect: "move" } },
                    preventDefault: function () {}
                }));
                emptyPaneTarget.trigger($.Event("drop", {
                    originalEvent: { dataTransfer: {} },
                    preventDefault: function () {},
                    stopPropagation: function () {}
                }));
                sourceTab.trigger($.Event("dragend"));

                await awaitsFor(
                    function () {
                        return tabExistsInPane(pinFiles[0], "second-pane") && !tabExistsInPane(pinFiles[0], "first-pane");
                    },
                    "Tab to move to the second pane"
                );
                expect(MainViewManager.isPathPinned("second-pane", pinFiles[0])).toBe(true);
                expect(MainViewManager.isPathPinned("first-pane", pinFiles[0])).toBe(false);

                // the working set lists follow the move as well
                const workingSetPaneOf = (filePath) => $("#working-set-list-container li").filter(function () {
                    const file = $(this).data("file");
                    return file && file.fullPath === filePath;
                }).closest(".working-set-view").attr("id");
                await awaitsFor(
                    function () {
                        return workingSetPaneOf(pinFiles[0]) === "working-set-list-second-pane";
                    },
                    "Working set to list the file under the second pane"
                );
                expect($("#working-set-list-second-pane .file-status-icon.pinned").length).toBe(1);
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar-2").find(`.tab[data-path="${pinFiles[0]}"] .tab-pin`).length === 1;
                    },
                    "Pin to show on the moved tab"
                );
            });
        });

        describe("Settings Menu", function () {
            beforeEach(async function () {
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1, smoothScroll: false });
                await testWindow.closeAllFiles();
                await openTestFiles([testFilePath]);
                await waitForTabs([testFilePath]);
            });

            afterEach(function () {
                testWindow.brackets.test.Menus.closeAll();
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1, smoothScroll: false });
            });

            async function openSettingsMenu() {
                const $bar = $("#phoenix-tab-bar");
                const barRect = $bar[0].getBoundingClientRect();
                $bar.trigger($.Event("mousedown", { which: 1, target: $bar[0] }));
                $bar.trigger($.Event("click", { target: $bar[0], pageX: barRect.right - 5, pageY: barRect.top + 5 }));
                await awaitsFor(
                    function () {
                        return $("#tabbar-settings-context-menu").hasClass("open");
                    },
                    "Settings menu to open"
                );
            }

            it("should open the tab bar settings from the empty part of the bar and toggle smooth scrolling", async function () {
                const $bar = $("#phoenix-tab-bar");
                const barRect = $bar[0].getBoundingClientRect();
                $bar.trigger($.Event("mousedown", { which: 1, target: $bar[0] }));
                $bar.trigger($.Event("click", { target: $bar[0], pageX: barRect.right - 5, pageY: barRect.top + 5 }));

                await awaitsFor(
                    function () {
                        return $("#tabbar-settings-context-menu").hasClass("open");
                    },
                    "Settings menu to open"
                );
                const itemNames = $("#tabbar-settings-context-menu .menu-name").map(function () {
                    return $(this).text().trim();
                }).get();
                expect(itemNames).toContain(Strings.CMD_TOGGLE_TABBAR_SMOOTH_SCROLL);
                expect(itemNames).toContain(Strings.TABBAR_NUMBER_OF_TABS);
                expect(itemNames).toContain(Strings.CMD_HIDE_TABBAR);
                expect(itemNames).not.toContain(Strings.CMD_WORKINGSET_SORT_BY_NAME);

                const $smoothItem = $("#tabbar-settings-context-menu .menu-name").filter(function () {
                    return $(this).text().trim() === Strings.CMD_TOGGLE_TABBAR_SMOOTH_SCROLL;
                }).closest("li");
                expect($smoothItem.find("a").hasClass("checked")).toBe(false);
                $smoothItem.click();

                await awaitsFor(
                    function () {
                        return PreferencesManager.get("tabBar.options").smoothScroll === true;
                    },
                    "Smooth scrolling preference to turn on"
                );
                expect(CommandManager.get(Commands.TOGGLE_TABBAR_SMOOTH_SCROLL).getChecked()).toBe(true);

                // a press that started on a tab and ended on the empty part of the bar is reported as a click
                // on the bar as well, that one must not open the settings
                getTab(testFilePath).trigger($.Event("mousedown", { which: 1 }));
                $bar.trigger($.Event("click", { target: $bar[0], pageX: barRect.right - 5, pageY: barRect.top + 5 }));
                expect($("#tabbar-settings-context-menu").hasClass("open")).toBe(false);
            });

            it("should limit the tabs when a count is picked from the number of tabs submenu", async function () {
                const files = await createTestFiles(5, "count-test", "// count test file");
                await openTestFiles(files);
                await waitForTabs(files);
                expect(getTabCount()).toBe(6);

                await openSettingsMenu();
                const $countItem = $("#tabbar-number-of-tabs-submenu .menu-name").filter(function () {
                    return $(this).text().trim() === "3";
                }).closest("li");
                expect($countItem.length).toBe(1);
                expect($countItem.find("a").hasClass("checked")).toBe(false);
                $countItem.click();

                await awaitsFor(
                    function () {
                        return PreferencesManager.get("tabBar.options").numberOfTabs === 3 && getTabCount() === 3;
                    },
                    "Only three tabs to show"
                );
                // the current file is past the limit and still gets a tab
                expect(isTabActive(files[4])).toBe(true);
                expect(CommandManager.get("tabbar.numberOfTabs.3").getChecked()).toBe(true);
                expect(CommandManager.get("tabbar.numberOfTabs.all").getChecked()).toBe(false);
            });
        });

        describe("Placeholder Rows", function () {
            let originalProjectPath;

            function getWorkingSetItem(filePath) {
                return $("#working-set-list-container li").filter(function () {
                    const file = $(this).data("file");
                    return file && file.fullPath === filePath;
                });
            }

            // a file is only previewed when it belongs to the project, files from elsewhere always go
            // straight into the working set. So the test folder becomes the project for these specs
            beforeAll(async function () {
                originalProjectPath = testWindow.brackets.test.ProjectManager.getProjectRoot().fullPath;
                await testWindow.closeAllFiles();
                await SpecRunnerUtils.loadProjectInTestWindow(testFolder);
            }, 30000);

            afterAll(async function () {
                await testWindow.closeAllFiles();
                await SpecRunnerUtils.loadProjectInTestWindow(originalProjectPath);
            }, 30000);

            beforeEach(async function () {
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });
                await testWindow.closeAllFiles();
                await addToWorkingSet([testFilePath]);
                await waitForTabs([testFilePath]);
            });

            it("should show a previewed file as a placeholder in the working set and the tab bar alike", async function () {
                const FileViewController = testWindow.brackets.test.FileViewController;
                await awaitsForDone(
                    FileViewController.openAndSelectDocument(testFilePath2, FileViewController.PROJECT_MANAGER),
                    "Preview second file from the file tree"
                );

                await awaitsFor(
                    function () {
                        return getTab(testFilePath2).hasClass("placeholder") &&
                            getWorkingSetItem(testFilePath2).hasClass("placeholder");
                    },
                    "Placeholder tab and working set row to appear"
                );
                expect(MainViewManager.findInWorkingSet("first-pane", testFilePath2)).toBe(-1);
                // the placeholder sits after the working set files in both
                expect($("#phoenix-tab-bar .tab").last().attr("data-path")).toBe(testFilePath2);
                expect($("#working-set-list-container li").last().data("file").fullPath).toBe(testFilePath2);

                // previewing another file replaces the placeholder in both
                await awaitsForDone(
                    FileViewController.openAndSelectDocument(testFilePath3, FileViewController.PROJECT_MANAGER),
                    "Preview third file from the file tree"
                );
                await awaitsFor(
                    function () {
                        return getTab(testFilePath3).hasClass("placeholder") && !tabExists(testFilePath2) &&
                            getWorkingSetItem(testFilePath3).hasClass("placeholder") &&
                            getWorkingSetItem(testFilePath2).length === 0;
                    },
                    "Placeholder to move to the third file"
                );

                // clicking the placeholder row keeps the file, in the working set and the tab bar
                getWorkingSetItem(testFilePath3).trigger($.Event("mousedown", { which: 1, pageY: 10 }));
                await awaitsFor(
                    function () {
                        return MainViewManager.findInWorkingSet("first-pane", testFilePath3) !== -1 &&
                            !getTab(testFilePath3).hasClass("placeholder") &&
                            getWorkingSetItem(testFilePath3).length === 1 &&
                            !getWorkingSetItem(testFilePath3).hasClass("placeholder");
                    },
                    "Placeholder to become a working set file"
                );
            });

            it("should keep the current file when a working set item is right-clicked", async function () {
                await addToWorkingSet([testFilePath2]);
                await waitForTabs([testFilePath, testFilePath2]);
                await awaitsFor(
                    function () {
                        return getWorkingSetItem(testFilePath).length === 1 && isTabActive(testFilePath2);
                    },
                    "Working set rows to appear"
                );

                const $row = getWorkingSetItem(testFilePath);
                $row.trigger($.Event("mousedown", { which: 3, pageY: 10 }));
                $row.trigger($.Event("contextmenu", { pageX: 100, pageY: 200, target: $row.find("a")[0] }));
                await awaitsFor(
                    function () {
                        return $("#workingset-context-menu").hasClass("open");
                    },
                    "Working set context menu to appear"
                );
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(testFilePath2);
                expect($row.hasClass("context")).toBe(true);

                // the menu acts on the right-clicked file: Close closes it, not the current file
                const $closeItem = $("#workingset-context-menu .menu-name").filter(function () {
                    return $(this).text().trim() === Strings.CMD_FILE_CLOSE;
                }).closest("li");
                $closeItem.click();
                cancelSaveDialog();
                await awaitsFor(
                    function () {
                        return !tabExists(testFilePath) && getWorkingSetItem(testFilePath).length === 0;
                    },
                    "Right-clicked file to close"
                );
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(testFilePath2);
                expect(testWindow.brackets.test.FileViewController.getWorkingSetContext()).toBe(null);
            });

            it("should forget the right-clicked file as soon as the menu is gone, however it went", async function () {
                const FileViewController = testWindow.brackets.test.FileViewController;
                const Menus = testWindow.brackets.test.Menus;
                await addToWorkingSet([testFilePath2]);
                await waitForTabs([testFilePath, testFilePath2]);

                // a left click on another row closes the menu through Menus.closeAll without telling it
                const $row = getWorkingSetItem(testFilePath);
                $row.trigger($.Event("contextmenu", { pageX: 100, pageY: 200, target: $row.find("a")[0] }));
                await awaitsFor(() => $("#workingset-context-menu").hasClass("open"), "Working set menu to appear");
                expect(FileViewController.getWorkingSetContext().file.fullPath).toBe(testFilePath);
                Menus.closeAll();
                await awaitsFor(() => FileViewController.getWorkingSetContext() === null, "Context forgotten after closeAll");
                expect($row.hasClass("context")).toBe(false);

                // a click anywhere else closes it through the dropdown plugin on the document
                const $tab = getTab(testFilePath);
                $tab.trigger($.Event("contextmenu", { pageX: 100, pageY: 100 }));
                await awaitsFor(() => $("#tabbar-context-menu").hasClass("open"), "Tab context menu to appear");
                expect(FileViewController.getWorkingSetContext().file.fullPath).toBe(testFilePath);
                $(testWindow.document).trigger("click");
                await awaitsFor(() => FileViewController.getWorkingSetContext() === null, "Context forgotten after a click");
                expect($tab.hasClass("context")).toBe(false);
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(testFilePath2);
            });

            it("should keep a previewed file when it is saved", async function () {
                const FileViewController = testWindow.brackets.test.FileViewController;
                await awaitsForDone(
                    FileViewController.openAndSelectDocument(testFilePath2, FileViewController.PROJECT_MANAGER),
                    "Preview second file from the file tree"
                );
                await awaitsFor(() => getTab(testFilePath2).hasClass("placeholder"), "Placeholder tab to appear");

                await awaitsForDone(CommandManager.execute(Commands.FILE_SAVE), "Save the previewed file");
                await awaitsFor(
                    function () {
                        return MainViewManager.findInWorkingSet("first-pane", testFilePath2) !== -1 &&
                            !getTab(testFilePath2).hasClass("placeholder") &&
                            getWorkingSetItem(testFilePath2).length === 1 &&
                            !getWorkingSetItem(testFilePath2).hasClass("placeholder");
                    },
                    "Saved preview to become a working set file"
                );
            });

            it("should keep a previewed file when it is pinned from its tab", async function () {
                const FileViewController = testWindow.brackets.test.FileViewController;
                await awaitsForDone(
                    FileViewController.openAndSelectDocument(testFilePath2, FileViewController.PROJECT_MANAGER),
                    "Preview second file from the file tree"
                );
                await awaitsFor(() => getTab(testFilePath2).hasClass("placeholder"), "Placeholder tab to appear");

                await openContextMenuOfTab(getTab(testFilePath2));
                getMenuItemByText("tabbar-context-menu", Strings.PIN_TAB).click();
                await awaitsFor(
                    function () {
                        return MainViewManager.isPathPinned("first-pane", testFilePath2) &&
                            getTab(testFilePath2).hasClass("pinned") && !getTab(testFilePath2).hasClass("placeholder");
                    },
                    "Previewed file to join the working set pinned"
                );
                expect(MainViewManager.getWorkingSet("first-pane").map((file) => file.fullPath))
                    .toEqual([testFilePath2, testFilePath]);
                const $row = getWorkingSetItem(testFilePath2);
                expect($row.length).toBe(1);
                expect($row.hasClass("placeholder")).toBe(false);
                expect($row.find(".file-status-icon.pinned").length).toBe(1);
            });

            it("should keep the previewed file when saving all files", async function () {
                const FileViewController = testWindow.brackets.test.FileViewController;
                await awaitsForDone(
                    FileViewController.openAndSelectDocument(testFilePath2, FileViewController.PROJECT_MANAGER),
                    "Preview second file from the file tree"
                );
                await awaitsFor(() => getTab(testFilePath2).hasClass("placeholder"), "Placeholder tab to appear");

                await awaitsForDone(CommandManager.execute(Commands.FILE_SAVE_ALL), "Save all files");
                await awaitsFor(
                    function () {
                        return MainViewManager.findInWorkingSet("first-pane", testFilePath2) !== -1 &&
                            !getTab(testFilePath2).hasClass("placeholder") &&
                            getWorkingSetItem(testFilePath2).length === 1 &&
                            !getWorkingSetItem(testFilePath2).hasClass("placeholder");
                    },
                    "Saved preview to become a working set file"
                );
            });

            it("should not show a closed file as a placeholder while the next one opens", async function () {
                await addToWorkingSet([testFilePath2, testFilePath3]);
                await waitForTabs([testFilePath, testFilePath2, testFilePath3]);
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(testFilePath3);

                // the closed file stays in view until the next one is ready, during which neither list may
                // treat it as a preview. The pane reports that state directly
                const pane = MainViewManager._getPane("first-pane");
                const file = FileSystem.getFileForPath(testFilePath3);
                const closePromise = CommandManager.execute(Commands.FILE_CLOSE, { file: file });
                expect(pane.getTemporaryViewFile()).toBe(null);
                await awaitsForDone(closePromise, "Close the current file");
                await awaitsFor(
                    () => !tabExists(testFilePath3) && getWorkingSetItem(testFilePath3).length === 0,
                    "Closed file to leave both lists"
                );
                expect($("#phoenix-tab-bar .tab.placeholder").length).toBe(0);
                expect($("#working-set-list-container li.placeholder").length).toBe(0);
            });
        });

        describe("Context Menu Commands", function () {
            let originalProjectPath, ProjectManager, SidebarView, Menus;

            // rename and show in file tree act on the file tree, so the test folder is the project here
            beforeAll(async function () {
                ProjectManager = testWindow.brackets.test.ProjectManager;
                SidebarView = testWindow.brackets.test.SidebarView;
                Menus = testWindow.brackets.test.Menus;
                originalProjectPath = ProjectManager.getProjectRoot().fullPath;
                await testWindow.closeAllFiles();
                await SpecRunnerUtils.loadProjectInTestWindow(testFolder);
            }, 30000);

            afterAll(async function () {
                await testWindow.closeAllFiles();
                await SpecRunnerUtils.loadProjectInTestWindow(originalProjectPath);
            }, 30000);

            beforeEach(async function () {
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });
                await testWindow.closeAllFiles();
                await addToWorkingSet([testFilePath, testFilePath2]);
                await waitForTabs([testFilePath, testFilePath2]);
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(testFilePath2);
            });

            afterEach(async function () {
                Menus.closeAll();
                if ($("#project-files-container .jstree-rename-input").length) {
                    ProjectManager._actionCreator.cancelRename();
                }
                SidebarView.show();
                await testWindow.closeAllFiles();
            });

            it("should save the right-clicked file and not the current one", async function () {
                const docA = DocumentManager.getOpenDocumentForPath(testFilePath),
                    docB = DocumentManager.getOpenDocumentForPath(testFilePath2);
                docA.setText("// Test file 1 for TabBar, changed");
                docB.setText("// Test file 2 for TabBar, changed");
                await awaitsFor(
                    function () {
                        return isTabDirty(testFilePath) && isTabDirty(testFilePath2);
                    },
                    "Both tabs to show the dirty indicator"
                );

                await openContextMenuOfTab(getTab(testFilePath));
                getMenuItemByText("tabbar-context-menu", Strings.CMD_FILE_SAVE).click();
                await awaitsFor(
                    function () {
                        return !docA.isDirty && !isTabDirty(testFilePath);
                    },
                    "Right-clicked file to be saved"
                );
                expect(await readFileFromDisk(testFilePath)).toBe("// Test file 1 for TabBar, changed");
                expect(docB.isDirty).toBe(true);
                expect(isTabDirty(testFilePath2)).toBe(true);
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(testFilePath2);

                // put the file back the way the other specs expect it
                docA.setText("// Test file 1 for TabBar");
                await awaitsForDone(CommandManager.execute(Commands.FILE_SAVE, { doc: docA }), "Restore the file");
            });

            it("should copy the path of the right-clicked file", async function () {
                const copySpy = spyOn(testWindow.Phoenix.app, "copyToClipboard");
                await openContextMenuOfTab(getTab(testFilePath));
                getMenuItemByText("tabbar-context-menu", Strings.CMD_FILE_COPY_PATH).click();
                await awaitsFor(
                    function () {
                        return copySpy.calls.count() > 0;
                    },
                    "Path to be copied"
                );
                expect(copySpy).toHaveBeenCalledWith(ProjectManager.makeProjectRelativeIfPossible(testFilePath));
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(testFilePath2);
            });

            it("should reveal the right-clicked file in the tree even when the sidebar is hidden", async function () {
                const fileName = testFilePath.split("/").pop();
                SidebarView.hide();
                expect(SidebarView.isVisible()).toBe(false);

                await openContextMenuOfTab(getTab(testFilePath));
                getMenuItemByText("tabbar-context-menu", Strings.CMD_SHOW_IN_TREE).click();
                await awaitsFor(
                    function () {
                        const selectedName = $("#project-files-container .selected-node").text()
                            .replace(new RegExp("\\s", "g"), "");
                        return SidebarView.isVisible() && selectedName === fileName;
                    },
                    "Sidebar to show with the right-clicked file selected in the tree"
                );
                expect(ProjectManager.getSelectedItem().fullPath).toBe(testFilePath);
                // the file selected in the tree is always the one in the editor, so the revealed file is shown too
                expect(MainViewManager.getCurrentlyViewedPath("first-pane")).toBe(testFilePath);
            });

            it("should rename the right-clicked file in the tree even when the sidebar is hidden", async function () {
                SidebarView.hide();
                expect(SidebarView.isVisible()).toBe(false);

                await openContextMenuOfTab(getTab(testFilePath));
                getMenuItemByText("tabbar-context-menu", Strings.CMD_FILE_RENAME).click();
                await awaitsFor(
                    function () {
                        return SidebarView.isVisible() &&
                            $("#project-files-container .jstree-rename-input").length === 1;
                    },
                    "Sidebar to show with the rename input in the tree"
                );
                expect($("#project-files-container .jstree-rename-input").val()).toBe(testFilePath.split("/").pop());

                ProjectManager._actionCreator.cancelRename();
                await awaitsFor(
                    function () {
                        return $("#project-files-container .jstree-rename-input").length === 0;
                    },
                    "Rename to be cancelled"
                );
            });

            it("should only offer rename and show in tree when the right-clicked file is on disk", async function () {
                const untitledDoc = await jsPromise(CommandManager.execute(Commands.FILE_NEW_UNTITLED));
                const untitledPath = untitledDoc.file.fullPath;
                await waitForTabs([untitledPath]);
                await openTestFiles([testFilePath]);
                await awaitsFor(() => isTabActive(testFilePath), "First file to be current again");

                function itemDisabled(text) {
                    return getMenuItemByText("tabbar-context-menu", text).find("a").hasClass("disabled");
                }

                // the untitled file isn't on disk, while the current file is
                await openContextMenuOfTab(getTab(untitledPath));
                await awaitsFor(
                    function () {
                        return itemDisabled(Strings.CMD_FILE_RENAME) && itemDisabled(Strings.CMD_SHOW_IN_TREE);
                    },
                    "Rename and show in file tree to be disabled for the untitled file"
                );
                Menus.closeAll();
                await awaitsFor(() => !$("#tabbar-context-menu").hasClass("open"), "Menu to close");

                // the other way round, the untitled file is current and a file on disk is right-clicked
                MainViewManager._edit("first-pane", untitledDoc);
                await awaitsFor(() => isTabActive(untitledPath), "Untitled file to be current");
                await openContextMenuOfTab(getTab(testFilePath));
                await awaitsFor(
                    function () {
                        return !itemDisabled(Strings.CMD_FILE_RENAME) && !itemDisabled(Strings.CMD_SHOW_IN_TREE);
                    },
                    "Rename and show in file tree to be enabled for the file on disk"
                );
            });
        });

        describe("Second Pane Menus", function () {
            let paneFiles;

            beforeEach(async function () {
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 2);
                paneFiles = await createTestFiles(3, "second-pane-menu", "// second pane menu test file");
                await addToWorkingSet([paneFiles[0], paneFiles[1]], "second-pane");
                await addToWorkingSet([paneFiles[2]], "first-pane");
                await waitForTabs([paneFiles[0], paneFiles[1]], "second-pane");
                await waitForTabs([paneFiles[2]], "first-pane");
                expect(MainViewManager.getActivePaneId()).toBe("first-pane");
            });

            afterEach(async function () {
                testWindow.brackets.test.Menus.closeAll();
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
            });

            it("should close and pin the right-clicked tab of the inactive pane", async function () {
                await openContextMenuOfTab(getTabInPane(paneFiles[1], "second-pane"));
                expect(MainViewManager.getActivePaneId()).toBe("first-pane");
                getMenuItemByText("tabbar-context-menu", Strings.CMD_FILE_CLOSE).click();
                cancelSaveDialog();
                await awaitsFor(
                    function () {
                        return !tabExistsInPane(paneFiles[1], "second-pane");
                    },
                    "Right-clicked tab of the second pane to close"
                );
                expect(MainViewManager.findInWorkingSet("second-pane", paneFiles[1])).toBe(-1);
                expect(MainViewManager.getWorkingSet("first-pane").map((file) => file.fullPath))
                    .toEqual([paneFiles[2]]);
                expect(tabExistsInPane(paneFiles[2], "first-pane")).toBe(true);

                await openContextMenuOfTab(getTabInPane(paneFiles[0], "second-pane"));
                getMenuItemByText("tabbar-context-menu", Strings.PIN_TAB).click();
                await awaitsFor(
                    function () {
                        return MainViewManager.isPathPinned("second-pane", paneFiles[0]) &&
                            getTabInPane(paneFiles[0], "second-pane").hasClass("pinned");
                    },
                    "Right-clicked tab of the second pane to be pinned"
                );
                expect(MainViewManager.isPathPinned("first-pane", paneFiles[2])).toBe(false);
            });

            it("should close and pin the right-clicked working set item of the inactive pane", async function () {
                await openContextMenuOfWorkingSetItem(getWorkingSetItemInPane(paneFiles[1], "second-pane"));
                expect(MainViewManager.getActivePaneId()).toBe("first-pane");
                getMenuItemByText("workingset-context-menu", Strings.CMD_FILE_CLOSE).click();
                cancelSaveDialog();
                await awaitsFor(
                    function () {
                        return getWorkingSetItemInPane(paneFiles[1], "second-pane").length === 0;
                    },
                    "Right-clicked item of the second pane to close"
                );
                expect(MainViewManager.findInWorkingSet("second-pane", paneFiles[1])).toBe(-1);
                expect(MainViewManager.getWorkingSet("first-pane").map((file) => file.fullPath))
                    .toEqual([paneFiles[2]]);
                expect(getWorkingSetItemInPane(paneFiles[2], "first-pane").length).toBe(1);

                await openContextMenuOfWorkingSetItem(getWorkingSetItemInPane(paneFiles[0], "second-pane"));
                getMenuItemByText("workingset-context-menu", Strings.CMD_FILE_PIN).click();
                await awaitsFor(
                    function () {
                        const $row = getWorkingSetItemInPane(paneFiles[0], "second-pane");
                        return MainViewManager.isPathPinned("second-pane", paneFiles[0]) &&
                            $row.find(".file-status-icon.pinned").length === 1;
                    },
                    "Right-clicked item of the second pane to be pinned"
                );
                expect(MainViewManager.isPathPinned("first-pane", paneFiles[2])).toBe(false);
            });
        });

        describe("Cross Pane Drag", function () {
            afterEach(async function () {
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
            });

            it("should keep the drop position when the target pane already has the file", async function () {
                MainViewManager.setLayoutScheme(1, 2);
                const files = await createTestFiles(3, "both-panes", "// file in both panes");
                await addToWorkingSet([files[1]], "first-pane");
                await addToWorkingSet([files[0], files[1], files[2]], "second-pane");
                await waitForTabs([files[1]], "first-pane");
                await waitForTabs([files[0], files[1], files[2]], "second-pane");

                // dropping the file from the first pane in front of the last tab of the second pane leaves
                // it where it already is, instead of pushing it past that tab
                const sourceTab = $(`#phoenix-tab-bar .tab[data-path="${files[1]}"]`);
                const targetTab = $(`#phoenix-tab-bar-2 .tab[data-path="${files[2]}"]`);
                const dropX = targetTab[0].getBoundingClientRect().left + 5;
                sourceTab.trigger($.Event("dragstart", {
                    originalEvent: { dataTransfer: { setData: function () {}, effectAllowed: "move" } }
                }));
                targetTab.trigger($.Event("dragenter"));
                targetTab.trigger($.Event("dragover", {
                    originalEvent: { dataTransfer: { dropEffect: "move" }, clientX: dropX },
                    preventDefault: function () {}
                }));
                targetTab.trigger($.Event("drop", {
                    originalEvent: { dataTransfer: {}, clientX: dropX },
                    preventDefault: function () {},
                    stopPropagation: function () {}
                }));
                sourceTab.trigger($.Event("dragend"));

                await awaitsFor(
                    () => !tabExistsInPane(files[1], "first-pane") &&
                        MainViewManager.getCurrentlyViewedPath("second-pane") === files[1],
                    "File to leave the first pane and show in the second"
                );
                expect(MainViewManager.getWorkingSet("second-pane").map((file) => file.fullPath)).toEqual(files);
                expect(MainViewManager.getWorkingSet("first-pane").length).toBe(0);
            });
        });

        describe("Number of Tabs Preference", function () {
            beforeEach(async function () {
                // Enable the tab bar feature with default settings
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();
            });

            afterEach(async function () {
                // Reset preferences to default
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });
            });

            it("should show all tabs when numberOfTabs is set to -1", async function () {
                // Create several test files
                const testFiles = [];
                for (let i = 0; i < 10; i++) {
                    const filePath = testFolder + `/number-test-${i}.js`;
                    testFiles.push(filePath);
                    await jsPromise(SpecRunnerUtils.createTextFile(filePath, `// Number test file ${i}`, FileSystem));
                }

                // Open all the test files
                for (const filePath of testFiles) {
                    await awaitsForDone(
                        CommandManager.execute(Commands.FILE_OPEN, { fullPath: filePath }),
                        `Open file ${filePath}`
                    );
                }

                // Wait for all tabs to appear
                await awaitsFor(
                    function () {
                        return getTabCount() >= testFiles.length;
                    },
                    "All tabs to appear"
                );

                // Verify all tabs are shown
                expect(getTabCount()).toBe(testFiles.length);

                // Clean up - close all the test files
                for (const filePath of testFiles) {
                    const fileToClose = FileSystem.getFileForPath(filePath);
                    const promise = CommandManager.execute(Commands.FILE_CLOSE, { file: fileToClose });
                    cancelSaveDialog();
                    await awaitsForDone(promise, `Close file ${filePath}`);
                }
            });

            it("should limit the number of tabs shown when numberOfTabs is set to a positive value", async function () {
                // Set the preference to show only 5 tabs
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: 5 });

                // Create several test files
                const testFiles = [];
                for (let i = 0; i < 10; i++) {
                    const filePath = testFolder + `/number-test-${i}.js`;
                    testFiles.push(filePath);
                    await jsPromise(SpecRunnerUtils.createTextFile(filePath, `// Number test file ${i}`, FileSystem));
                }

                // Open all the test files
                for (const filePath of testFiles) {
                    await awaitsForDone(
                        CommandManager.execute(Commands.FILE_OPEN, { fullPath: filePath }),
                        `Open file ${filePath}`
                    );
                }

                // Wait for tabs to appear
                await awaitsFor(
                    function () {
                        return getTabCount() > 0;
                    },
                    "Tabs to appear"
                );

                // Verify only 5 tabs are shown
                expect(getTabCount()).toBe(5);

                // Clean up - close all the test files
                for (const filePath of testFiles) {
                    const fileToClose = FileSystem.getFileForPath(filePath);
                    const promise = CommandManager.execute(Commands.FILE_CLOSE, { file: fileToClose });
                    cancelSaveDialog();
                    await awaitsForDone(promise, `Close file ${filePath}`);
                }
            });

            it("should hide the tab bar when numberOfTabs is set to 0", async function () {
                // First open some files with the default setting
                const testFiles = [];
                for (let i = 0; i < 3; i++) {
                    const filePath = testFolder + `/number-test-${i}.js`;
                    testFiles.push(filePath);
                    await jsPromise(SpecRunnerUtils.createTextFile(filePath, `// Number test file ${i}`, FileSystem));
                }

                // Open all the test files
                for (const filePath of testFiles) {
                    await awaitsForDone(
                        CommandManager.execute(Commands.FILE_OPEN, { fullPath: filePath }),
                        `Open file ${filePath}`
                    );
                }

                // Wait for tabs to appear
                await awaitsFor(
                    function () {
                        return getTabCount() > 0;
                    },
                    "Tabs to appear"
                );

                // Verify tab bar is visible
                expect($("#phoenix-tab-bar").is(":visible")).toBe(true);

                // Now set numberOfTabs to 0
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: 0 });

                // Wait for tab bar to disappear
                await awaitsFor(
                    function () {
                        return !$("#phoenix-tab-bar").is(":visible");
                    },
                    "Tab bar to disappear"
                );

                // Verify tab bar is hidden
                expect($("#phoenix-tab-bar").is(":visible")).toBe(false);

                // Clean up - close all the test files
                for (const filePath of testFiles) {
                    const fileToClose = FileSystem.getFileForPath(filePath);
                    const promise = CommandManager.execute(Commands.FILE_CLOSE, { file: fileToClose });
                    cancelSaveDialog();
                    await awaitsForDone(promise, `Close file ${filePath}`);
                }
            });

            it("should apply numberOfTabs preference to both panes", async function () {
                // Set up split pane layout
                MainViewManager.setLayoutScheme(1, 2);

                // Set the preference to show only 3 tabs
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: 3 });

                // Create test files for first pane
                const firstPaneFiles = [];
                for (let i = 0; i < 5; i++) {
                    const filePath = testFolder + `/first-pane-${i}.js`;
                    firstPaneFiles.push(filePath);
                    await jsPromise(SpecRunnerUtils.createTextFile(filePath, `// First pane file ${i}`, FileSystem));
                }

                // Create test files for second pane
                const secondPaneFiles = [];
                for (let i = 0; i < 5; i++) {
                    const filePath = testFolder + `/second-pane-${i}.js`;
                    secondPaneFiles.push(filePath);
                    await jsPromise(SpecRunnerUtils.createTextFile(filePath, `// Second pane file ${i}`, FileSystem));
                }

                // Open files in first pane
                for (const filePath of firstPaneFiles) {
                    await awaitsForDone(
                        CommandManager.execute(Commands.FILE_OPEN, { fullPath: filePath, paneId: "first-pane" }),
                        `Open file ${filePath} in first pane`
                    );
                }

                // Open files in second pane
                for (const filePath of secondPaneFiles) {
                    await awaitsForDone(
                        CommandManager.execute(Commands.FILE_OPEN, { fullPath: filePath, paneId: "second-pane" }),
                        `Open file ${filePath} in second pane`
                    );
                }

                // Wait for both tab bars to appear
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar").is(":visible") && $("#phoenix-tab-bar-2").is(":visible");
                    },
                    "Both tab bars to appear"
                );

                // Verify each pane shows only 3 tabs
                expect($("#phoenix-tab-bar").find(".tab").length).toBe(3);
                expect($("#phoenix-tab-bar-2").find(".tab").length).toBe(3);

                // Change preference to show all tabs
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Wait for all tabs to appear
                await awaitsFor(
                    function () {
                        return (
                            $("#phoenix-tab-bar").find(".tab").length === 5 &&
                            $("#phoenix-tab-bar-2").find(".tab").length === 5
                        );
                    },
                    "All tabs to appear in both panes"
                );

                // Verify all tabs are shown in both panes
                expect($("#phoenix-tab-bar").find(".tab").length).toBe(5);
                expect($("#phoenix-tab-bar-2").find(".tab").length).toBe(5);

                // Change preference to hide tab bars
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: 0 });

                // Wait for both tab bars to disappear
                await awaitsFor(
                    function () {
                        return !$("#phoenix-tab-bar").is(":visible") && !$("#phoenix-tab-bar-2").is(":visible");
                    },
                    "Both tab bars to disappear"
                );

                // Clean up - close all files and reset to single pane
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
            });
        });

        describe("Split Panes", function () {
            beforeEach(async function () {
                // Enable the tab bar feature
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });

                // Close all files to start with a clean state
                await testWindow.closeAllFiles();

                // Set up a horizontal split view (two columns)
                MainViewManager.setLayoutScheme(1, 2);
            });

            afterEach(async function () {
                // Reset to single pane layout
                MainViewManager.setLayoutScheme(1, 1);
            });

            it("should show tab bars in both panes when files are open in both", async function () {
                // Open a file in the first pane
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath, paneId: "first-pane" }),
                    "Open file in first pane"
                );

                // Open a different file in the second pane
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath2, paneId: "second-pane" }),
                    "Open file in second pane"
                );

                // Wait for both tab bars to appear
                await awaitsFor(
                    function () {
                        return isTabBarVisible("first-pane") && isTabBarVisible("second-pane");
                    },
                    "Both tab bars to appear"
                );

                // Verify both tab bars are visible
                expect(isTabBarVisible("first-pane")).toBe(true);
                expect(isTabBarVisible("second-pane")).toBe(true);

                // Verify each pane has the correct tab
                expect(tabExistsInPane(testFilePath, "first-pane")).toBe(true);
                expect(tabExistsInPane(testFilePath2, "second-pane")).toBe(true);
                expect(getPaneTabCount("first-pane")).toBe(1);
                expect(getPaneTabCount("second-pane")).toBe(1);
            });

            it("should hide tab bar in a pane with no files", async function () {
                // Open a file in the first pane only
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath, paneId: "first-pane" }),
                    "Open file in first pane"
                );

                // Wait for the first tab bar to appear
                await awaitsFor(
                    function () {
                        return isTabBarVisible("first-pane");
                    },
                    "First tab bar to appear"
                );

                // Verify first tab bar is visible and second is not
                expect(isTabBarVisible("first-pane")).toBe(true);
                expect(isTabBarVisible("second-pane")).toBe(false);

                // Verify the first pane has the correct tab
                expect(tabExistsInPane(testFilePath, "first-pane")).toBe(true);
                expect(getPaneTabCount("first-pane")).toBe(1);
            });

            it("should update tab bars when moving files between panes", async function () {
                // Open a file in the first pane
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath, paneId: "first-pane" }),
                    "Open file in first pane"
                );

                // Wait for the first tab bar to appear
                await awaitsFor(
                    function () {
                        return isTabBarVisible("first-pane");
                    },
                    "First tab bar to appear"
                );

                // Verify first tab bar is visible and second is not
                expect(isTabBarVisible("first-pane")).toBe(true);
                expect(isTabBarVisible("second-pane")).toBe(false);

                // Move the file to the second pane
                const fileObj = FileSystem.getFileForPath(testFilePath);
                MainViewManager.addToWorkingSet("second-pane", fileObj);

                // Remove from first pane
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_CLOSE, { file: fileObj, paneId: "first-pane" }),
                    "Close file in first pane"
                );

                // Wait for the tab to appear in the second pane and disappear from the first
                await awaitsFor(
                    function () {
                        return (
                            !tabExistsInPane(testFilePath, "first-pane") && tabExistsInPane(testFilePath, "second-pane")
                        );
                    },
                    "Tab to move to second pane"
                );

                // Verify the tab bars visibility has updated
                expect(isTabBarVisible("first-pane")).toBe(false);
                expect(isTabBarVisible("second-pane")).toBe(true);

                // Verify the tab is now in the second pane
                expect(tabExistsInPane(testFilePath, "first-pane")).toBe(false);
                expect(tabExistsInPane(testFilePath, "second-pane")).toBe(true);
                expect(getPaneTabCount("first-pane")).toBe(0);
                expect(getPaneTabCount("second-pane")).toBe(1);
            });

            it("should hide tab bar when closing all files in a pane", async function () {
                // Open files in both panes
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath, paneId: "first-pane" }),
                    "Open file in first pane"
                );
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath2, paneId: "second-pane" }),
                    "Open file in second pane"
                );

                // Wait for both tab bars to appear
                await awaitsFor(
                    function () {
                        return isTabBarVisible("first-pane") && isTabBarVisible("second-pane");
                    },
                    "Both tab bars to appear"
                );

                // Verify both tab bars are visible
                expect(isTabBarVisible("first-pane")).toBe(true);
                expect(isTabBarVisible("second-pane")).toBe(true);

                // Close the file in the second pane
                const fileToClose = FileSystem.getFileForPath(testFilePath2);
                const promise = CommandManager.execute(Commands.FILE_CLOSE, {
                    file: fileToClose,
                    paneId: "second-pane"
                });

                // Cancel the save dialog if it appears
                cancelSaveDialog();

                await awaitsForDone(promise, "Close file in second pane");

                // Wait for the second tab bar to disappear
                await awaitsFor(
                    function () {
                        return !isTabBarVisible("second-pane");
                    },
                    "Second tab bar to disappear"
                );

                // Verify first tab bar is still visible but second is not
                expect(isTabBarVisible("first-pane")).toBe(true);
                expect(isTabBarVisible("second-pane")).toBe(false);

                // Verify the tabs are in the correct panes
                expect(tabExistsInPane(testFilePath, "first-pane")).toBe(true);
                expect(tabExistsInPane(testFilePath2, "second-pane")).toBe(false);
                expect(getPaneTabCount("first-pane")).toBe(1);
                expect(getPaneTabCount("second-pane")).toBe(0);
            });

            it("should keep the active tab of the inactive pane in step with its current file", async function () {
                const files = await createTestFiles(2, "inactive-pane", "// inactive pane file");
                await addToWorkingSet([files[0], files[1]], "second-pane");
                await addToWorkingSet([testFilePath], "first-pane");
                await waitForTabs([files[0], files[1]], "second-pane");
                await waitForTabs([testFilePath], "first-pane");
                expect(MainViewManager.getActivePaneId()).toBe("first-pane");
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar-2 .tab.active").attr("data-path") === files[1];
                    },
                    "Second pane to mark its current file"
                );

                // showing the other file in the second pane without activating the pane is only announced by
                // the pane itself, the tab bar has to pick that up
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, {
                        fullPath: files[0],
                        paneId: "second-pane",
                        options: { noPaneActivate: true }
                    }),
                    "Open the first file in the second pane without activating it"
                );
                expect(MainViewManager.getActivePaneId()).toBe("first-pane");
                expect(MainViewManager.getCurrentlyViewedPath("second-pane")).toBe(files[0]);
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar-2 .tab.active").attr("data-path") === files[0];
                    },
                    "Tab of the inactive pane to follow its current file"
                );
                expect($("#phoenix-tab-bar-2 .tab.active").length).toBe(1);
                expect($("#phoenix-tab-bar .tab.active").attr("data-path")).toBe(testFilePath);
            });

            it("should work correctly with vertical split layout", async function () {
                // Change to vertical split layout (2 rows, 1 column)
                MainViewManager.setLayoutScheme(2, 1);

                // Open a file in the first pane
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath, paneId: "first-pane" }),
                    "Open file in first pane"
                );

                // Open a different file in the second pane
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: testFilePath2, paneId: "second-pane" }),
                    "Open file in second pane"
                );

                // Wait for both tab bars to appear
                await awaitsFor(
                    function () {
                        return isTabBarVisible("first-pane") && isTabBarVisible("second-pane");
                    },
                    "Both tab bars to appear"
                );

                // Verify both tab bars are visible
                expect(isTabBarVisible("first-pane")).toBe(true);
                expect(isTabBarVisible("second-pane")).toBe(true);

                // Verify each pane has the correct tab
                expect(tabExistsInPane(testFilePath, "first-pane")).toBe(true);
                expect(tabExistsInPane(testFilePath2, "second-pane")).toBe(true);
                expect(getPaneTabCount("first-pane")).toBe(1);
                expect(getPaneTabCount("second-pane")).toBe(1);

                // Close the file in the second pane
                const fileToClose = FileSystem.getFileForPath(testFilePath2);
                const promise = CommandManager.execute(Commands.FILE_CLOSE, {
                    file: fileToClose,
                    paneId: "second-pane"
                });

                // Cancel the save dialog if it appears
                cancelSaveDialog();

                await awaitsForDone(promise, "Close file in second pane");

                // Wait for the second tab bar to disappear
                await awaitsFor(
                    function () {
                        return !isTabBarVisible("second-pane");
                    },
                    "Second tab bar to disappear"
                );

                // Verify first tab bar is still visible but second is not
                expect(isTabBarVisible("first-pane")).toBe(true);
                expect(isTabBarVisible("second-pane")).toBe(false);

                // Reset to horizontal split for other tests
                MainViewManager.setLayoutScheme(1, 2);
            });
        });

        describe("Tab Bar Scrolling", function () {
            let longTestFilePaths = [];

            beforeAll(async function () {
                // These files are read-only fixtures; create them once rather than rewriting
                // the same 15 files and notifying filesystem watchers before every scroll test.
                for (let i = 1; i <= 15; i++) {
                    const filePath = testFolder + `/scroll-test-file-${i}.js`;
                    longTestFilePaths.push(filePath);
                    await jsPromise(
                        SpecRunnerUtils.createTextFile(filePath, `// Test file ${i} for scrolling`, FileSystem)
                    );
                }
            }, 30000);

            beforeEach(async function () {
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
                PreferencesManager.set("tabBar.options", { showTabBar: true, numberOfTabs: -1 });
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: longTestFilePaths[0] }),
                    "Open the scrolling fixture's active editor"
                );
                // Working-set entries create real tabs without loading and linting 14 more
                // editors. These cases exercise tab scrolling, not document activation.
                for (const filePath of longTestFilePaths.slice(1)) {
                    MainViewManager.addToWorkingSet("first-pane", FileSystem.getFileForPath(filePath));
                }

                // Require actual overflow so no scrolling assertion can pass without scrolling.
                await awaitsFor(
                    function () {
                        const tabBar = $("#phoenix-tab-bar")[0];
                        return getTabCount() === longTestFilePaths.length && tabBar &&
                            tabBar.scrollWidth > tabBar.clientWidth;
                    },
                    "All scrolling tabs to be created and overflow"
                );
                $("#phoenix-tab-bar").scrollLeft(0);
            });

            afterEach(async function () {
                await testWindow.closeAllFiles();
                MainViewManager.setLayoutScheme(1, 1);
            });

            it("should scroll tab bar horizontally when mouse wheel is scrolled", function () {
                const $tabBar = $("#phoenix-tab-bar");
                expect($tabBar.length).toBe(1);

                // Get initial scroll position
                const initialScrollLeft = $tabBar.scrollLeft();

                // Create a wheel event for scrolling down (should scroll right)
                const wheelEventDown = $.Event("wheel");
                wheelEventDown.originalEvent = { deltaY: 100 }; // Positive deltaY = scroll down/right

                // Trigger the wheel event
                $tabBar.trigger(wheelEventDown);

                // Check that scroll position has changed to the right
                const scrollAfterDown = $tabBar.scrollLeft();
                expect(scrollAfterDown).toBeGreaterThan(initialScrollLeft);
                // scroll is deltaY * 2.5 unless clamped; the clamp point varies with font metrics
                const maxScrollLeft = $tabBar[0].scrollWidth - $tabBar[0].clientWidth;
                const expectedDown = Math.min(100 * 2.5, maxScrollLeft - initialScrollLeft);
                expect(scrollAfterDown - initialScrollLeft).toBeCloseTo(expectedDown, 0);

                // Create a wheel event for scrolling up (should scroll left)
                const wheelEventUp = $.Event("wheel");
                wheelEventUp.originalEvent = { deltaY: -100 }; // Negative deltaY = scroll up/left

                // Trigger the wheel event
                $tabBar.trigger(wheelEventUp);

                // Check that scroll position has moved left from the previous position
                const scrollAfterUp = $tabBar.scrollLeft();
                expect(scrollAfterUp).toBeLessThan(scrollAfterDown);
                const expectedUp = Math.min(100 * 2.5, scrollAfterDown);
                expect(scrollAfterDown - scrollAfterUp).toBeCloseTo(expectedUp, 0);
            });

            it("should scroll tab bar with trackpad scrolling", function () {
                const $tabBar = $("#phoenix-tab-bar");
                expect($tabBar.length).toBe(1);

                // Get initial scroll position
                const initialScrollLeft = $tabBar.scrollLeft();

                // Create a wheel event simulating trackpad scrolling (smaller deltaY values)
                const trackpadEvent = $.Event("wheel");
                trackpadEvent.originalEvent = { deltaY: 25 }; // Smaller value typical of trackpad

                // Trigger the trackpad scrolling event multiple times
                for (let i = 0; i < 4; i++) {
                    $tabBar.trigger(trackpadEvent);
                }

                // Check that scroll position has changed
                const scrollAfterTrackpad = $tabBar.scrollLeft();
                expect(scrollAfterTrackpad).toBeGreaterThan(initialScrollLeft);
            });

            it("should scroll second pane tab bar when it exists", async function () {
                // Create the second pane first
                MainViewManager.setLayoutScheme(1, 2);

                // Wait for the layout to be created
                await awaitsFor(
                    function () {
                        return MainViewManager.getPaneIdList().length === 2;
                    },
                    "Second pane to be created"
                );

                // Open a file in the second pane to create the second tab bar
                await awaitsForDone(
                    CommandManager.execute(Commands.FILE_OPEN, {
                        fullPath: longTestFilePaths[0],
                        paneId: "second-pane"
                    }),
                    "Open file in second pane"
                );

                // Wait for second tab bar to appear
                await awaitsFor(
                    function () {
                        return $("#phoenix-tab-bar-2").length > 0;
                    },
                    "Second tab bar to appear"
                );

                const $tabBar2 = $("#phoenix-tab-bar-2");
                expect($tabBar2.length).toBe(1);

                // Open multiple files in second pane to enable scrolling
                for (let i = 1; i < 8; i++) {
                    MainViewManager.addToWorkingSet("second-pane", FileSystem.getFileForPath(longTestFilePaths[i]));
                }

                // Wait for tabs to be rendered in second pane
                await awaitsFor(
                    function () {
                        return $tabBar2.find(".tab").length >= 8;
                    },
                    "Tabs to be created in second pane"
                );

                // Get initial scroll position of second tab bar
                const initialScrollLeft = $tabBar2.scrollLeft();

                // Create a wheel event for scrolling
                const wheelEvent = $.Event("wheel");
                wheelEvent.originalEvent = { deltaY: 150 };

                // Trigger the wheel event on second tab bar
                $tabBar2.trigger(wheelEvent);

                // Check that scroll position has changed
                const scrollAfterWheel = $tabBar2.scrollLeft();
                expect(scrollAfterWheel).toBeGreaterThan(initialScrollLeft);
                // Verify the scroll amount is proportional to deltaY
                expect(scrollAfterWheel - initialScrollLeft).toBeCloseTo(150 * 2.5, 0);

                // Reset layout scheme back to single pane
                MainViewManager.setLayoutScheme(1, 1);
            });

            it("should calculate correct scroll amount based on deltaY", function () {
                const $tabBar = $("#phoenix-tab-bar");
                expect($tabBar.length).toBe(1);

                // Set initial scroll position to middle to allow scrolling in both directions
                const maxScroll = $tabBar[0].scrollWidth - $tabBar[0].clientWidth;
                expect(maxScroll).toBeGreaterThan(200);
                const midScroll = Math.floor(maxScroll / 2);
                $tabBar.scrollLeft(midScroll);

                // Test positive deltaY (scroll right)
                const initialScrollLeft = $tabBar.scrollLeft();
                const wheelEventRight = $.Event("wheel");
                wheelEventRight.originalEvent = { deltaY: 40 };
                $tabBar.trigger(wheelEventRight);

                const scrollAfterRight = $tabBar.scrollLeft();
                expect(scrollAfterRight).toBeGreaterThan(initialScrollLeft);
                expect(scrollAfterRight - initialScrollLeft).toBeCloseTo(40 * 2.5, 0);

                // Reset and test negative deltaY (scroll left)
                $tabBar.scrollLeft(midScroll);
                const wheelEventLeft = $.Event("wheel");
                wheelEventLeft.originalEvent = { deltaY: -40 };
                $tabBar.trigger(wheelEventLeft);

                const scrollAfterLeft = $tabBar.scrollLeft();
                expect(scrollAfterLeft).toBeLessThan(midScroll);
                expect(midScroll - scrollAfterLeft).toBeCloseTo(40 * 2.5, 0);
            });

            it("should not scroll beyond the scrollable bounds", function () {
                const $tabBar = $("#phoenix-tab-bar");
                expect($tabBar.length).toBe(1);

                // Get the maximum scrollable width
                const maxScrollLeft = $tabBar[0].scrollWidth - $tabBar[0].clientWidth;

                // Scroll far to the right
                $tabBar.scrollLeft(maxScrollLeft + 1000); // Try to scroll beyond max

                // Create a wheel event to scroll further right
                const wheelEventRight = $.Event("wheel");
                wheelEventRight.originalEvent = { deltaY: 500 }; // Large scroll right
                $tabBar.trigger(wheelEventRight);

                // Should not exceed maximum scroll. scrollWidth and clientWidth are rounded to whole
                // pixels while the tabs have fractional widths, so the real end can sit a pixel past them
                expect($tabBar.scrollLeft()).toBeLessThanOrEqual(maxScrollLeft + 2);

                // Scroll far to the left
                $tabBar.scrollLeft(-1000); // Try to scroll beyond minimum

                // Create a wheel event to scroll further left
                const wheelEventLeft = $.Event("wheel");
                wheelEventLeft.originalEvent = { deltaY: -500 }; // Large scroll left
                $tabBar.trigger(wheelEventLeft);

                // Should not go below 0 (a small floating point tolerance)
                expect($tabBar.scrollLeft()).toBeGreaterThanOrEqual(-1);
            });
        });
    });
});
