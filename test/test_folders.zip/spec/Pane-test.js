/*
 * GNU AGPL-3.0 License
 *
 * Copyright (c) 2021 - present core.ai . All rights reserved.
 * Original work Copyright (c) 2014 - 2021 Adobe Systems Incorporated. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see https://opensource.org/licenses/AGPL-3.0.
 *
 */


/*global describe, it, expect, beforeEach, afterEach, jasmine, spyOn */

define(function (require, exports, module) {


    var Pane = require("view/Pane").Pane;

    describe("Pane", function () {
        var myPane,
            myView,
            $container = $("<div>");

        function createMockPane(name) {
            return new Pane(name, $container);
        }
        function createTestPane() {
            myPane = createMockPane("test-pane");
        }

        function createMockView(name) {
            var $view = $("<div>");
            return {
                $el: $view,
                file: {
                    fullPath: name
                },
                getFullPath: function () {
                    return this.file.fullPath;
                },
                getFile: function () {
                    return this.file;
                },
                updateLayout: function (hint) {
                },
                destroy: function () {
                },
                getScrollPos: function () {
                    return "1234";
                },
                adjustScrollPos: function () {
                },
                getViewState: function () {
                },
                notifyContainerChange: function () {
                },
                notifyVisibilityChange: function (visible) {
                    this._visible = visible;
                },
                markPaneId: function (id) {
                    this._paneId = id;
                }

            };
        }

        function createTestView() {
            myView = createMockView("test-view");
        }


        beforeEach(function () {
            createTestPane();
            createTestView();
        });

        afterEach(function () {
            myPane.destroy();
            myPane = null;
            myView = null;
            expect($container.contents().length).toEqual(0);
        });

        describe("Basic Pane Attributes", function () {
            it("should have an id", function () {
                expect(myPane.id).toEqual("test-pane");
            });
            it("should have an element", function () {
                expect(myPane.$el.length).toEqual(1);
                expect($container.find(myPane.$el).length).toEqual(1);
            });
            it("should not allow you to change the id", function () {
                myPane.id = "junk";
                expect(myPane.id).toEqual("test-pane");
            });
        });
        describe("View management", function () {
            beforeEach(function () {
                myPane.addView(myView);
            });
            it("should be added to pane's view map", function () {
                expect(myPane._views[myView.getFullPath()]).toEqual(myView);
            });
            it("should show a view", function () {
                spyOn(myView, "notifyVisibilityChange").and.callThrough();
                spyOn(myView, "getFile").and.callThrough();
                spyOn(myView, "updateLayout");

                myPane.showView(myView);

                expect(myView.notifyVisibilityChange).toHaveBeenCalled();
                expect(myView.updateLayout).toHaveBeenCalled();
                expect(myView.getFile).toHaveBeenCalled();
                expect(myView._visible).toBeTruthy();
            });
            it("should report currents", function () {
                myPane.showView(myView);
                expect(myPane._currentView).toEqual(myView);
                expect(myPane.getCurrentlyViewedFile()).toEqual(myView.getFile());
                expect(myPane.getCurrentlyViewedPath()).toEqual(myView.getFullPath());
            });
            it("should report whether or not view is needed", function () {
                expect(myPane._isViewNeeded(myView)).toBeFalsy();
                myPane.showView(myView);
                expect(myPane._isViewNeeded(myView)).toBeTruthy();
            });
            it("should not show interstitial page after showing a view", function () {
                myPane.showView(myView);
                expect(myPane.$el.find(".not-editor").css("display")).toEqual("none");
            });
            it("should destroy a view", function () {
                spyOn(myView, "destroy");

                myPane.showView(myView);
                myPane._reset();

                expect(Object.keys(myPane._views).length).toBe(0);
                expect(myView.destroy).toHaveBeenCalled();
            });
            it("should show interstitial page when no view is displayed", function () {
                expect(myPane.$el.find(".not-editor").css("display")).toBeFalsy();

                myPane.showView(myView);
                expect(myPane.$el.find(".not-editor").css("display")).toEqual("none");

                myPane._reset();
                expect(myPane.$el.find(".not-editor").css("display")).toBeFalsy();
            });
            it("should destroy view when new view is added", function () {
                var secondView = createMockView("second-view");
                spyOn(myView, "destroy");

                myPane.addView(secondView);
                myPane.showView(myView);
                myPane.showView(secondView);

                expect(myView.destroy).toHaveBeenCalled();
            });
            it("should remove view when file is deleted", function () {
                spyOn(myView, "destroy");
                myPane.showView(myView);
                myPane._handleFileDeleted(undefined, myView.getFullPath());

                expect(myView.destroy).toHaveBeenCalled();
                expect(myPane.$el.find(".not-editor").css("display")).toBeFalsy();
            });
            it("should rename view map entry when file is renamed", function () {
                myPane._handleFileNameChange(undefined, myView.getFullPath(), "xxxx");
                expect(myPane._views.xxxx).toEqual(myView);
            });
            it("should swap view container when pane is merged with another", function () {
                var secondView = createMockView("second-view"),
                    secondPane = createMockPane("second-pane");

                spyOn(secondView, "notifyContainerChange");
                spyOn(secondView, "destroy");

                myPane.addToViewList(myView.getFile());

                secondPane.addToViewList(secondView.getFile());
                secondPane.addView(secondView);

                myPane.showView(myView);
                secondPane.showView(secondView);

                myPane.mergeFrom(secondPane);
                expect(secondView.notifyContainerChange).toHaveBeenCalled();
                expect(secondView.destroy).not.toHaveBeenCalled();

                secondPane.destroy();
            });
            it("should destroy temporary views when merging panes", function () {
                var secondView = createMockView("second-view"),
                    secondPane = createMockPane("second-pane");

                spyOn(secondView, "destroy");

                myPane.addToViewList(myView.getFile());

                secondPane.addView(secondView);

                myPane.showView(myView);
                secondPane.showView(secondView);

                myPane.mergeFrom(secondPane);
                expect(secondView.destroy).toHaveBeenCalled();

                secondPane.destroy();
            });
            it("should interstitial page after merging", function () {
                var secondView = createMockView("second-view"),
                    secondPane = createMockPane("second-pane");

                myPane.addToViewList(myView.getFile());

                secondPane.addView(secondView);

                myPane.showView(myView);
                secondPane.showView(secondView);

                myPane.mergeFrom(secondPane);
                expect(secondPane.$el.find(".not-editor").css("display")).toBeFalsy();

                secondPane.destroy();
            });
            it("should hide current view when merging", function () {
                var secondView = createMockView("second-view"),
                    secondPane = createMockPane("second-pane");

                myPane.addToViewList(myView.getFile());

                secondPane.addToViewList(secondView.getFile());
                secondPane.addView(secondView);

                myPane.addView(myView, true);
                secondPane.addView(secondView, true);

                spyOn(secondPane, "_setViewVisibility");

                myPane.mergeFrom(secondPane);

                expect(secondPane._setViewVisibility).toHaveBeenCalled();
                expect(secondPane._setViewVisibility.calls.all()[0].args[0]).toBe(secondView);
                expect(secondPane._setViewVisibility.calls.all()[0].args[1]).toBeFalsy();

                secondPane.destroy();
            });
            it("should not switch views when adding another view", function () {
                var secondView = createMockView("second-view");

                myPane.showView(myView);
                myPane.addView(secondView);
                expect(myPane._currentView).toEqual(myView);
            });
            it("should switch views when removing view", function () {
                spyOn(myPane, "_execOpenFile").and.callFake(function (fullPath) {
                    myPane.showView(myPane._views[fullPath]);
                    return new $.Deferred().resolve().promise();
                });

                var secondView = createMockView("second-view");

                myPane.addToViewList(myView.getFile());
                myPane.addToViewList(secondView.getFile());
                myPane.addView(secondView);

                myPane.showView(myView);
                myPane.showView(secondView);

                myPane.removeView(secondView.getFile());
                expect(myPane._currentView).toEqual(myView);
            });
            it("should show interstitial when showing the next file fails", function () {
                spyOn(myPane, "_execOpenFile").and.callFake(function (fullPath) {
                    return new $.Deferred().reject().promise();
                });

                var secondView = createMockView("second-view");

                spyOn(myPane, "_hideCurrentView").and.callThrough();
                spyOn(myPane, "showInterstitial").and.callThrough();

                myPane.addToViewList(myView.getFile());
                myPane.addToViewList(secondView.getFile());
                myPane.addView(secondView);

                myPane.showView(myView);
                myPane.showView(secondView);

                myPane.removeView(secondView.getFile());
                expect(myPane._currentView).toEqual(null);
                // should be called twice --
                //  the second time to show the interstitial due to the removal
                expect(myPane.showInterstitial.calls.all()[1].args[0]).toBeTruthy();
                expect(myPane._hideCurrentView).toHaveBeenCalled();
                expect(myPane._views.hasOwnProperty(secondView.getFile().fullPath)).toBeFalsy();
            });
            it("should not switch views when removing view", function () {
                spyOn(myPane, "_execOpenFile");

                var secondView = createMockView("second-view");

                myPane.addToViewList(myView.getFile());
                myPane.addToViewList(secondView.getFile());
                myPane.addView(secondView);

                myPane.showView(myView);
                myPane.showView(secondView);

                myPane.removeView(secondView.getFile(), true);
                expect(myPane._currentView).toEqual(null);
                expect(myPane._execOpenFile).not.toHaveBeenCalled();
            });
            it("should hide view when switching views", function () {
                var secondView = createMockView("second-view");

                myPane.addToViewList(myView.getFile());
                myPane.addToViewList(secondView.getFile());
                myPane.addView(secondView);

                myPane.showView(myView);
                myPane.showView(secondView);

                expect(myView._visible).toBeFalsy();
            });
        });
        describe("List Management", function () {
            it("should get added to all lists", function () {
                myPane.addToViewList(myView.getFile());

                expect(myPane._viewList.length).toEqual(1);
                expect(myPane._viewListAddedOrder.length).toEqual(1);
                expect(myPane._viewListMRUOrder.length).toEqual(1);
            });
            it("should get removed from all lists", function () {
                myPane.addToViewList(myView.getFile());
                myPane.addView(myView);
                myPane.showView(myView);
                myPane.removeView(myView.getFile());

                expect(myPane._viewList.length).toEqual(0);
                expect(myPane._viewListAddedOrder.length).toEqual(0);
                expect(myPane._viewListMRUOrder.length).toEqual(0);
                expect(myPane._views[myView.getFullPath()]).toBeFalsy();
            });
            it("should add all items to the list", function () {
                var secondView = createMockView("second-view");

                myPane.addListToViewList([myView.getFile(), secondView.getFile()]);

                expect(myPane._viewList.length).toEqual(2);
                expect(myPane._viewListAddedOrder.length).toEqual(2);
                expect(myPane._viewListMRUOrder.length).toEqual(2);
            });
            it("should remove all items to the list", function () {
                var secondView = createMockView("second-view");

                myPane.addListToViewList([myView.getFile(), secondView.getFile()]);
                myPane.removeViews([myView.getFile(), secondView.getFile()]);

                expect(myPane._viewList.length).toEqual(0);
                expect(myPane._viewListAddedOrder.length).toEqual(0);
                expect(myPane._viewListMRUOrder.length).toEqual(0);
            });
            it("should walk MRU list in order", function () {
                var i,
                    previous,
                    views = [],
                    files = [];

                for (i = 0; i < 5; i++) {
                    views[i] = createMockView("view/" + i.toString());
                    files[i] = views[i].getFile();
                }

                myPane.addListToViewList(files);

                for (i = 0; i < 5; i++) {
                    previous = myPane.traverseViewListByMRU(1, previous && previous.fullPath);
                    expect(previous.fullPath).toEqual("view/" + i.toString());
                }

                var order = [1, 3, 4, 2, 0];

                for (i = 0; i < order.length; i++) {
                    myPane.makeViewMostRecent(files[order[i]]);
                }

                for (previous = undefined, i = order.length; i > 0; i--) {
                    previous = myPane.traverseViewListByMRU(1, previous && previous.fullPath);
                    expect(previous).toEqual(files[order[i - 1]]);
                }
            });
            it("should swap indices", function () {
                var i,
                    views = [],
                    files = [];

                for (i = 0; i < 5; i++) {
                    views[i] = createMockView("view/" + i.toString());
                    files[i] = views[i].getFile();
                }

                myPane.addListToViewList(files);

                myPane.swapViewListIndexes(0, 4);
                myPane.swapViewListIndexes(1, 3);

                var order = [4, 3, 2, 1, 0];

                for (i = 0; i < order.length; i++) {
                    expect(myPane._viewList[i]).toEqual(files[order[i]]);
                }
            });
            it("should maintain order", function () {
                var i,
                    views = [],
                    files = [];

                for (i = 0; i < 5; i++) {
                    views[i] = createMockView("view/" + i.toString());
                    files[i] = views[i].getFile();
                }

                myPane.addListToViewList(files);

                var order = [1, 3, 4, 2, 0];

                for (i = 0; i < order.length; i++) {
                    myPane.makeViewMostRecent(files[order[i]]);
                }

                myPane.swapViewListIndexes(0, 4);
                myPane.swapViewListIndexes(1, 3);

                files.reverse();

                for (i = 0; i < files.length; i++) {
                    expect(myPane._viewListAddedOrder[i]).toEqual(files[i]);
                }
            });
        });
        describe("Temporary views", function () {
            it("should report the current view while its file is not in the view list", function () {
                createTestPane();
                const view = createMockView("/temp/a.js");
                myPane.addView(view);
                myPane.showView(view);
                expect(myPane.getTemporaryViewFile()).toBe(view.getFile());

                myPane.addToViewList(view.getFile());
                expect(myPane.getTemporaryViewFile()).toBe(null);
            });

            it("should not report a closed file whose view waits for the next one", function () {
                createTestPane();
                const first = createMockView("/temp/first.js");
                const second = createMockView("/temp/second.js");
                myPane.addToViewList(first.getFile());
                myPane.addView(first);
                myPane.addToViewList(second.getFile());
                myPane.addView(second);
                myPane.showView(first);

                myPane._doRemove(first.getFile(), true);
                expect(myPane.getCurrentlyViewedPath()).toBe("/temp/first.js");
                expect(myPane.getTemporaryViewFile()).toBe(null);

                myPane.showView(second);
                expect(myPane.getTemporaryViewFile()).toBe(null);

                const preview = createMockView("/temp/preview.js");
                myPane.addView(preview);
                myPane.showView(preview);
                expect(myPane.getTemporaryViewFile()).toBe(preview.getFile());
            });

            it("should announce the rename of a file that is only being looked at", function () {
                createTestPane();
                const view = createMockView("/temp/old.js");
                myPane.addView(view);
                myPane.showView(view);
                const spy = jasmine.createSpy("viewListChange");
                myPane.on("viewListChange", spy);

                // the file system renames the File object before the event arrives
                view.file.fullPath = "/temp/new.js";
                myPane._handleFileNameChange(null, "/temp/old.js", "/temp/new.js");
                expect(spy).toHaveBeenCalled();
                expect(myPane._views["/temp/new.js"]).toBe(view);
                expect(myPane.getTemporaryViewFile().fullPath).toBe("/temp/new.js");
            });
        });

        describe("Pinning", function () {
            let files;

            function paths() {
                return myPane._viewList.map(function (file) {
                    return file.fullPath;
                });
            }

            beforeEach(function () {
                files = [];
                for (let i = 0; i < 4; i++) {
                    files[i] = createMockView("/pin/" + i.toString()).getFile();
                }
                myPane.addListToViewList(files);
            });

            it("should move a pinned file to the front and an unpinned one to the start of the unpinned files", function () {
                expect(myPane.setPathPinned("/pin/2", true)).toBe(true);
                expect(paths()).toEqual(["/pin/2", "/pin/0", "/pin/1", "/pin/3"]);
                expect(myPane.setPathPinned("/pin/3", true)).toBe(true);
                expect(paths()).toEqual(["/pin/2", "/pin/3", "/pin/0", "/pin/1"]);
                expect(myPane.getPinnedCount()).toEqual(2);
                expect(myPane.isPathPinned("/pin/3")).toBe(true);

                expect(myPane.setPathPinned("/pin/2", false)).toBe(true);
                expect(paths()).toEqual(["/pin/3", "/pin/2", "/pin/0", "/pin/1"]);
                expect(myPane.isPathPinned("/pin/2")).toBe(false);
                expect(myPane.getPinnedCount()).toEqual(1);

                expect(myPane.setPathPinned("/pin/2", false)).toBe(false);
                expect(myPane.setPathPinned("/not/there", true)).toBe(false);
            });

            it("should pin a file moved in front of a pinned file and unpin one moved behind an unpinned file", function () {
                myPane.setPathPinned("/pin/0", true);

                myPane.moveWorkingSetItem(3, 0);
                expect(paths()).toEqual(["/pin/3", "/pin/0", "/pin/1", "/pin/2"]);
                expect(myPane.isPathPinned("/pin/3")).toBe(true);

                myPane.moveWorkingSetItem(1, 3);
                expect(paths()).toEqual(["/pin/3", "/pin/1", "/pin/2", "/pin/0"]);
                expect(myPane.isPathPinned("/pin/0")).toBe(false);

                // dropping right behind the pinned files keeps the file as it was
                myPane.moveWorkingSetItem(3, 1);
                expect(paths()).toEqual(["/pin/3", "/pin/0", "/pin/1", "/pin/2"]);
                expect(myPane.isPathPinned("/pin/0")).toBe(false);
                expect(myPane.getPinnedCount()).toEqual(1);
            });

            it("should keep pinned files in front when sorting", function () {
                myPane.setPathPinned("/pin/3", true);
                myPane.sortViewList(function (paneId, file1, file2) {
                    return file2.fullPath.localeCompare(file1.fullPath);
                });
                expect(paths()).toEqual(["/pin/3", "/pin/2", "/pin/1", "/pin/0"]);

                myPane.setPathPinned("/pin/0", true);
                myPane.sortViewList(function (paneId, file1, file2) {
                    return file1.fullPath.localeCompare(file2.fullPath);
                });
                expect(paths()).toEqual(["/pin/0", "/pin/3", "/pin/1", "/pin/2"]);
            });

            it("should pin a file added inside the pinned block and keep the others behind the pinned files", function () {
                myPane.setPathPinned("/pin/0", true);
                myPane.setPathPinned("/pin/1", true);
                const inside = createMockView("/pin/inside").getFile(),
                    front = createMockView("/pin/front").getFile();

                expect(myPane.addToViewList(inside, 1)).toEqual(1);
                expect(myPane.isPathPinned("/pin/inside")).toBe(true);
                expect(paths()).toEqual(["/pin/0", "/pin/inside", "/pin/1", "/pin/2", "/pin/3"]);

                // a move from another pane without an index lands right after the pinned files
                expect(myPane._addToViewList(front, { indexRequested: true })).toEqual(3);
                expect(myPane.isPathPinned("/pin/front")).toBe(false);
                expect(paths()).toEqual(["/pin/0", "/pin/inside", "/pin/1", "/pin/front", "/pin/2", "/pin/3"]);
            });

            it("should keep the pinned files of a merged pane pinned and in front", function () {
                myPane.setPathPinned("/pin/2", true);
                const otherPane = createMockPane("other-pane"),
                    otherFiles = [createMockView("/other/a").getFile(), createMockView("/other/b").getFile()];
                otherPane.addListToViewList(otherFiles);
                otherPane.setPathPinned("/other/b", true);

                myPane.mergeFrom(otherPane);
                expect(paths()).toEqual(["/pin/2", "/other/b", "/pin/0", "/pin/1", "/pin/3", "/other/a"]);
                expect(myPane.isPathPinned("/other/b")).toBe(true);
                expect(myPane.isPathPinned("/other/a")).toBe(false);
                expect(myPane.getPinnedCount()).toEqual(2);
                otherPane.destroy();
            });

            it("should move the pinned state along when a pinned file or its folder is renamed", function () {
                myPane.setPathPinned("/pin/1", true);
                // the file system renames the File objects before the event arrives
                files[1].fullPath = "/pin/renamed";
                myPane._handleFileNameChange(null, "/pin/1", "/pin/renamed");
                expect(myPane.isPathPinned("/pin/renamed")).toBe(true);
                expect(myPane.isPathPinned("/pin/1")).toBe(false);

                myPane.setPathPinned("/pin/3", true);
                files.forEach(function (file) {
                    file.fullPath = file.fullPath.replace("/pin/", "/moved/");
                });
                myPane._handleFileNameChange(null, "/pin/", "/moved/");
                expect(myPane.isPathPinned("/moved/renamed")).toBe(true);
                expect(myPane.isPathPinned("/moved/3")).toBe(true);
                expect(myPane.isPathPinned("/pin/3")).toBe(false);
                expect(myPane.getPinnedCount()).toEqual(2);
                expect(paths().slice(0, 2)).toEqual(["/moved/renamed", "/moved/3"]);
            });

            it("should forget the pinned state when the file is removed", function () {
                myPane.setPathPinned("/pin/1", true);
                myPane.removeView(files[1]);
                expect(myPane.isPathPinned("/pin/1")).toBe(false);
                expect(myPane.getPinnedCount()).toEqual(0);
            });

            it("should save and restore the pinned state", function () {
                myPane.setPathPinned("/pin/2", true);
                const state = myPane.saveState();
                expect(state[0].file).toEqual("/pin/2");
                expect(state[0].pinned).toBe(true);
                expect(state[1].pinned).toBeUndefined();

                const otherPane = createMockPane("other-pane");
                otherPane.loadState(state);
                expect(otherPane.getViewList().map(function (file) {
                    return file.fullPath;
                })).toEqual(["/pin/2", "/pin/0", "/pin/1", "/pin/3"]);
                expect(otherPane.isPathPinned("/pin/2")).toBe(true);
                expect(otherPane.getPinnedCount()).toEqual(1);
                otherPane.destroy();
            });
        });
        describe("Dispatch events", function () {
            beforeEach(function () {
                myPane.addView(myView);
            });
            it("should dispatch events when a file is removed", function () {
                var eventHandler = jasmine.createSpy();

                myPane.on("viewListChange.test", eventHandler);

                myPane.addToViewList(myView.getFile());
                myPane.showView(myView);
                myPane._handleFileDeleted(undefined, myView.getFullPath());

                expect(eventHandler).toHaveBeenCalled();
                myPane.off(".test");
            });
            it("should dispatch events when file is renamed", function () {
                var eventHandler = jasmine.createSpy();

                myPane.on("viewListChange.test", eventHandler);

                myPane.addToViewList(myView.getFile());
                myPane.showView(myView);

                var oldPath = myView.getFullPath();
                myView.file.fullPath = "xxxx";

                myPane._handleFileNameChange(undefined, oldPath, myView.getFullPath());

                expect(eventHandler).toHaveBeenCalled();
                myPane.off(".test");
            });
            it("should dispatch events when the view has changed", function () {
                var eventHandler = jasmine.createSpy();

                myPane.on("currentViewChange.test", eventHandler);

                myPane.addToViewList(myView.getFile());
                myPane.showView(myView);

                expect(eventHandler).toHaveBeenCalled();
                myPane.off(".test");
            });
            it("should dispatch events when all views are closed", function () {
                var eventHandler = jasmine.createSpy();

                myPane.on("currentViewChange.test", eventHandler);

                myPane.addToViewList(myView.getFile());
                myPane.showView(myView);
                myPane._reset();

                expect(eventHandler.calls.count()).toBe(2);
                myPane.off(".test");
            });
        });
    });
});

