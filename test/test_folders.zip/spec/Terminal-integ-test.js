/*
 * GNU AGPL-3.0 License
 *
 * Copyright (c) 2021 - present core.ai . All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see https://opensource.org/licenses/AGPL-3.0.
 *
 */

/*global describe, it, expect, beforeAll, afterAll, beforeEach, afterEach, awaitsFor, spyOn */

define(function (require, exports, module) {

    if (!Phoenix.isNativeApp) {
        return;
    }

    const SpecRunnerUtils = require("spec/SpecRunnerUtils");
    const Strings = require("strings");
    const StringUtils = require("utils/StringUtils");

    const IS_WINDOWS = Phoenix.platform === "win";
    const IS_MAC = Phoenix.platform === "mac";

    describe("integration:Terminal", function () {
        let testWindow,
            __PR,
            WorkspaceManager,
            testProjectPath;

        const PANEL_ID = "terminal-panel";

        beforeAll(async function () {
            testWindow = await SpecRunnerUtils.createTestWindowAndRun();
            __PR = testWindow.__PR;
            WorkspaceManager = testWindow.brackets.test.WorkspaceManager;

            // Create a real temp directory so the terminal has a
            // physical native path to use as cwd.
            testProjectPath = await SpecRunnerUtils.getTempTestDirectory(
                "/spec/JSUtils-test-files"
            );
            await SpecRunnerUtils.loadProjectInTestWindow(testProjectPath);
        }, 30000);

        afterAll(async function () {
            // Dispose all terminal PTY processes before teardown.
            // panel.hide() keeps terminals alive by design, so we
            // must explicitly kill them.
            if (testWindow) {
                try {
                    const termModule = testWindow.brackets.getModule(
                        "extensionsIntegrated/Terminal/main"
                    );
                    if (termModule && termModule._disposeAll) {
                        await termModule._disposeAll();
                    }
                } catch (e) {
                    // test window may already be torn down
                }
            }
            const panel = WorkspaceManager
                ? WorkspaceManager.getPanelForID(PANEL_ID)
                : null;
            if (panel && panel.isVisible()) {
                panel.hide();
            }
            testWindow = null;
            __PR = null;
            WorkspaceManager = null;
            await SpecRunnerUtils.closeTestWindow();
        }, 30000);

        afterEach(async function () {
            // If a test failed and left a dialog open, dismiss it
            // so the next test starts from a clean state.
            if (testWindow && isDialogOpen()) {
                testWindow.$(".modal.instance .dialog-button")
                    .last().click();
                try {
                    await awaitsFor(function () {
                        return !isDialogOpen();
                    }, "dialog to close", 3000);
                } catch (e) {
                    // ignore — best-effort cleanup
                }
            }
        });

        // --- Helpers ---

        async function openTerminal() {
            await __PR.execCommand(__PR.Commands.VIEW_TERMINAL);
            await awaitsFor(function () {
                return testWindow.$("#terminal-panel").is(":visible");
            }, "terminal panel to be visible", 10000);
        }

        function clickNewTerminal() {
            testWindow.$(".terminal-flyout-new-btn").click();
        }

        function getTerminalCount() {
            return testWindow.$(".terminal-flyout-item").length;
        }

        function clickPanelCloseButton() {
            testWindow.$(
                '.bottom-panel-tab[data-panel-id="terminal-panel"]'
                + ' .bottom-panel-tab-close-btn'
            ).click();
        }

        function isDialogOpen() {
            return testWindow.$(".modal.instance").length >= 1;
        }

        function getDialogTitle() {
            return testWindow.$(
                ".modal.instance .dialog-title"
            ).text();
        }

        function getDialogConfirmButtonText() {
            return testWindow.$(
                ".modal.instance .dialog-button.primary"
            ).text();
        }

        /**
         * Trigger a process refresh so tab titles
         * reflect the current foreground process.
         */
        function triggerFlyoutRefresh() {
            const termModule = testWindow.brackets.getModule(
                "extensionsIntegrated/Terminal/main"
            );
            termModule._refreshAllProcesses();
        }

        /**
         * Wait for the active terminal's shell to initialize.
         * The flyout title text changes from "Terminal" to the
         * shell name (e.g. "bash") once process info is fetched.
         */
        async function waitForShellReady() {
            const termModule = testWindow.brackets.getModule(
                "extensionsIntegrated/Terminal/main"
            );
            // Fail fast if the PTY never started
            await awaitsFor(function () {
                const active = termModule._getActiveTerminal();
                return active && active.isAlive;
            }, "terminal PTY to be alive", 10000);

            // Then wait for process info
            await awaitsFor(function () {
                triggerFlyoutRefresh();
                const title = testWindow.$(
                    ".terminal-flyout-item.active "
                    + ".terminal-flyout-title"
                ).text();
                return title && title !== "Terminal";
            }, "shell to initialize", 10000);
        }

        /**
         * Wait for a child process (e.g. "node") to appear as
         * the active terminal's foreground process in the flyout.
         */
        async function waitForActiveProcess(processName) {
            await awaitsFor(function () {
                triggerFlyoutRefresh();
                const title = testWindow.$(
                    ".terminal-flyout-item.active "
                    + ".terminal-flyout-title"
                ).text();
                return title && title.indexOf(processName) !== -1;
            }, processName + " process to appear in flyout",
            15000);
        }

        /**
         * Write data to the active terminal's PTY via the
         * terminal extension's test helper.
         */
        async function writeToTerminal(text) {
            const termModule = testWindow.brackets.getModule(
                "extensionsIntegrated/Terminal/main"
            );
            await termModule._writeToActiveTerminal(text);
        }

        /**
         * Get the native platform path for the loaded project.
         * Mirrors the same VFS→native conversion the terminal uses.
         */
        function getNativeProjectPath() {
            const Phoenix = testWindow.Phoenix;
            const ProjectManager =
                testWindow.brackets.test.ProjectManager;
            const fullPath =
                ProjectManager.getProjectRoot().fullPath;
            const tauriPrefix = Phoenix.VFS.getTauriDir();
            let nativePath;
            if (fullPath.startsWith(tauriPrefix)) {
                nativePath =
                    Phoenix.fs.getTauriPlatformPath(fullPath);
            } else {
                nativePath = fullPath;
            }
            // Strip trailing slash (terminal does the same)
            if (nativePath.length > 1 &&
                (nativePath.endsWith("/") ||
                 nativePath.endsWith("\\"))) {
                nativePath = nativePath.slice(0, -1);
            }
            return nativePath;
        }

        // --- Tests ---

        describe("Panel basics", function () {
            it("should open terminal in the current project directory",
                async function () {
                    await openTerminal();
                    expect(testWindow.$("#terminal-panel")
                        .is(":visible")).toBeTrue();
                    expect(getTerminalCount()).toBe(1);

                    if (IS_WINDOWS || IS_MAC) {
                        // On Windows, PowerShell/cmd set the title to
                        // their own executable path. On macOS, zsh does
                        // not emit title escape sequences by default.
                        // Just verify the shell started and updated its
                        // title from the default profile name.
                        await waitForShellReady();
                        const flyoutTitle = testWindow.$(
                            ".terminal-flyout-item.active"
                        ).attr("title") || "";
                        expect(flyoutTitle).not.toBe("");
                    } else {
                        // On Linux, verify the cwd by running `pwd`
                        // and checking the terminal buffer. This is
                        // more reliable than checking the terminal
                        // title, which depends on the shell's PS1
                        // including title-setting escape sequences.
                        await waitForShellReady();
                        await writeToTerminal("pwd\r");

                        const expectedPath = getNativeProjectPath();
                        const projectDirName = expectedPath
                            .split("/").pop().split("\\").pop();

                        const termModule = testWindow.brackets
                            .getModule(
                                "extensionsIntegrated/Terminal/main"
                            );
                        await awaitsFor(function () {
                            const active =
                                termModule._getActiveTerminal();
                            if (!active) {
                                return false;
                            }
                            const buffer =
                                active.terminal.buffer.active;
                            for (let i = 0; i < buffer.length; i++) {
                                const line = buffer.getLine(i);
                                if (line && line.translateToString()
                                    .indexOf(projectDirName) !== -1) {
                                    return true;
                                }
                            }
                            return false;
                        }, "pwd output to contain project dir",
                        15000);
                    }
                });

            it("should close single idle terminal without dialog",
                async function () {
                    if (!testWindow.$("#terminal-panel")
                        .is(":visible")) {
                        await openTerminal();
                    }
                    await awaitsFor(function () {
                        return getTerminalCount() === 1;
                    }, "single terminal to exist", 5000);

                    await waitForShellReady();

                    clickPanelCloseButton();

                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to close", 5000);

                    expect(isDialogOpen()).toBeFalse();
                    expect(getTerminalCount()).toBe(0);
                });
        });

        describe("Close confirmation with multiple terminals",
            function () {
                it("should show close-all dialog and cancel keeps panel",
                    async function () {
                        await openTerminal();
                        await awaitsFor(function () {
                            return getTerminalCount() === 1;
                        }, "first terminal", 10000);

                        clickNewTerminal();
                        await awaitsFor(function () {
                            return getTerminalCount() === 2;
                        }, "second terminal", 10000);

                        await waitForShellReady();

                        clickPanelCloseButton();

                        await __PR.waitForModalDialog();

                        expect(getDialogTitle())
                            .toBe(Strings.TERMINAL_CLOSE_ALL_TITLE);
                        expect(getDialogConfirmButtonText())
                            .toBe(Strings.TERMINAL_CLOSE_ALL_BTN);

                        // Cancel
                        __PR.clickDialogButtonID(
                            __PR.Dialogs.DIALOG_BTN_CANCEL
                        );
                        await __PR.waitForModalDialogClosed();

                        expect(testWindow.$("#terminal-panel")
                            .is(":visible")).toBeTrue();
                        expect(getTerminalCount()).toBe(2);
                    });

                it("should close all terminals when confirmed",
                    async function () {
                        // Still 2 terminals from previous test
                        expect(getTerminalCount()).toBe(2);

                        clickPanelCloseButton();
                        await __PR.waitForModalDialog();

                        __PR.clickDialogButtonID(
                            __PR.Dialogs.DIALOG_BTN_OK
                        );
                        await __PR.waitForModalDialogClosed();

                        await awaitsFor(function () {
                            return !testWindow.$("#terminal-panel")
                                .is(":visible");
                        }, "terminal panel to close", 5000);

                        expect(getTerminalCount()).toBe(0);
                    });
            });

        describe("Close confirmation with active process", function () {
            it("should show close-terminal dialog for single terminal",
                async function () {
                    await openTerminal();
                    await awaitsFor(function () {
                        return getTerminalCount() === 1;
                    }, "terminal to be created", 10000);

                    await waitForShellReady();

                    // Start a long-running node process
                    await writeToTerminal(
                        'node -e "setTimeout(()=>{},60000)"\r'
                    );
                    await waitForActiveProcess("node");

                    clickPanelCloseButton();

                    await __PR.waitForModalDialog();


                    expect(getDialogTitle())
                        .toBe(Strings.TERMINAL_CLOSE_SINGLE_TITLE);
                    expect(getDialogConfirmButtonText())
                        .toBe(Strings.TERMINAL_CLOSE_SINGLE_BTN);

                    // Cancel — terminal stays
                    __PR.clickDialogButtonID(
                        __PR.Dialogs.DIALOG_BTN_CANCEL
                    );
                    await __PR.waitForModalDialogClosed();

                    expect(testWindow.$("#terminal-panel")
                        .is(":visible")).toBeTrue();
                    expect(getTerminalCount()).toBe(1);

                    // Now confirm
                    clickPanelCloseButton();
                    await __PR.waitForModalDialog();
                    __PR.clickDialogButtonID(
                        __PR.Dialogs.DIALOG_BTN_OK
                    );
                    await __PR.waitForModalDialogClosed();

                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "panel to close after confirm", 5000);

                    expect(getTerminalCount()).toBe(0);
                });

            it("should show stop-processes dialog with multiple terminals",
                async function () {
                    await openTerminal();
                    await awaitsFor(function () {
                        return getTerminalCount() === 1;
                    }, "first terminal", 10000);

                    clickNewTerminal();
                    await awaitsFor(function () {
                        return getTerminalCount() === 2;
                    }, "second terminal", 10000);

                    await waitForShellReady();

                    await writeToTerminal(
                        'node -e "setTimeout(()=>{},60000)"\r'
                    );
                    await waitForActiveProcess("node");

                    clickPanelCloseButton();

                    await __PR.waitForModalDialog();


                    expect(getDialogTitle())
                        .toBe(Strings.TERMINAL_CLOSE_ALL_TITLE);
                    expect(getDialogConfirmButtonText())
                        .toBe(Strings.TERMINAL_CLOSE_ALL_STOP_BTN);

                    // Cancel
                    __PR.clickDialogButtonID(
                        __PR.Dialogs.DIALOG_BTN_CANCEL
                    );
                    await __PR.waitForModalDialogClosed();

                    expect(getTerminalCount()).toBe(2);

                    // Confirm
                    clickPanelCloseButton();
                    await __PR.waitForModalDialog();
                    __PR.clickDialogButtonID(
                        __PR.Dialogs.DIALOG_BTN_OK
                    );
                    await __PR.waitForModalDialogClosed();

                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "panel to close after confirm", 5000);

                    expect(getTerminalCount()).toBe(0);
                });
        });

        describe("Terminal title management", function () {
            it("should retain custom title while child process runs",
                async function () {
                    await openTerminal();
                    await awaitsFor(function () {
                        return getTerminalCount() === 1;
                    }, "terminal to be created", 10000);

                    await waitForShellReady();

                    // Start a long-running node process that sets a
                    // custom terminal title via escape sequence.
                    await writeToTerminal(
                        'node -e "process.stdout.write('
                        + "'\\x1b]0;MyAppTitle\\x07'"
                        + ');setTimeout(()=>{},60000)"\r'
                    );
                    await waitForActiveProcess("node");

                    // Verify the custom title appears
                    await awaitsFor(function () {
                        triggerFlyoutRefresh();
                        const title = testWindow.$(
                            ".terminal-flyout-item.active"
                        ).attr("title") || "";
                        return title.indexOf("MyAppTitle") !== -1;
                    }, "custom title to appear", 10000);

                    // Trigger several flyout refreshes — the title
                    // must remain stable while the process runs.
                    triggerFlyoutRefresh();
                    const title = testWindow.$(
                        ".terminal-flyout-item.active"
                    ).attr("title") || "";
                    expect(title).toContain("MyAppTitle");

                    // Kill the node process so next test starts clean
                    await writeToTerminal("\x03"); // Ctrl+C
                    await awaitsFor(function () {
                        triggerFlyoutRefresh();
                        const label = testWindow.$(
                            ".terminal-flyout-item.active "
                            + ".terminal-flyout-title"
                        ).text();
                        return label && label.indexOf("node") === -1;
                    }, "node process to exit", 10000);

                    // Clean up
                    clickPanelCloseButton();
                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to close", 5000);
                });

            it("should clear stale title after child process exits",
                async function () {
                    await openTerminal();
                    await awaitsFor(function () {
                        return getTerminalCount() === 1;
                    }, "terminal to be created", 10000);

                    await waitForShellReady();

                    // Start a node process that sets a custom title
                    // then exits after a short delay.
                    await writeToTerminal(
                        'node -e "process.stdout.write('
                        + "'\\x1b]0;TestCustomTitle\\x07'"
                        + ');setTimeout(()=>{},3000)"\r'
                    );
                    await waitForActiveProcess("node");

                    // Verify the custom title appears in the flyout
                    await awaitsFor(function () {
                        triggerFlyoutRefresh();
                        const title = testWindow.$(
                            ".terminal-flyout-item.active"
                        ).attr("title") || "";
                        return title.indexOf("TestCustomTitle") !== -1;
                    }, "custom title to appear", 10000);

                    // Wait for the node process to exit (3s timeout)
                    // and the flyout to reflect the shell again.
                    await awaitsFor(function () {
                        triggerFlyoutRefresh();
                        const title = testWindow.$(
                            ".terminal-flyout-item.active"
                        ).attr("title") || "";
                        return title.indexOf("TestCustomTitle") === -1;
                    }, "stale title to be cleared after exit", 15000);

                    // Wait for the process info to update (async)
                    // so the flyout label reflects the shell, not the
                    // exited child process.
                    await awaitsFor(function () {
                        triggerFlyoutRefresh();
                        const lbl = testWindow.$(
                            ".terminal-flyout-item.active "
                            + ".terminal-flyout-title"
                        ).text();
                        return lbl && lbl.indexOf("node") === -1;
                    }, "flyout label to show shell instead of node",
                    15000);

                    // The flyout label should be back to the shell
                    const label = testWindow.$(
                        ".terminal-flyout-item.active "
                        + ".terminal-flyout-title"
                    ).text();
                    expect(label).not.toBe("");
                    expect(label).not.toContain("node");

                    // Clean up
                    clickPanelCloseButton();
                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to close", 5000);
                });
        });

        describe("Project-switch banner", function () {
            let termModule, secondProjectPath;

            beforeAll(async function () {
                termModule = testWindow.brackets.getModule("extensionsIntegrated/Terminal/main");
                await SpecRunnerUtils.createTempDirectory();
                secondProjectPath = SpecRunnerUtils.getTempDirectory();
            });

            beforeEach(async function () {
                await termModule._disposeAll();
                WorkspaceManager.getPanelForID(PANEL_ID).hide();
                await SpecRunnerUtils.loadProjectInTestWindow(testProjectPath);
            }, 30000);

            afterEach(async function () {
                if (isDialogOpen()) {
                    __PR.clickDialogButtonID(__PR.Dialogs.DIALOG_BTN_CANCEL);
                    await __PR.waitForModalDialogClosed();
                }
                await termModule._disposeAll();
                WorkspaceManager.getPanelForID(PANEL_ID).hide();
                await SpecRunnerUtils.loadProjectInTestWindow(testProjectPath);
            }, 30000);

            afterAll(async function () {
                await SpecRunnerUtils.removeTempDirectory();
            });

            /**
             * Open a real shell and wait for its first prompt output.
             * @return {Promise<TerminalInstance>} The ready terminal.
             */
            async function openReadyTerminal() {
                await openTerminal();
                await waitForShellReady();
                const instance = termModule._getActiveTerminal();
                await instance.firstDataReceived;
                return instance;
            }

            /**
             * Verify the shell's actual directory without depending on its prompt format.
             * @param {TerminalInstance} instance The shell to query.
             * @param {string} path Expected native directory.
             */
            async function expectWorkingDirectory(instance, path) {
                const shell = instance.shellProfile.path.split(/[\\/]/).pop().toLowerCase();
                const command = shell === "cmd.exe" ? "cd"
                    : /^(powershell|pwsh)(\.exe)?$/.test(shell) ? "(Get-Location).Path" : "pwd";
                await instance.firstDataReceived;
                await termModule.getNodeConnector().execPeer("writeTerminal", {id: instance.id, data: command + "\r"});
                await awaitsFor(function () {
                    const buffer = instance.terminal.buffer.active;
                    let text = "";
                    for (let i = 0; i < buffer.length; i++) {
                        text += buffer.getLine(i).translateToString();
                    }
                    return text.includes(path);
                }, "shell to report the new project directory", 10000);
            }

            /**
             * Report a busy terminal while keeping real PTY creation, input and disposal.
             * @return {jasmine.Spy} Connector spy for checking restart calls.
             */
            function reportActiveProcess() {
                const connector = termModule.getNodeConnector();
                const execPeer = connector.execPeer.bind(connector);
                return spyOn(connector, "execPeer").and.callFake(function (method, params) {
                    if (method === "getTerminalProcess") {
                        return Promise.resolve({process: "test-running-task"});
                    }
                    return execPeer(method, params);
                });
            }

            it("does not show a banner when no terminals exist", async function () {
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
                const instance = await openReadyTerminal();
                expect(instance.cwd).toBe(getNativeProjectPath());
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
            }, 30000);

            it("keeps sessions and dismisses the notice until the next project switch", async function () {
                const instance = await openReadyTerminal();
                await writeToTerminal("cd ..\r");
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                expect(testWindow.$(".terminal-project-banner").is(":visible")).toBeTrue();
                expect(testWindow.$(".terminal-project-path").text())
                    .toBe(StringUtils.format(Strings.TERMINAL_PROJECT_RESTART_PATH, getNativeProjectPath()));
                testWindow.$(".terminal-project-keep").click();

                const panel = WorkspaceManager.getPanelForID(PANEL_ID);
                panel.hide();
                panel.show();
                testWindow.brackets.test.ProjectManager.trigger("projectOpen");
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
                expect(termModule._getActiveTerminal()).toBe(instance);
                expect(instance.isAlive).toBeTrue();
                await SpecRunnerUtils.loadProjectInTestWindow(testProjectPath);
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                expect(testWindow.$(".terminal-project-banner").is(":visible")).toBeTrue();
            }, 30000);

            it("clears the banner when returning to the original project without restarting", async function () {
                const instance = await openReadyTerminal();
                await writeToTerminal("cd ..\r");
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                expect(testWindow.$(".terminal-project-banner").is(":visible")).toBeTrue();
                await SpecRunnerUtils.loadProjectInTestWindow(testProjectPath);
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
                expect(termModule._getActiveTerminal()).toBe(instance);
                expect(instance.isAlive).toBeTrue();
            }, 30000);

            it("keeps the banner while tabs from another project remain", async function () {
                const first = await openReadyTerminal();
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                await __PR.execCommand(termModule.CMD_NEW_TERMINAL);
                const second = termModule._getActiveTerminal();
                await second.firstDataReceived;
                await SpecRunnerUtils.loadProjectInTestWindow(testProjectPath);
                expect(testWindow.$(".terminal-project-banner").is(":visible")).toBeTrue();
                testWindow.$('.terminal-flyout-item[data-terminal-id="' + second.id + '"] .terminal-flyout-close')
                    .click();
                await awaitsFor(function () {
                    return second._disposed && getTerminalCount() === 1;
                }, "the other project's terminal to close", 10000);
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
                expect(termModule._getActiveTerminal()).toBe(first);
                expect(first.isAlive).toBeTrue();
            }, 30000);

            it("restarts every tab in the new project and preserves its shell and selection", async function () {
                const first = await openReadyTerminal();
                const ShellProfiles = testWindow.brackets.getModule("extensionsIntegrated/Terminal/ShellProfiles");
                // Distinct profiles using an installed shell keep this portable to machines with only one shell.
                const profileSpy = spyOn(ShellProfiles, "getDefaultShell").and.returnValue(
                    Object.assign({}, first.shellProfile, {name: "Secondary test shell"})
                );
                await __PR.execCommand(termModule.CMD_NEW_TERMINAL);
                profileSpy.and.callThrough();
                const second = termModule._getActiveTerminal();
                await second.firstDataReceived;
                testWindow.$('.terminal-flyout-item[data-terminal-id="' + first.id + '"]').click();
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                const path = getNativeProjectPath();
                testWindow.$(".terminal-project-restart").click();
                await awaitsFor(function () {
                    const active = termModule._getActiveTerminal();
                    return getTerminalCount() === 2 && active && active.isAlive && active.id !== first.id
                        && testWindow.$(".terminal-flyout-item.active").index() === 0;
                }, "both terminals to restart and the first tab to remain selected", 15000);

                expect(first._disposed).toBeTrue();
                expect(second._disposed).toBeTrue();
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
                const replacements = testWindow.$(".terminal-flyout-item").map(function () {
                    return testWindow.$(this).attr("data-terminal-id");
                }).get();
                const originals = [first, second];
                for (let i = 0; i < replacements.length; i++) {
                    testWindow.$('.terminal-flyout-item[data-terminal-id="' + replacements[i] + '"]').click();
                    const instance = termModule._getActiveTerminal();
                    expect(instance.id).not.toBe(originals[i].id);
                    expect(instance.shellProfile).toEqual(originals[i].shellProfile);
                    expect(instance.cwd).toBe(path);
                    await expectWorkingDirectory(instance, path);
                }
                await SpecRunnerUtils.loadProjectInTestWindow(testProjectPath);
                expect(testWindow.$(".terminal-project-banner").is(":visible")).toBeTrue();
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
            }, 30000);

            it("confirms active processes and leaves sessions untouched when canceled", async function () {
                const instance = await openReadyTerminal();
                const connectorSpy = reportActiveProcess();
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                testWindow.$(".terminal-project-restart").click();
                await __PR.waitForModalDialog();
                expect(getDialogTitle()).toBe(Strings.TERMINAL_RESTART_CONFIRM_TITLE);
                __PR.clickDialogButtonID(__PR.Dialogs.DIALOG_BTN_CANCEL);
                await __PR.waitForModalDialogClosed();
                await awaitsFor(function () {
                    return !testWindow.$(".terminal-project-restart").prop("disabled");
                }, "restart action to be available again", 3000);
                expect(termModule._getActiveTerminal()).toBe(instance);
                expect(instance.isAlive).toBeTrue();
                expect(connectorSpy.calls.allArgs().some(args => args[0] === "killTerminal")).toBeFalse();

                testWindow.$(".terminal-project-restart").click();
                await __PR.waitForModalDialog();
                __PR.clickDialogButtonID(__PR.Dialogs.DIALOG_BTN_OK);
                await __PR.waitForModalDialogClosed();
                await awaitsFor(function () {
                    const active = termModule._getActiveTerminal();
                    return active && active.id !== instance.id && active.isAlive;
                }, "confirmed restart to replace the terminal", 10000);
                expect(instance._disposed).toBeTrue();
                expect(termModule._getActiveTerminal().cwd).toBe(getNativeProjectPath());
            }, 30000);

            it("does not restart into a stale project if the project changes during confirmation", async function () {
                const instance = await openReadyTerminal();
                const connectorSpy = reportActiveProcess();
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                testWindow.$(".terminal-project-restart").click();
                await __PR.waitForModalDialog();
                await SpecRunnerUtils.loadProjectInTestWindow(testProjectPath);
                __PR.clickDialogButtonID(__PR.Dialogs.DIALOG_BTN_OK);
                await __PR.waitForModalDialogClosed();
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
                expect(termModule._getActiveTerminal()).toBe(instance);
                expect(connectorSpy.calls.allArgs().some(args => args[0] === "killTerminal")).toBeFalse();
            }, 30000);

            it("retains the notice while hidden and removes it when all terminals close", async function () {
                await openReadyTerminal();
                const panel = WorkspaceManager.getPanelForID(PANEL_ID);
                panel.hide();
                await SpecRunnerUtils.loadProjectInTestWindow(secondProjectPath);
                expect(panel.isVisible()).toBeFalse();
                panel.show();
                expect(testWindow.$(".terminal-project-banner").is(":visible")).toBeTrue();
                await termModule._disposeAll();
                expect(testWindow.$(".terminal-project-banner").length).toBe(0);
            }, 30000);
        });

        it("should forward Alt+Up to the terminal instead of a Phoenix command", async function () {
            const termModule = testWindow.brackets.getModule("extensionsIntegrated/Terminal/main");
            let inputListener;
            try {
                await openTerminal();
                await waitForShellReady();
                const instance = termModule._getActiveTerminal();
                const KeyBindingManager = testWindow.brackets.getModule("command/KeyBindingManager");
                const binding = KeyBindingManager.getKeymap()["Alt-Up"];
                const command = testWindow.brackets.test.CommandManager.get(binding.commandID);
                const execute = spyOn(command, "execute")
                    .and.returnValue(testWindow.$.Deferred().resolve().promise());
                const input = [];
                inputListener = instance.terminal.onData(function (data) { input.push(data); });
                instance.focus();
                await awaitsFor(function () {
                    return testWindow.document.activeElement === instance.terminal.textarea;
                }, "terminal input to have focus", 3000);

                const key = {key: "ArrowUp", code: "ArrowUp", keyCode: 38, which: 38,
                    altKey: true, bubbles: true, cancelable: true};
                instance.terminal.textarea.dispatchEvent(new testWindow.KeyboardEvent("keydown", key));
                instance.terminal.textarea.dispatchEvent(new testWindow.KeyboardEvent("keyup", key));
                await awaitsFor(function () {
                    return input.includes("\x1b[1;3A");
                }, "Alt+Up escape sequence to reach the terminal", 3000);
                expect(execute).not.toHaveBeenCalled();
            } finally {
                if (inputListener) {
                    inputListener.dispose();
                }
                await termModule._disposeAll();
                WorkspaceManager.getPanelForID(PANEL_ID).hide();
            }
        });

        describe("Context menu commands", function () {
            let CommandManager;

            function getActiveTerminal() {
                const mod = testWindow.brackets.getModule(
                    "extensionsIntegrated/Terminal/main"
                );
                return mod._getActiveTerminal();
            }

            /**
             * Check whether a marker string appears anywhere
             * in the active terminal's buffer.
             */
            function bufferContains(marker) {
                const active = getActiveTerminal();
                if (!active) {
                    return false;
                }
                const buffer = active.terminal.buffer.active;
                for (let i = 0; i < buffer.length; i++) {
                    const line = buffer.getLine(i);
                    if (line && line.translateToString()
                        .indexOf(marker) !== -1) {
                        return true;
                    }
                }
                return false;
            }

            beforeAll(function () {
                CommandManager =
                    testWindow.brackets.test.CommandManager;
            });

            it("should open Copy, Paste and Clear Terminal on right-click",
                async function () {
                    const Menus = testWindow.brackets.test.Menus;
                    const ctxMenu = Menus.getContextMenu("terminal-context-menu");
                    const termModule = testWindow.brackets.getModule("extensionsIntegrated/Terminal/main");
                    const commandStates = ["terminal.copy", "terminal.paste", "terminal.clear"].map(function (id) {
                        const command = CommandManager.get(id);
                        return {command, enabled: command.getEnabled()};
                    });
                    try {
                        await openTerminal();
                        await waitForShellReady();
                        const active = getActiveTerminal();
                        active.terminal.clearSelection();
                        active.$container.find(".xterm-screen").trigger(testWindow.$.Event("contextmenu", {
                            pageX: 100,
                            pageY: 100
                        }));
                        await awaitsFor(function () {
                            return testWindow.$("#terminal-context-menu.open > .dropdown-menu").is(":visible");
                        }, "terminal context menu to open on right-click", 3000);

                        const labels = testWindow.$("#terminal-context-menu .menu-name").map(function () {
                            return testWindow.$(this).text();
                        }).get();
                        expect(labels).toEqual([Strings.CMD_COPY, Strings.CMD_PASTE, Strings.TERMINAL_CLEAR]);
                        expect(CommandManager.get("terminal.copy").getEnabled()).toBeFalse();
                        expect(CommandManager.get("terminal.paste").getEnabled()).toBeTrue();
                        expect(CommandManager.get("terminal.clear").getEnabled()).toBeTrue();
                    } finally {
                        ctxMenu.close();
                        commandStates.forEach(function (state) { state.command.setEnabled(state.enabled); });
                        await termModule._disposeAll();
                        WorkspaceManager.getPanelForID(PANEL_ID).hide();
                    }
                });

            it("should clear the terminal screen",
                async function () {
                    await openTerminal();
                    await waitForShellReady();

                    // Write some output so the terminal has content
                    await writeToTerminal("echo cleartest\r");
                    await awaitsFor(function () {
                        return bufferContains("cleartest");
                    }, "echo output to appear", 10000);

                    // Execute the clear command
                    await CommandManager.execute("terminal.clear");

                    // After clear, the marker should no longer be
                    // in the buffer (xterm.clear() wipes scrollback).
                    await awaitsFor(function () {
                        return !bufferContains("cleartest");
                    }, "terminal to be cleared", 5000);

                    // Clean up
                    clickPanelCloseButton();
                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to close", 5000);
                });

            it("should copy selected terminal text to clipboard",
                async function () {
                    await openTerminal();
                    await waitForShellReady();

                    // Write a unique marker string
                    await writeToTerminal("echo COPYMARKER123\r");
                    await awaitsFor(function () {
                        return bufferContains("COPYMARKER123");
                    }, "echo output to appear", 10000);

                    // Select all text in xterm
                    const active = getActiveTerminal();
                    active.terminal.selectAll();
                    expect(active.terminal.hasSelection())
                        .toBeTrue();
                    const selection = active.terminal.getSelection();
                    expect(selection).toContain("COPYMARKER123");

                    // The copy command writes to the system clipboard
                    // via navigator.clipboard.writeText(). In the test
                    // iframe clipboard writes may be denied (no focus),
                    // so we verify the command reads the right text by
                    // spying on writeText.
                    const clipboard = testWindow.navigator.clipboard;
                    let copiedText = null;
                    spyOn(clipboard, "writeText").and.callFake(
                        function (text) {
                            copiedText = text;
                            return testWindow.Promise.resolve();
                        }
                    );
                    await CommandManager.execute("terminal.copy");
                    expect(copiedText).toContain("COPYMARKER123");

                    // Clean up
                    clickPanelCloseButton();
                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to close", 5000);
                });

            it("should paste clipboard text into terminal",
                async function () {
                    await openTerminal();
                    await waitForShellReady();

                    // Mock Phoenix.app.clipboardReadText to return a
                    // known string, since the test iframe may not have
                    // clipboard permission (no window focus).
                    const pasteText = "PASTEMARKER456";
                    spyOn(testWindow.Phoenix.app, "clipboardReadText")
                        .and.returnValue(
                            testWindow.Promise.resolve(pasteText)
                        );

                    // Execute the paste command
                    await CommandManager.execute("terminal.paste");

                    // The pasted text should appear in the terminal
                    // buffer (written to PTY input → echoed back).
                    await awaitsFor(function () {
                        return bufferContains(pasteText);
                    }, "pasted text to appear in terminal", 10000);

                    // Clean up: press Enter then close
                    await writeToTerminal("\r");
                    clickPanelCloseButton();
                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to close", 5000);
                });

            it("should disable copy when there is no selection",
                async function () {
                    await openTerminal();
                    await waitForShellReady();

                    const active = getActiveTerminal();
                    // Ensure no selection
                    active.terminal.clearSelection();
                    expect(active.terminal.hasSelection())
                        .toBeFalse();

                    // Open context menu to trigger
                    // beforeContextMenuOpen event
                    const Menus = testWindow.brackets.test.Menus;
                    const ctxMenu = Menus.getContextMenu(
                        "terminal-context-menu"
                    );
                    ctxMenu.open({pageX: 100, pageY: 100});

                    const copyCmd =
                        CommandManager.get("terminal.copy");
                    expect(copyCmd.getEnabled()).toBeFalse();

                    // Close menu
                    ctxMenu.close();

                    // Now select text and re-open
                    active.terminal.selectAll();
                    ctxMenu.open({pageX: 100, pageY: 100});
                    expect(copyCmd.getEnabled()).toBeTrue();
                    ctxMenu.close();

                    // Clean up
                    clickPanelCloseButton();
                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to close", 5000);
                });
        });

        describe("Programmatic hide vs user close", function () {
            it("should keep terminals alive after panel.hide()",
                async function () {
                    await openTerminal();
                    await awaitsFor(function () {
                        return getTerminalCount() === 1;
                    }, "terminal to be created", 10000);

                    const panel =
                        WorkspaceManager.getPanelForID(PANEL_ID);
                    panel.hide();

                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to hide", 5000);

                    expect(isDialogOpen()).toBeFalse();

                    // Re-show — terminal should still exist
                    panel.show();
                    await awaitsFor(function () {
                        return testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to show again", 5000);

                    expect(getTerminalCount()).toBe(1);

                    // Clean up
                    clickPanelCloseButton();
                    await awaitsFor(function () {
                        return !testWindow.$("#terminal-panel")
                            .is(":visible");
                    }, "terminal panel to close", 5000);
                });
        });
    });
});
