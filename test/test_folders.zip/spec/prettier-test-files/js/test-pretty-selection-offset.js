function hello(){console.log("hello");}

function world(){console.log("world");}

        function yo() {
            console.log("yo");
        }
